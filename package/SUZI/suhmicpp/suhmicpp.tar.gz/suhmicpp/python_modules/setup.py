import os
from distutils.core import setup, Extension

try:
    QTDIR = os.environ['QTDIR']
except KeyError:
    QTDIR='/opt/QtSDK/Desktop/Qt/473/gcc'    

QTDIR = QTDIR + '/include'

setup(
    name='SuhmiCpp',
    version='0.1.0',
    author='V. Jendrol',
    author_email='vlado@tind.sk',
    packages=['hmi','suhmi_cpp'],
    ext_modules = [Extension('hmi._hmi', ['hmi_adapt.i',], libraries=['python2.5'], include_dirs=[QTDIR+'/QtCore', QTDIR+'/QtNetwork',QTDIR+'/QtGui',QTDIR+'/QtXml',QTDIR+'/QtXmlPatterns',QTDIR+'/QtSql',QTDIR+'/QtSvg',QTDIR, '/usr/local/include/suhub-connector-light', '/usr/local/include/suhub-connector-light', '/usr/include/python2.5','../', '../Widgetkeyboard/src'], extra_compile_args=['-fPIC','-g3','-O0'], language='c++', swig_opts=['-c++','-outdir', 'hmi'], extra_link_args=['-shared'])],
    url='',
    license='LICENSE.txt',
    description='Moduly pre suhmi-cpp',
)
