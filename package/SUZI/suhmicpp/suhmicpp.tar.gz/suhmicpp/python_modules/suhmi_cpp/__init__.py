__all__ = ['suhmi_cpp',]

__version__ = '0.1.0'
from suhmi_cpp import createTag, voidTag
from constants import *
