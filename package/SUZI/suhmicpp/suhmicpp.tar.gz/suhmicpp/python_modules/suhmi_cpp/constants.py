# Konstanty pouzivane v skriptoch suzi

# FONT
class Font:
    class Name:
        SERIF = 0
        SANSSERIF = 1
        MONOSPACED = 2
    class Style:
        PLAIN = 0
        BOLD = 1
        ITALIC = 2
        
class BgStyle:
    SOLID = 0
    TRANSPARENT = 1

class FgStyle:
    SOLID = 0
    DASH = 1
    DOT = 2
    DASHDOT = 3
    
class ImageExtension:
    JPG = 0
    BMP = 1
    PNG = 2
    SVG = 3
    GIF = 4

class ArcType:
    CHORD = 0
    OPEN = 1
    PIE = 2

class Alignment:
    LEFT = 0
    CENTER = 1
    RIGHT = 2

class Print:
    class Size:
        A0 = 0
        A1 = 1
        A2 = 2
        A3 = 3
        A4 = 4
        A5 = 5
    class Orientation:
        PORTRAIT = 0
        LANDSCAPE = 1

