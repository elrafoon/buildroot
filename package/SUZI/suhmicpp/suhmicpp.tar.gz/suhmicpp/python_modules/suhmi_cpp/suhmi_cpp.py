# Defaultne
#v = 0, t= now, q = 192
# TODO: t nastavovat na now pri zmene v a q
from time import time

class Tag(object):
    def __init__(self, v=0, t=0, q=0):
        self.v = v
        self.t = t
        self.q = q

class VoidTag(object):
	t = 0
	q = 0
     
	def setV(self, v):
		t = time()
		q = 0
     
	def getV(self):
		return 0

	v = property(getV, setV)
	
def createTag(v=0, t=time(), q=192):
    return Tag(v, t, q)

voidTag = VoidTag()
