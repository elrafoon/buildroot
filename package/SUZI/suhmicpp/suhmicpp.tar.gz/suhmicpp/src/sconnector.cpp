/*
zw * sconnector.cpp
 *
 *  Created on: Sep 10, 2010
 *      Author: vlado
 */

#include "suhmicpp/sconnector.h"

using namespace SuhubConnector;

SConnector::SConnector(TagNameSet &staticNotifyList, TagNameSet &staticInputList, TagNameSet &dynamicNotifyList, TagNameSet &dynamicInputList) :
		GenericConnector(staticNotifyList,staticInputList,dynamicNotifyList,dynamicInputList) {
}
