/*
 * image.cpp
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QtGui>
#include <QSvgRenderer>
#include <QColor>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/image.h"
#include "suhmicpp/symbols/visual_symbol.h"


const QSize Image::maxSize(2048, 2048);

Image::Image(const QXmlAttributes &attributes) :
	VisualSymbol(attributes) {
	obType = obType | IMAGE;
	if (attributes.value("extension") == "JPG" || attributes.value("extension") == "JPEG")
		extension = JPG;
	else if (attributes.value("extension") == "BMP")
		extension = BMP;
	else if (attributes.value("extension") == "PNG")
		extension = PNG;
	else if (attributes.value("extension") == "SVG")
		extension = SVG;
	else if (attributes.value("extension") == "GIF")
		extension = GIF;
	else
		extension = JPG;
}

Image::Image(const Image &image) : VisualSymbol(image), image(image.image), extension(image.extension), data(image.data){

}

Symbol* Image::clone() {
	Image *i = new Image(*this);
	return static_cast<Symbol*>(i);
}

QRectF Image::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void Image::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Image");
	ProfileTimer t(timerName);
#endif
	if (bgBlinkState == true) {
		QRegion verticalReg = QRegion(0, size.height() * (1 - verticalFill / 100.0), size.width(), size.height() * (verticalFill / 100.0)); // vykreslovana oblast
		QRegion horizontalReg = QRegion(0, 0, size.width() * (horizontalFill / 100.0), size.height());
		painter->setClipRegion(horizontalReg & verticalReg);
		painter->drawImage(QPoint(0, 0), image.scaled(size.toSize().boundedTo(maxSize)));
	}
}

QPainterPath Image::shape() const {
	QPainterPath path;
	path.addRect(0, 0, size.width(), size.height());
	return path;
}

void Image::setData(std::string data) {
#ifdef PROFILE_TIMER
	std::string timerName("Image::setData");
	ProfileTimer t(timerName);
#endif
	this->data = data;
	image = QImage(size.width(), size.height(), QImage::Format_ARGB32_Premultiplied);
	const QByteArray ba = QByteArray::fromHex(data.c_str());
	switch (extension) {
	case SVG: {
		QPainter painter(static_cast<QPaintDevice *> (&image));
		QSvgRenderer renderer(ba);
		renderer.render(&painter);
	}
		break;
	case JPG:
		image.loadFromData(ba, "JPG");
		break;
	case PNG:
		image.loadFromData(ba, "PNG");
		break;
	case BMP:
		image.loadFromData(ba, "BMP");
		break;
	case GIF:
		image.loadFromData(ba, "GIF");
		break;
	default:
		break;
	}
}

/**
 * Vrati minimum zo size a maxSize.
 */
std::pair<int, int> Image::getSize(){
	QSize minSize = size.toSize().boundedTo(maxSize);
	return std::pair<int, int>(minSize.width(), minSize.height());
}

QSize Image::getMaxSize(){
	return maxSize;
}
