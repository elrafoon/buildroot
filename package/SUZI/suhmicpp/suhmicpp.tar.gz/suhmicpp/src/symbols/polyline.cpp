/*
 * polyline.cpp
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#include <vector>
#include <QtGui>
#include <QXmlAttributes>
#include <QColor>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/polyline.h"


Polyline::Polyline(const QXmlAttributes &attributes) :
	SimpleVisualSymbol(attributes) {
	obType = obType | POLYLINE;
	pen.setWidth(pen.width() / 2.0);
	pen.setJoinStyle(Qt::RoundJoin);
}

Symbol* Polyline::clone() {
	Polyline *p = new Polyline(*this);
	return static_cast<Symbol*>(p);
}

QRectF Polyline::boundingRect() const {
	float border = 1.5 * (lineWidth /2); // linePath.boundingRect() nepocita so sirkou ciary, border je kompenzacia; 1.5 je priblizne sqrt(2); ak je ciara pod uhlom 45 stupnov
	return polyline.boundingRect().adjusted(-border, -border, border, border);
}

void Polyline::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Polyline");
	ProfileTimer t(timerName);
#endif
#ifdef ANTIALIASING
	painter->setRenderHint(QPainter::Antialiasing);
#endif

	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setPen(pen);
	painter->drawPath(polyline);
}

QPainterPath Polyline::shape() const {
	return polyline;
}

/**
 * Prida bod obsiahnuty v attributes do vectora vertexes a originalVertexes.
 */
void Polyline::addVertex(const QXmlAttributes &attributes) {
	vertexes.push_back(QPoint(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt()));
	originalVertexes.push_back(QPoint(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt()));
}

/**
 * Zadane body premapuje tak, aby sa polyline dovnutra. Z premapovanych bodov vytvori cestu polyline.
 */
void Polyline::fini() {
	//vytvorim cestu podla vrcholov z XML
	const QPainterPath emptyPath;
	polyline = emptyPath;
	QPainterPath path;
	bool first = true;
	for (std::vector<QPoint>::iterator p = vertexes.begin(); p < vertexes.end(); ++p) {
		if (first) {
			path.moveTo(QPoint((*p).x(), (*p).y()));
			first = false;
		}
		path.lineTo(QPoint((*p).x(), (*p).y()));
	}

	// urcim poziciu novych koncovych bodov, aby sedeli s pozadovanou sirkou ciary
	int length = path.length();
	QPointF newStart = path.pointAtPercent(lineWidth / ((float) length * 2));
	QPointF newEnd = path.pointAtPercent(1 - (lineWidth / ((float) length * 2)));
	vertexes[0].setX(newStart.x());
	vertexes[0].setY(newStart.y());
	vertexes[vertexes.size()-1].setX(newEnd.x());
	vertexes[vertexes.size()-1].setY(newEnd.y());

	prepareGeometryChange();
	// vytvorim vyslednu polyline
	first = true;
	for (std::vector<QPoint>::iterator p = vertexes.begin(); p < vertexes.end(); ++p) {
		if (first) {
			polyline.moveTo(QPoint((*p).x(), (*p).y()));
			first = false;
		}
		polyline.lineTo(QPoint((*p).x(), (*p).y()));
	}
}

/**
 * Sluzi na nastavenie velkosti opisaneho obdlznika. Vypocita nove vrcholy polyline a zavola fini() aby sa vytvorila nova cesta polyline.
 */
void Polyline::setSize(int width, int height){
	SimpleVisualSymbol::setSize(width, height);
	QMatrix4x4 matrix;
	matrix.scale(float(width)/originalSize.width(), float(height)/originalSize.height());
	std::vector<QPoint>::iterator it;
	std::vector<QPoint>::iterator jt;
	for(it = originalVertexes.begin(), jt = vertexes.begin(); jt != vertexes.end(); ++it, ++jt){
		*jt = matrix.map(*it);
	}
	fini();
	update();
}

void Polyline::setHorSize(long value) {
	setSize(value, size.height());
}

void Polyline::setVertSize(long value) {
	setSize(size.width(), value);
}
