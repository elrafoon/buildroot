/*
 * base_label.cpp
 *
 *  Created on: Oct 26, 2010
 *      Author: vlado
 */

#include "suhmicpp/symbols/base_label.h"

BaseLabel::BaseLabel(const QXmlAttributes &attributes) : SimpleVisualSymbol (attributes){
	obType = obType | BASE_LABEL;
	sFont.flags = Qt::AlignVCenter;
	sFont.setAlign(attributes.value("align").toStdString());
}

BaseLabel::BaseLabel(const BaseLabel &bl) : SimpleVisualSymbol(bl), sFont(bl.sFont){
	obType = obType | BASE_LABEL;
}

void BaseLabel::setFontAttributes(const QXmlAttributes &attributes){
	sFont.size = attributes.value("size").toInt();
	sFont.setName(attributes.value("name").toStdString());
	sFont.setStyle(attributes.value("style").toStdString());
}

Font& BaseLabel::getFont(){
	return sFont;
}

void BaseLabel::setSize(int width, int height){
	SimpleVisualSymbol::setSize(width, height);
}

void BaseLabel::setHorSize(long value){
	setSize(value, size.height());
	update();
}

void BaseLabel::setVertSize(long value){
	setSize(size.width(), value);
	update();
}

void BaseLabel::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget){
	painter->fillRect(0, size.height()  * (1 - (verticalFill / 100.0)), size.width() * (horizontalFill / 100.0), size.height() * (verticalFill / 100.0), brush);
}

QPainterPath BaseLabel::shape() const {
	QPainterPath path;
	path.addRect(0, size.height()  * (1 - (verticalFill / 100.0)), size.width() * (horizontalFill / 100.0), size.height() * (verticalFill / 100.0));
	return path;
}
