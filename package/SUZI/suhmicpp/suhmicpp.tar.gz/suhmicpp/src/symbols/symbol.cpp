/*
 * symbol.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#include "suhmicpp/symbols/symbol.h"

#include <QString>

Symbol::Symbol() {
	obType = obType | SYMBOL;
	name = "Symbol";
	identification = name;

}

Symbol::Symbol(QString &n) {
	obType = obType | SYMBOL;
	name = n.toStdString();
	identification = name;
}

Symbol::Symbol(const QXmlAttributes &attributes) {
	obType |= SYMBOL;
	name = attributes.value("name").toStdString();
	identification = name;
}

Symbol::Symbol(const Symbol &symbol) :
	ObjectBase(symbol), name(symbol.name) {
}

void Symbol::create() {
	ObjectBase::create();
}

void Symbol::destroy() {
	ObjectBase::destroy();
}

void Symbol::fini() {
	ObjectBase::fini();
}

void Symbol::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	genericScriptList.setDebugInfo(this->debugInfo, identification);
	oncreate.setDebugInfo(this->debugInfo, identification);
	ondestroy.setDebugInfo(this->debugInfo, identification);
}
