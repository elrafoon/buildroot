/*
 * arc.cpp
 *
 *  Created on: Jul 9, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QtGui>
#include <QColor>
#include <QRect>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/symbols/arc.h"


Arc::Arc(const QXmlAttributes &attributes) :
	SimpleVisualSymbol(attributes) {
	obType = obType | ARC;
	this->angleStart = attributes.value(QString("angleStart")).toFloat();
	this->angleSize = attributes.value(QString("angleSize")).toFloat();
	this->radius = attributes.value(QString("radius")).toFloat();
	QString arcType = attributes.value(QString("arcType"));
	if (arcType == "chord") {
		this->arctype = chord;
	} else if (arcType == "open") {
		this->arctype = open;
	} else {
		this->arctype = pie;
	}
}

Symbol* Arc::clone() {
	Arc *a = new Arc(*this);
	a->fini();
	return static_cast<Symbol*>(a);
}

QRectF Arc::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void Arc::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Arc");
	ProfileTimer t(timerName);
#endif
#ifdef ANTIALIASING
	painter->setRenderHint(QPainter::Antialiasing);
#endif

	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setBrush(brush);
	painter->setPen(pen);

	QRect innerRectangle = innerArcPath.boundingRect().toRect();
	QPainterPath verticalPath;
	verticalPath.addRect(innerRectangle.x(), innerRectangle.y(), innerRectangle.width(), innerRectangle.height() * (1 - verticalFill / 100.0));

	QPainterPath horizontalPath;
	horizontalPath.addRect(innerRectangle.x() + innerRectangle.width() * (horizontalFill / 100.0), innerRectangle.y(), innerRectangle.width() * (1 - horizontalFill / 100.0), innerRectangle.height());

	painter->setClipPath(arcPath - (innerArcPath & (verticalPath + horizontalPath)));
	painter->drawPath(arcPath);
	//painter->drawPath(innerArcPath & verticalPath & horizontalPath);
	//QPoint middle = QPoint(size.width() / 2, size.height() / 2);
}

QPainterPath Arc::shape() const {
	QPainterPath arcPath;
	if (arctype == pie) {
		arcPath.setFillRule(Qt::OddEvenFill);
		arcPath.moveTo(size.width() / 2, size.height() / 2);
		arcPath.arcTo(0, 0, size.width(), size.height(), angleStart, angleSize);
	} else {
		arcPath.setFillRule(Qt::OddEvenFill);
		QPointF currentPoint;
		arcPath.arcMoveTo(0, 0, size.width(), size.height(), angleStart);
		currentPoint = arcPath.currentPosition();
		arcPath.arcTo(0, 0, size.width(), size.height(), angleStart, angleSize);
	}
	return arcPath;
}

/**
 * Vrati bod na obvode elipsy, kde rameno uhla so stredom v strede elipsy a velkostou uhla angle pretina obvod elipsy.
 */
QPoint Arc::ellipseIntersection(int angle) {
	float angleRad = (angle % 360) * PI / 180;
	int x = (size.width() / 2) * cos(angleRad);
	int y = (size.height() / 2) * sin(angleRad);
	return QPoint(x, -y);
}

/**
 * Do argumentu intersect nastavi bod, v ktorom sa pretinaju priamky dane bodmi (x1, y1, x2, y2) a (x3, y3, x4, y4).
 * \retval 0 ak nasiel priesecnik
 * \retval -1 ak su priamky paralelne
 */
int Arc::intersection(QPoint &intersect, int x1,int y1,int x2,int y2,int x3, int y3, int x4,int y4){
	int denominator = ((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4));
	if(denominator == 0)
		return -1;
	int xi = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denominator;
	int yi = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denominator;
	intersect.setX(xi);
	intersect.setY(yi);
	return 0;
}

/**
 * Pretazenie funkcie Arc::getInnerLine(QPoint p1, QPoint p2, bool start, int distance). Ako distance sa pouzije sirka ciary lineWidth.
 */
std::pair<QPoint, QPoint> Arc::getInnerLine(QPoint &p1, QPoint &p2, bool start) {
	return getInnerLine(p1, p2, start, lineWidth);
}

/**
 * Vrati usecku paralelnu so zadanou useckou vo vzdialenosti distance.
 * \returns Vrati dvojicu bodov definujucich usecku.
 */
std::pair<QPoint, QPoint> Arc::getInnerLine(QPoint &p1, QPoint &p2, bool start, int distance){
	float vectX;
	float vectY;

	if (start) {
		vectX = p2.x() - p1.x();
		vectY = p2.y() - p1.y();
	} else {
		vectX = p1.x() - p2.x();
		vectY = p1.y() - p2.y();
	}
	float vectSize = sqrt((vectX * vectX) + (vectY * vectY));

	float tmp = vectX;
	vectX = vectY;
	vectY = -tmp;

	int ecx = size.width() / 2;
	int ecy = size.height() / 2;

	vectX = (vectX / vectSize) * distance * 2;
	vectY = (vectY / vectSize) * distance * 2;
	return std::pair<QPoint, QPoint>(QPoint(p1.x() + ecx + vectX / 2.0, p1.y() + ecy + vectY / 2.0), QPoint(p2.x() + ecx + vectX / 2.0, p2.y() + ecy + vectY / 2.0));
}

/**
 * Finalizacia Arc-u.
 * Podla typu Arcu nastavi innerArcPath a arcPath.
 */
void Arc::fini() {
#ifdef PROFILE_TIMER
	std::string timerName("Arc::fini");
	ProfileTimer t(timerName);
#endif
	QPainterPath empytPath;
	innerArcPath = empytPath;
	arcPath = empytPath;
	QPoint i;
	QPoint si;
	QPoint ei;
	QPoint zeroPoint(0,0);
	std::pair<QPoint, QPoint> parallel1;
	std::pair<QPoint, QPoint> parallel2;
	si = ellipseIntersection(angleStart);
	ei = ellipseIntersection(angleStart + angleSize);
	float fi1 = 0;
	QPoint middle = QPoint(size.width() / 2, size.height() / 2);

	if (arctype == pie) {
		fi1 = atan(lineWidth / (sqrt(si.x() * si.x() + si.y() * si.y()) - lineWidth));
		arcPath.moveTo(size.width() / 2, size.height() / 2);
		arcPath.arcTo(0, 0, size.width(), size.height(), angleStart, angleSize);
		arcPath.closeSubpath();

		QPoint ec = QPoint(size.width() / 2, size.height() / 2);

		parallel1 = this->getInnerLine(zeroPoint, si, true);
		parallel2 = this->getInnerLine(zeroPoint, ei, false);
		if(intersection(i, parallel1.first.x(), parallel1.first.y(), parallel1.second.x(), parallel1.second.y(), parallel2.first.x(), parallel2.first.y(), parallel2.second.x(), parallel2.second.y()) != -1){
			innerArcPath.moveTo(i);
			innerArcPath.arcTo(lineWidth, lineWidth, size.width() - 2 * lineWidth, size.height() - 2 * lineWidth, angleStart + fi1 * 180 / PI, angleSize - 2 * fi1 * 180 / PI);
		}
		else{
			// ramena su paralelne
			innerArcPath.addEllipse(lineWidth, lineWidth, size.width() - 2 * lineWidth, size.height() - 2 * lineWidth);
		}
		innerArcPath.closeSubpath();

	} else if (arctype == chord) {
		fi1 = atan(lineWidth / (sqrt(pow(ei.x() - si.x(), 2) + pow(ei.y() - si.y(), 2))));
		arcPath.arcMoveTo(0, 0, size.width(), size.height(), angleStart);
		arcPath.arcTo(0, 0, size.width(), size.height(), angleStart, angleSize);
		arcPath.closeSubpath();
		parallel1 = this->getInnerLine(ei, si, true);

		std::pair<QPoint, QPoint> l7;
		l7 = getInnerLine(si, ei, true, size.width());
		QPainterPath pol;
		pol.moveTo(parallel1.first);
		pol.lineTo(parallel1.second);
		pol.lineTo(l7.first);
		pol.lineTo(l7.second);
		pol.lineTo(parallel1.first);

		innerArcPath.addEllipse(lineWidth, lineWidth, size.width() - 2*lineWidth, size.height() - 2*lineWidth);
		innerArcPath = (innerArcPath - pol) & arcPath;
	} else {
		QPointF currentPoint;
		arcPath.arcMoveTo(0, 0, size.width(), size.height(), angleStart);
		currentPoint = arcPath.currentPosition();
		arcPath.arcTo(0, 0, size.width(), size.height(), angleStart, angleSize);
		innerArcPath.addEllipse(lineWidth, lineWidth, size.width() - 2*lineWidth, size.height() - 2*lineWidth);
	}
}

void Arc::setAngleStart(int angleStart){
	this->angleStart = angleStart;
	fini();
	update();
}

int Arc::getAngleStart(){
	return angleStart;
}

void Arc::setAngleSize(int angleSize){
	this->angleSize = angleSize;
	fini();
	update();
}

int Arc::getAngleSize(){
	return angleSize;
}

void Arc::setSize(float width, float height){
	SimpleVisualSymbol::setSize(width, height);
	fini();
}
void Arc::setHorSize(long value){
	setSize(value, size.height());
	update();
}

void Arc::setVertSize(long value){
	setSize(size.width(), value);
	update();
}

void Arc::setArctype(int arctype){
	this->arctype = static_cast<ArcType>(arctype);
	fini();
	update();
}
