/*
 * timer.cpp
 *
 *  Created on: Sep 9, 2011
 *      Author: vlado
 */

#include "suhmicpp/symbols/timer.h"

Timer::Timer(const QXmlAttributes &attributes) :
	Symbol(attributes), onTick(this) {
	obType = obType | TIMER;
	connect(&qTimer, SIGNAL(timeout()), this, SLOT(onTimeout()));
	period = attributes.value("period").toUInt();
	if (attributes.value("enabled") == "true") {
		enabled = true;
		qTimer.start(period);
	} else
		enabled = false;
}

Timer::Timer(const Timer &timer) : Symbol(timer), onTick(timer.onTick, this), enabled(timer.enabled), period(timer.period){
	connect(&qTimer, SIGNAL(timeout()), this, SLOT(onTimeout()));
	if(enabled)
		qTimer.start(period);
}

void Timer::onTimeout() {
	onTick.exec();
}

void Timer::fini() {
	Symbol::fini();
}

Symbol* Timer::clone(){
	Timer *r = new Timer(*this);
	return static_cast<Symbol*>(r);
}

void Timer::setEnabled(bool enabled) {
	if (enabled) {
		if (!qTimer.isActive())
			qTimer.start(period);
	} else {
		qTimer.stop();
	}
}

void Timer::compileCodes(){
	onTick.handlerCode.compileCode();
}

void Timer::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Symbol::setDebugInfo(debugInfo, parentId);
	onTick.setDebugInfo(this->debugInfo, identification);
}
