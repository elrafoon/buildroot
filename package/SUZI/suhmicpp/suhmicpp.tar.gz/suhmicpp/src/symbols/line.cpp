/*
 * line.cpp
 *
 *  Created on: Jul 9, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QtGui>
#include <QColor>
#include <QPainterPath>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/symbols/line.h"

Line::Line(const QXmlAttributes &attributes) :
	SimpleVisualSymbol(attributes) {
	obType |= LINE;
	pen.setWidth(pen.width() / 2.0);
}

Line::Line(const Line &line) : SimpleVisualSymbol(line) {
	vertexes = line.vertexes;
	originalVertexes = line.originalVertexes;
	linePath = line.linePath;
	pen.setWidth(line.pen.width());
}

Symbol* Line::clone() {
	Line *l = new Line(*this);
	return static_cast<Symbol*>(l);
}

QRectF Line::boundingRect() const {
	float border = 1.5 * (lineWidth /2); // linePath.boundingRect() nepocita so sirkou ciary, border je kompenzacia; 1.5 je priblizne sqrt(2); ak je ciara pod uhlom 45 stupnov
	return linePath.boundingRect().adjusted(-border, -border, border, border);
}

void Line::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Line");
	ProfileTimer t(timerName);
#endif
#ifdef ANTIALIASING
	painter->setRenderHint(QPainter::Antialiasing);
#endif

	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setPen(pen);
	painter->drawPath(linePath);
}

QPainterPath Line::shape() const {
	QPainterPath shape;
	shape.addRect(linePath.boundingRect());
	return shape;
}

void Line::addVertex(const QXmlAttributes &attributes) {
	vertexes.push_back(QPoint(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt()));
	originalVertexes.push_back(QPoint(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt()));
}

void Line::setStart(int x, int y) {
	vertexes[0].setX(x);
	vertexes[0].setY(y);
	update();
}

void Line::getStart(int &x, int &y) {
	x = vertexes[0].x();
	y = vertexes[0].y();
}

void Line::setEnd(int x, int y) {
	vertexes[1].setX(x);
	vertexes[1].setY(y);
	update();
}

void Line::getEnd(int &x, int &y) {
	x = vertexes[1].x();
	y = vertexes[1].y();
}

/**
 * Prepocita vrcholy ciary tak, aby sa vosli do obdlznika so sirkou width a vyskou height.
 */
void Line::setSize(int width, int height) {
	SimpleVisualSymbol::setSize(width, height);
	QMatrix4x4 matrix;
	matrix.scale(float(width) / originalSize.width(), float(height) / originalSize.height());
	std::vector<QPoint>::iterator it;
	std::vector<QPoint>::iterator jt;
	for (it = originalVertexes.begin(), jt = vertexes.begin(); jt != vertexes.end(); ++it, ++jt) {
		*jt = matrix.map(*it);
	}
	fini();
}

void Line::setHorSize(long value) {
	setSize(value, size.height());
}

void Line::setVertSize(long value) {
	setSize(size.width(), value);
}

/**
 * Na zaklade vrcholov z XML a sirky ciary, vytvori cestu, ktora ma vrcholy posunute dovnutra tak aby po vykresleni perom s hrubkou sirky ciary, vyzerala ako ziadana.
 */
void Line::fini() {
	SimpleVisualSymbol::fini();
	const QPainterPath emptyPath;
	linePath = emptyPath;

	QPainterPath path;
	path.moveTo(vertexes[0]);
	path.lineTo(vertexes[1]);
	int length = path.length();
	linePath.moveTo(path.pointAtPercent(lineWidth / ((float) length * 2)));
	linePath.lineTo(path.pointAtPercent(1 - (lineWidth / ((float) length * 2))));
}

void Line::setLineWidth(int lineWidth){
	if (lineWidth < 0)
		lineWidth = 0;
	this->lineWidth = lineWidth;
	pen.setWidth(lineWidth);
	prepareGeometryChange();
}
