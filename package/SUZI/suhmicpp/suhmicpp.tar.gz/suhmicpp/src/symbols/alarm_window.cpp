/*
 * alarm_window.cpp
 *
 *  Created on: Aug 24, 2011
 *      Author: vlado
 */

#include <iostream>
#include <algorithm>
#include <ace/INET_Addr.h>
#include "suhmicpp/symbols/alarm_window.h"
#include "suhmicpp/AlarmWindow/alarmcontroller.h"

AWSSystem::AWSSystem() {
	source = SYSTEM;
}

AWSGroup::AWSGroup(const QXmlAttributes &attributes) {
	source = GROUP;
	groupId = attributes.value("groupId").toUInt();
	if (attributes.value("withSubgroups") == "true")
		withSubGroups = true;
	else
		withSubGroups = false;
}

AWSAlarm::AWSAlarm(const QXmlAttributes &attributes) {
	source = ALARM;
	alarmId = attributes.value("alarmId").toUInt();
}

AlarmColumn::AlarmColumn(EType type, uint32_t section, uint32_t width) :
		type(type), section(section), width(width) {

}

void AlarmColumn::setWidth(uint32_t width) {
	this->width = width;
}

AlarmWindow::AlarmWindow(const QXmlAttributes &attributes, int port, std::string host) :
		Symbol(attributes), onshow(this), onhide(this), source(NULL), alarmController(NULL), filter(0), logger("AlarmWindow: ") {
	obType = obType | ALARM_WINDOW;
	refreshPeriod = attributes.value("refreshPeriod").toUInt();
	defaultSortColumn = attributes.value("defaultSortColumn").toStdString();
	userSortEnabled = (bool) attributes.value("userSortEnabled").toInt();
	this->port = port;
	this->host = host;
}

AlarmWindow::~AlarmWindow() {
	for (std::map<AlarmColumn::EType, AlarmColumn*>::iterator it = columns.begin(); it != columns.end(); ++it) {
		delete it->second;
	}

	if (alarmController)
		delete alarmController;
}

void AlarmWindow::fini() {
	onshow.handlerCode.compileCode();
	onhide.handlerCode.compileCode();
}

Symbol* AlarmWindow::clone() {
	return NULL;
}

void AlarmWindow::setPosition(const QXmlAttributes &attributes) {
	position.setX(attributes.value("x").toInt());
	position.setY(attributes.value("y").toInt());
}

void AlarmWindow::setSize(const QXmlAttributes &attributes) {
	size.setWidth(attributes.value("width").toInt());
	size.setHeight(attributes.value("height").toInt());
}

void AlarmWindow::addColumn(const QXmlAttributes &attributes) {
	QString type = attributes.value("type");
	uint32_t order = attributes.value("order").toInt();
	uint32_t width = attributes.value("width").toInt();
	if (type == "alarmLatestUpdateTime")
		columns[AlarmColumn::alarmLatestUpdateTime] = new AlarmColumn(AlarmColumn::alarmLatestUpdateTime, order, width);
	else if (type == "alarmName")
		columns[AlarmColumn::alarmName] = new AlarmColumn(AlarmColumn::alarmName, order, width);
	else if (type == "groupName")
		columns[AlarmColumn::groupName] = new AlarmColumn(AlarmColumn::groupName, order, width);
	else if (type == "alarmPriority")
		columns[AlarmColumn::alarmPriority] = new AlarmColumn(AlarmColumn::alarmPriority, order, width);
	else if (type == "alarmEffectivePriority")
		columns[AlarmColumn::alarmEffectivePriority] = new AlarmColumn(AlarmColumn::alarmEffectivePriority, order, width);
	else if (type == "groupEffectivePriority")
		columns[AlarmColumn::groupEffectivePriority] = new AlarmColumn(AlarmColumn::groupEffectivePriority, order, width);
	else if (type == "alarmState")
		columns[AlarmColumn::alarmState] = new AlarmColumn(AlarmColumn::alarmState, order, width);
	else if (type == "groupState")
		columns[AlarmColumn::groupState] = new AlarmColumn(AlarmColumn::groupState, order, width);
	else if (type == "alarmConditions")
		columns[AlarmColumn::alarmConditions] = new AlarmColumn(AlarmColumn::alarmConditions, order, width);
}

void AlarmWindow::setButtonSet(const QXmlAttributes &attributes) {
	std::map<int, EButtonSet> buttonMap;
	insertIfNotHidden(buttonMap, attributes, "ackSelected", ackSelected);
	insertIfNotHidden(buttonMap, attributes, "ackGroup", ackGroup);
	insertIfNotHidden(buttonMap, attributes, "ackAll", ackAll);
	insertIfNotHidden(buttonMap, attributes, "ackInactive", ackInactive);
	for (std::map<int, EButtonSet>::iterator it = buttonMap.begin(); it != buttonMap.end(); ++it) {
		buttonVector.push_back(it->second);
	}
}

void AlarmWindow::setFilter(const QXmlAttributes &attributes) {
	if (attributes.value("NACT_NACK") == "true") {
		filter |= NACT_NACK;
	}
	if (attributes.value("NACT_ACK") == "true") {
		filter |= NACT_ACK;
	}
	if (attributes.value("ACT_NACK") == "true") {
		filter |= ACT_NACK;
	}
	if (attributes.value("ACT_ACK") == "true") {
		filter |= ACT_ACK;
	}
}

void AlarmWindow::show() {
	onshow.exec();
}

void AlarmWindow::hide() {
	onhide.exec();
}

/**
 * Vytvori a vrati pointer na AlarmController, co je trieda dediaca od QWidget.
 * Pri opakovanom volani vracia pointer na uz existujuci objekt tzn. alarmController sa vytvara iba pri prvom volani.
 */
AlarmController const * const AlarmWindow::getAlarmWindowWidget() {
	ACE_INET_Addr addr(port, host.c_str());
	if (addr.is_any()) {
		logger.log(LM_WARNING,"Host %s not resolved.", host.c_str());
	} else {
		for (std::map<AlarmColumn::EType, AlarmColumn*>::iterator it = columns.begin(); it != columns.end(); ++it) {
			if (it->second->section != -1)
				columnVector.push_back(it->second);
		}
		std::sort(columnVector.begin(), columnVector.end(), columnSort);
		if (alarmController == NULL) {
			alarmController = new AlarmController(columnVector, buttonVector, ACE_INET_Addr(port, host.c_str()), source, filter, size.width());
			alarmController->move(position.x(), position.y());
			alarmController->resize(size);
		}
		return alarmController;
	}
	return NULL;
}

void AlarmWindow::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	Symbol::setDebugInfo(debugInfo, parentId);
	onshow.setDebugInfo(this->debugInfo, identification);
	onhide.setDebugInfo(this->debugInfo, identification);
}
