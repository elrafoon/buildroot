/*
 * label.cpp
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#include <QtGui>
#include <QColor>
#include <QString>
#include "suhmicpp/util/profile_timer.h"
#include <sstream>
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/symbols/label.h"

extern WidgetKeyboard *virtualKeyBoard;

Label::Label(const QXmlAttributes &attributes) :
	BaseLabel(attributes), ResultListener(), fontSize(12), boundExpression(this, (ResultListener *) this), onchange(this), text("") {
	obType = obType | LABEL;
	resultType = STRING;
	writeEnabled = attributes.value("writeEnabled") == QString("true");

	lineEdit.setWindowFlags(lineEdit.windowFlags() | Qt::FramelessWindowHint | Qt::Dialog);
	connect(&lineEdit, SIGNAL(editingFinished()), this, SLOT(editingFinished()));
	connect(&lineEdit, SIGNAL(cancelEditing()), this, SLOT(onCancelEditing()));

	identification = Symbol::name;
	onchange.setDebugInfo(debugInfo, identification);
	boundExpression.expression.setDebugInfo(debugInfo, identification);
}

Label::Label(const Label &label): BaseLabel(label), ResultListener(label), writeEnabled(label.writeEnabled), expression(label.expression), fontSize(label.fontSize), boundExpression(label.boundExpression, this, (ResultListener *) this), onchange(label.onchange), text(label.text){
}

Symbol* Label::clone() {
	Label *l = new Label(*this);
	return static_cast<Symbol*> (l);
}

void Label::setFontAttributes(const QXmlAttributes &attributes) {
	BaseLabel::setFontAttributes(attributes);
}

void Label::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Label");
	ProfileTimer t(timerName);
#endif
	painter->setFont(sFont.getQFont());

	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setBrush(brush);
	painter->setPen(pen);

	BaseLabel::paint(painter, option, widget);
	painter->drawText(0, 0, size.width(), size.height(), sFont.flags, QString::fromUtf8(text.c_str()));
}

void Label::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event) {
	if (writeEnabled) {
		virtualKeyBoard->setParent(&lineEdit);
		virtualKeyBoard->setGeometry(position.x(), position.y() + size.height(), size.width(), size.height());
		lineEdit.setGeometry(position.x(), position.y(), size.width(), size.height());
		lineEdit.setText(text.c_str());
		lineEdit.show();
		lineEdit.setFocus();
		virtualKeyBoard->show();
	}
}

void Label::editingFinished() {
	std::string newText = lineEdit.text().toStdString();
	lineEdit.hide();
	virtualKeyBoard->hide();
	onchange.exec(newText);
	update();
}

void Label::onCancelEditing(){
	lineEdit.hide();
	virtualKeyBoard->hide();
}

QPainterPath Label::shape() const {
	QPainterPath path;
	path.addRect(0, 0, size.width(), size.height());
	return path;
}

std::string Label::getText() {
	return text;
}

void Label::setText(std::string text) {
	this->text = text;
	update();
}

void Label::handleResult(std::string result) {
	text.clear();
	text.append(result);
	update();
}

void Label::compileCodes(){
	this->boundExpression.expression.compileCode();
}
