/*
 * visual_symbol.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#include <QApplication>
#include <QList>
#include <QRectF>
#include <QGraphicsView>
#include <QXmlAttributes>
#include <QString>
#include <QGraphicsScene>
#include <QTimer>
#include "suhmicpp/symbols/visual_symbol.h"

VisualSymbol::VisualSymbol() :
		Symbol(), linkList(this), onshow(this), onhide(this), onclick(this), bgBlinkState(true), fgBlinkState(true), horizontalFill(100), verticalFill(100) {
	obType = obType | VISUAL_SYMBOL;
}

VisualSymbol::VisualSymbol(const QXmlAttributes &attributes) :
		Symbol(attributes), linkList(this), onshow(this), onhide(this), onclick(this), bgBlinkState(true), fgBlinkState(true), horizontalFill(100), verticalFill(100), position(0, 0) {
	obType = obType | VISUAL_SYMBOL;
	setRotation(attributes);
	setPos(position);
	setZOrder(attributes.value(QString("zorder")).toInt());
	onclick.setDebugInfo(debugInfo, identification);
	onhide.setDebugInfo(debugInfo, identification);
	onshow.setDebugInfo(debugInfo, identification);
	linkList.setDebugInfo(debugInfo, identification);
	originalSize.setHeight(1);
	originalSize.setWidth(1);
}

VisualSymbol::VisualSymbol(const VisualSymbol &visualSymbol) :
		Symbol(visualSymbol), linkList(visualSymbol.linkList, this), onshow(this), onhide(this), onclick(visualSymbol.onclick, this), bgBlinkState(true), fgBlinkState(true), horizontalFill(100), verticalFill(100) {
	obType = obType | VISUAL_SYMBOL;
	position.setX(visualSymbol.position.x());
	position.setY(visualSymbol.position.y());
	setPos(position);
	size.setHeight(visualSymbol.size.height());
	size.setWidth(visualSymbol.size.width());
	originalSize.setHeight(visualSymbol.originalSize.height());
	originalSize.setWidth(visualSymbol.originalSize.width());
	position.setX(visualSymbol.position.x());
	position.setY(visualSymbol.position.y());
	horizontalFill = visualSymbol.horizontalFill;
	verticalFill = visualSymbol.verticalFill;
	setZOrder(visualSymbol.zOrder);
	//scale = symbol.scale;
	rotCenter = visualSymbol.rotCenter;
	setTransformOriginPoint(mapFromParent(rotCenter));
	setRotation(visualSymbol.rotation);
}

QRectF VisualSymbol::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void VisualSymbol::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
	;
}

void VisualSymbol::setPosition(const QXmlAttributes &attributes) {
	position = QPoint(attributes.value(QString("x")).toFloat(), attributes.value(QString("y")).toFloat());
	setPos(position);
}

/**
 * Sets position of symbol relative to its parent.
 */
void VisualSymbol::setPosition(int x, int y) {
	QPoint pos(x, y);
	position = pos;
	setPos(pos);
}

std::pair<int, int> VisualSymbol::getSize() {
	return std::pair<int, int>(size.width(), size.height());
}

void VisualSymbol::setSize(const QXmlAttributes &attributes) {
	size.setWidth(attributes.value(QString("width")).toFloat());
	size.setHeight(attributes.value(QString("height")).toFloat());
}

/**
 * Nastavi velkost symbolu. Ak su parametre mensie ako 1, normalizuju sa na 1.
 */
void VisualSymbol::setSize(float width, float height) {
	if (width < 1.0)
		width = 1.0;
	if (height < 1.0)
		height = 1.0;
	size.setWidth(width);
	size.setHeight(height);
	prepareGeometryChange();
	update();
}

void VisualSymbol::setRotation(const QXmlAttributes &attributes) {
	rotation = attributes.value(QString("rotation")).toFloat();
}

void VisualSymbol::setRotation(long newValue) {
	VisualSymbol::setRotation((float) newValue);
}

void VisualSymbol::setRotation(float newValue) {
	rotation = newValue;
	QGraphicsItem::setRotation(-rotation);
}

void VisualSymbol::setRotCenter(int x, int y) {
	rotCenter.setX(x);
	rotCenter.setY(y);
	QGraphicsItem::setRotation(0);
	setTransformOriginPoint(mapFromParent(rotCenter));
	QGraphicsItem::setRotation(-rotation);
}

void VisualSymbol::setRotCenter(const QXmlAttributes &attributes) {
	setRotCenter(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt());
}

void VisualSymbol::show() {
	onshow.exec();
}

void VisualSymbol::hide() {
	onhide.exec();
}

void VisualSymbol::setVertPosition(long vPos) {
	position.setY((int) vPos);
	setPos(position);
}

void VisualSymbol::setHorPosition(long hPos) {
	position.setX((int) hPos);
	setPos(position);
}

/**
 * Sets value of fill in horizontal axis and updates symbol.
 * @param value - in percents; for value < 0 will be set to 0 and for value > 100 will be set to 100.
 */
void VisualSymbol::setHorFill(long value) {
	if (value > 100)
		horizontalFill = 100;
	else if (value < 0)
		horizontalFill = 0;
	else
		horizontalFill = (int) value;
	update();
}

/**
 * Sets value of fill in vertical axis and updates symbol.
 * @param value - in percents; for value < 0 will be set to 0 and for value > 100 will be set to 100.
 */
void VisualSymbol::setVertFill(long value) {
	if (value > 100)
		verticalFill = 100;
	else if (value < 0)
		verticalFill = 0;
	else
		verticalFill = (int) value;
	update();
}

void VisualSymbol::setHorSize(long value) {
	size.setWidth((int) value);
	prepareGeometryChange();
}

void VisualSymbol::setVertSize(long value) {
	size.setHeight((int) value);
	prepareGeometryChange();
}

/**
 * Sets the visibility of the object and executes onshow or onhide if visibility changes.
 */
void VisualSymbol::setVisibility(bool visible) {
	setVisible(visible);
	if (visible)
		onshow.exec();
	else
		onhide.exec();
}

std::pair<float, float> VisualSymbol::getScale() {
	return std::pair<float, float>(size.width() / (float) originalSize.width(), size.height() / (float) originalSize.height());
}

void VisualSymbol::setScale(const QXmlAttributes &attributes) {
	float x = attributes.value(QString("x")).toFloat();
	float y = attributes.value(QString("y")).toFloat();

	//Size je v XML uz prepocitany pomerom. Kedze pouzivam transformaciu originalSize aj size nastavujem na povodnu velkost.
	originalSize.setWidth(size.width() / x);
	originalSize.setHeight(size.height() / y);
	size.setWidth(originalSize.width());
	size.setHeight(originalSize.height());
}

void VisualSymbol::setScale(float width, float height) {
	if (width < 0)
		width = 0;
	if (height < 0)
		height = 0;
	setSize((float)originalSize.width() * width, (float)originalSize.height() * height);
}

void VisualSymbol::setZOrder(int zOrder) {
	this->zOrder = zOrder;
	setZValue(zOrder);
}

void VisualSymbol::mousePressEvent(QGraphicsSceneMouseEvent * event) {
	onclick.exec();
	update();
	event->ignore();
}

void VisualSymbol::changeBgBlinkState() {
	bgBlinkState = !bgBlinkState;
	update();
}

void VisualSymbol::changeFgBlinkState() {
	fgBlinkState = !fgBlinkState;
	update();
}

/**
 * Finalization of the symbol. It's called when closing tag in XML is reached.
 */
void VisualSymbol::fini() {
	Symbol::fini();
	setRotation(rotation);
	onclick.handlerCode.compileCode();
	onshow.handlerCode.compileCode();
	onhide.handlerCode.compileCode();
}

void VisualSymbol::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	Symbol::setDebugInfo(debugInfo, parentId);
	linkList.setDebugInfo(this->debugInfo, identification);
	onshow.setDebugInfo(this->debugInfo, identification);
	onhide.setDebugInfo(this->debugInfo, identification);
	onclick.setDebugInfo(this->debugInfo, identification);
}
