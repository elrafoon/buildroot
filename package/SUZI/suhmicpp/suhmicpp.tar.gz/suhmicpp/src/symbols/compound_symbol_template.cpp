/*
 * compound_symbol.cpp
 *
 *  Created on: Jul 14, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QString>
#include "suhmicpp/symbols/compound_symbol_template.h"

CompoundSymbolTemplate::CompoundSymbolTemplate(){
	this->className = QString("NoClassName");
}

CompoundSymbolTemplate::~CompoundSymbolTemplate(){
	for(std::vector<Symbol*>::iterator it = symbol.begin(); it!=symbol.end(); ++it){
		delete *it;
	}
	symbol.clear();
}

CompoundSymbolTemplate::CompoundSymbolTemplate(QString className){
	this->className = className;
}

CompoundSymbolTemplate::CompoundSymbolTemplate(const QXmlAttributes & attributes){
	this->className = attributes.value(QString("className"));
}

CompoundSymbolTemplate::CompoundSymbolTemplate(CompoundSymbolTemplate &compoundSymbolTemplate){
	this->className = compoundSymbolTemplate.className;
}
