/*
 * simple_visual_symbol.cpp
 *
 *  Created on: Jul 8, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QString>
#include <QColor>
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/util/util.h"

SimpleVisualSymbol::SimpleVisualSymbol(const QXmlAttributes &attributes) :
	VisualSymbol(attributes), lineWidth(1), pen(Qt::SolidPattern, lineWidth, Qt::SolidLine, Qt::SquareCap, Qt::BevelJoin) {
	obType = obType | SIMPLE_VISUAL_SYMBOL;
	fgColor.setNamedColor(attributes.value("fgColor"));
	fgStyle = Util::stringToFgStyle(attributes.value("fgStyle").toStdString());
	bgColor.setNamedColor(attributes.value("bgColor"));
	bgStyle = Util::stringToBgStyle(attributes.value("bgStyle").toStdString());
	lineWidth = attributes.value("lineWidth").toFloat();
	pen.setJoinStyle(Qt::MiterJoin);
	pen.setColor(fgColor);
	pen.setWidth(lineWidth * 2);
	pen.setStyle(fgStyle);

	brush.setColor(bgColor);
	brush.setStyle(bgStyle);
}

SimpleVisualSymbol::SimpleVisualSymbol(const SimpleVisualSymbol &svs) :
	VisualSymbol(svs) {
	obType = obType | SIMPLE_VISUAL_SYMBOL;
	fgColor.setRgba(svs.fgColor.rgba());
	fgStyle = svs.fgStyle;
	bgColor.setRgba(svs.bgColor.rgba());
	bgStyle = svs.bgStyle;
	lineWidth = svs.lineWidth;
	pen.setJoinStyle(Qt::MiterJoin);
	pen.setColor(fgColor);
	pen.setWidth(lineWidth * 2);
	pen.setStyle(fgStyle);

	brush.setColor(bgColor);
	brush.setStyle(bgStyle);
}

QRectF SimpleVisualSymbol::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

/**
 * Nastavi sirku ciary na lineWidth a pero na 2*lineWidth.
 */
void SimpleVisualSymbol::setLineWidth(int lineWidth) {
	this->lineWidth = lineWidth;
	pen.setWidth(lineWidth * 2);
	update();
}

/**
 * Nastavi farbu pozadia podla color. Pozri QColor:setNamedColor.
 */
void SimpleVisualSymbol::setBgColor(std::string color) {
	bgColor.setNamedColor(QString(color.c_str()));
	brush.setColor(bgColor);
	update();
}

/**
 * Nastavi farbu popredia podla color. Pozri QColor:setNamedColor.
 */
void SimpleVisualSymbol::setFgColor(std::string color) {
	fgColor.setNamedColor(QString(color.c_str()));
	update();
}

int SimpleVisualSymbol::getFgStyle() const{
	switch (fgStyle) {
		case Qt::SolidLine:
			return 0;
		case Qt::DashLine:
			return 1;
		case Qt::DotLine:
			return 2;
		case Qt::DashDotLine:
			return 3;
		default:
			return 0;
	}
}

void SimpleVisualSymbol::setFgStyle(int style) {
	switch (style) {
	case 0:
		fgStyle = Qt::SolidLine;
		break;
	case 1:
		fgStyle = Qt::DashLine;
		break;
	case 2:
		fgStyle = Qt::DotLine;
		break;
	case 3:
		fgStyle = Qt::DashDotLine;
		break;
	default:
		fgStyle = Qt::SolidLine;
		break;
	}
	pen.setStyle(fgStyle);
	update();
}

int SimpleVisualSymbol::getBgStyle() const{
	switch (bgStyle) {
		case Qt::SolidPattern:
			return 0;
		case Qt::NoBrush:
			return 1;
		default:
			return 0;
	}
	return 0;
}

void SimpleVisualSymbol::setBgStyle(int style){
	switch (style) {
	case 0:
		bgStyle = Qt::SolidPattern;
		break;
	case 1:
		bgStyle = Qt::NoBrush;
		break;
	default:
		bgStyle = Qt::SolidPattern;
		break;
	}
	brush.setStyle(bgStyle);
	update();
}

void SimpleVisualSymbol::setFgColor(int r, int g, int b, int a) {
	fgColor.setRgb(r, g, b, a);
	pen.setColor(fgColor);
	update();
}

void SimpleVisualSymbol::setBgColor(int r, int g, int b, int a) {
	bgColor.setRgb(r, g, b, 255);
	brush.setColor(bgColor);
	update();
}

void SimpleVisualSymbol::setSize(int width, int height) {
	VisualSymbol::setSize(width, height);
}
