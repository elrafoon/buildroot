/*
 * value_display.cpp
 *
 *  Created on: Oct 22, 2010
 *      Author: vlado
 */

#include <QRegExpValidator>
#include <QRegExp>
#include <QColor>
#include <QString>
#include "suhmicpp/util/profile_timer.h"
#include <scl/hlapi/data_writer.h>
#include "suhmicpp/connector_instance.h"
#include "suhmicpp/symbols/value_display.h"

extern SuhubConnectorLight::Connector *con;
extern WidgetKeyboard *virtualKeyBoard;

ValueDisplay::ValueDisplay(const QXmlAttributes &attributes) :
	BaseLabel(attributes), value(0), valueLink(this), tag(NULL), precision(2), logger("Value Display: ") {
	obType = obType | VALUE_DISPLAY;
	writeEnabled = attributes.value("writeEnabled") == QString("true");
	tagName = attributes.value("tagName");
	precision = attributes.value("precision").toUInt();
	if (attributes.value("scientific") == "true")
		scientific = true;
	else
		scientific = false;

	connect(&lineEdit, SIGNAL(editingFinished()), this, SLOT(editingFinished()));
	connect(&lineEdit, SIGNAL(cancelEditing()), this, SLOT(onCancelEditing()));
	lineEdit.setValidator(new QRegExpValidator(QRegExp("\\d*"), NULL));
	lineEdit.setWindowFlags(lineEdit.windowFlags() | Qt::FramelessWindowHint | Qt::Dialog);
}

ValueDisplay::ValueDisplay(const ValueDisplay &vd) :
	BaseLabel(vd), tagName(vd.tagName), writeEnabled(vd.writeEnabled), valueLink(vd.valueLink, this), value(vd.value), lineEdit(vd.lineEdit), tag(vd.tag), precision(vd.precision), scientific(vd.scientific), logger("Value Display: ") {
	valueLink.setTag(tag);
	connect(&lineEdit, SIGNAL(editingFinished()), this, SLOT(editingFinished()));
	connect(&lineEdit, SIGNAL(cancelEditing()), this, SLOT(onCancelEditing()));
	lineEdit.setValidator(new QRegExpValidator(QRegExp("\\d*"), NULL));
	lineEdit.setWindowFlags(lineEdit.windowFlags() | Qt::FramelessWindowHint | Qt::Dialog);
}

Symbol* ValueDisplay::clone() {
	ValueDisplay *v = new ValueDisplay(*this);
	return static_cast<Symbol*>(v);
}

void ValueDisplay::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("ValueDisplay");
	ProfileTimer t(timerName);
#endif
	painter->setFont(sFont.getQFont());

	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setPen(pen);
	painter->setBrush(brush);

	BaseLabel::paint(painter, option, widget);
	formatValue(buff);
	painter->drawText(0, 0, size.width(), size.height(), sFont.flags, buff);
}

/**
 * Zobrazi virtualnu klavesnicu na pozici ValueDisplaya.
 */
void ValueDisplay::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event) {
	if (writeEnabled) {
		logger.log(LM_DEBUG, "Posuvam LineEdit na: %d %d", position.x(), position.y());
		lineEdit.setGeometry(position.x(), position.y(), size.width(), size.height());
		virtualKeyBoard->setParent(&lineEdit);
		virtualKeyBoard->setGeometry(position.x(), position.y() + size.height(), size.width(), size.height());
		lineEdit.show();
		lineEdit.setFocus();
		virtualKeyBoard->show();
	}
}

void ValueDisplay::setValue(double value) {
	logger.log(LM_DEBUG, "setValue: %lf", value);
	this->value = value;
	update();
}

/**
 * Schova klavesnicu a zapise hodnotu do suhubu s aktualnym casom.
 */
void ValueDisplay::editingFinished() {
	//value = lineEdit->toPlainText().toInt();
	value = lineEdit.text().toInt();
	lineEdit.hide();
	virtualKeyBoard->hide();
	SuhubConnectorLight::DataWriter dw(con);
	SuhubConnectorLight::VTQ vtq;
	vtq.v = value;
	vtq.t = time(NULL);
	vtq.q = 192;
	dw.updateByPointer(tag, vtq);
	update();
}

std::string ValueDisplay::getTagName() {
	return tagName.toStdString();
}

void ValueDisplay::setTag(SuhubConnectorLight::StatefulTag *tag) {
	this->tag = tag;
	valueLink.setTag(tag);
}

/**
 * Zrusenie editacie, schova klavesnicu bez zapisu hodnoty.
 */
void ValueDisplay::onCancelEditing() {
	lineEdit.hide();
	virtualKeyBoard->hide();
}

/**
 * Naformatuje do \a buff hodnotu podla nastaveni \a precision a \a scientific.
 */
void ValueDisplay::formatValue(char * const buff) const {
	if (precision == 0)
		sprintf(buff, "%d", (int)value); // je to urobene takto lebo "%.0f" vypisuje aj bodku
	else {
		if (scientific)
			sprintf(buff, "%#.*e", precision, value);
		else
			sprintf(buff, "%#.*f", precision, value);
	}
}
