/*
 * label.cpp
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#include <QColor>
#include <QString>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/static_label.h"

StaticLabel::StaticLabel(const QXmlAttributes &attributes) : BaseLabel(attributes){
	obType = obType | STATIC_LABEL;
	text = attributes.value("text").toUtf8().data();
}

Symbol* StaticLabel::clone(){
	StaticLabel *s = new StaticLabel(*this);
	return static_cast<Symbol*>(s);
}

void StaticLabel::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("StaticLabel");
	ProfileTimer t(timerName);
#endif
	//painter->drawRect(boundingRect());
	painter->setFont(sFont.getQFont());

	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setPen(pen);
	painter->setBrush(brush);

	BaseLabel::paint(painter, option, widget);
	painter->drawText(0, 0, size.width(),size.height(), sFont.flags, QString::fromUtf8(text.c_str()));
}

std::string StaticLabel::getText(){
	return text;
}
void StaticLabel::setText(std::string text){
	this->text = text;
	update();
}
