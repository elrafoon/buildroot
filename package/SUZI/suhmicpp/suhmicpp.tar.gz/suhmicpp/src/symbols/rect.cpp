/*
 * Rect.cpp
 *
 *  Created on: Jun 25, 2010
 *      Author: vlado
 */

#include <QtGui>
#include <QXmlAttributes>
#include <QGraphicsScene>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/rect.h"
#include "suhmicpp/symbols/simple_visual_symbol.h"


Rect::Rect(const QXmlAttributes &attributes) :
	SimpleVisualSymbol(attributes) {
	obType = obType | RECT;
}

Rect::Rect(const Rect &rect) :
	SimpleVisualSymbol(rect) {
}

Symbol* Rect::clone() {
	Rect *r = new Rect(*this);
	return static_cast<Symbol*>(r);
}

QRectF Rect::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void Rect::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Rectangle");
	ProfileTimer t(timerName);
#endif
#ifdef ANTIALIASING
	painter->setRenderHint(QPainter::Antialiasing);
#endif
	//vypln
	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	painter->setBrush(brush);

	QPainterPath outline;
	outline.addRect(0, 0, size.width(), size.height());

	QPainterPath vertical;
	vertical.addRect(lineWidth, lineWidth, size.width() - 2 * lineWidth, (size.height() - 2 * lineWidth) * ((1 - verticalFill / 100.0)));

	QPainterPath horizontal;
	horizontal.addRect(lineWidth + (size.width() - 2 * lineWidth) * (horizontalFill / 100.0), lineWidth, (size.width() - 2 * lineWidth) * ((100 - horizontalFill) / 100.0), size.height()
			- 2 * lineWidth);

	painter->setClipPath(outline - (horizontal + vertical));
	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setPen(pen);
	painter->drawRect(0, 0, size.width(), size.height());
}

QPainterPath Rect::shape() const {
	QPainterPath path;
	path.addRect(0, 0, size.width(), size.height());
	return path;
}

