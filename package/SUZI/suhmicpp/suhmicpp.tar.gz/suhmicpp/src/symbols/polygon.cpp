/*
 * polygon.cpp
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#include <vector>
#include <math.h>
#include <QtGui>
#include <QXmlAttributes>
#include <QColor>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/polygon.h"

Polygon::Polygon(const QXmlAttributes &attributes) :
		SimpleVisualSymbol(attributes), logger("Polygon: ") {
	obType = obType | POLYGON;
}

Symbol* Polygon::clone() {
	Polygon *p = new Polygon(*this);
	p->fini();
	return static_cast<Symbol*>(p);
}

QRectF Polygon::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

/**
 * Vrati usecku paralelnu s useckou zadanou bodmi p1, p2, vo vzdialenosti lineWidth*2.
 */
std::pair<QPointF, QPointF> Polygon::getInnerLine(QPointF &p1, QPointF &p2) {
	float vectX = p1.x() - p2.x();
	float vectY = p1.y() - p2.y();
	float vectSize = sqrt((vectX * vectX) + (vectY * vectY));

	float tmp = vectX;
	vectX = vectY;
	vectY = -tmp;

	if (path.contains(QPointF(((p1.x() + p2.x()) / 2.0) + (vectX / vectSize), ((p1.y() + p2.y()) / 2.0) + (vectY / vectSize)))) {
		logger.log(LM_DEBUG, "Polygon OBSAHUJE bod");
		vectX = (vectX / vectSize) * lineWidth * 2;
		vectY = (vectY / vectSize) * lineWidth * 2;
		return std::pair < QPointF, QPointF > (QPointF(p1.x() + vectX / 2.0, p1.y() + vectY / 2.0), QPointF(p2.x() + vectX / 2.0, p2.y() + vectY / 2.0));
	} else {
		logger.log(LM_DEBUG, "Polygon NEOBSAHUJE bod");
		vectX = (vectX / vectSize) * lineWidth * 2;
		vectY = (vectY / vectSize) * lineWidth * 2;
		return std::pair < QPointF, QPointF > (QPointF(p1.x() - vectX / 2.0, p1.y() - vectY / 2.0), QPointF(p2.x() - vectX / 2.0, p2.y() - vectY / 2.0));
	}
}

/**
 * Do argumentu intersect nastavi bod, v ktorom sa pretinaju priamky dane bodmi (x1, y1, x2, y2) a (x3, y3, x4, y4).
 * \retval 0 ak nasiel priesecnik
 * \retval -1 ak su priamky paralelne
 */
int Polygon::intersection(QPointF &intersect, int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
	int denominator = ((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4));
	if (denominator == 0)
		return -1;
	int xi = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denominator;
	int yi = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denominator;
	intersect.setX(xi);
	intersect.setY(yi);
	return 0;
}

void Polygon::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Polygon");
	ProfileTimer t(timerName);
#endif
#ifdef ANTIALIASING
	painter->setRenderHint(QPainter::Antialiasing);
#endif

	//painter->drawRect(innerRectangle);

	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}

	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setBrush(brush);
	painter->setPen(pen);

	QPainterPath verticalPath;
	verticalPath.addRect(innerRectangle.x(), innerRectangle.y(), innerRectangle.width(), innerRectangle.height() * (1 - verticalFill / 100.0));
	QPainterPath horizonallPath;
	horizonallPath.addRect(innerRectangle.x() + innerRectangle.width() * (horizontalFill / 100.0), innerRectangle.y(), innerRectangle.width() * (1 - horizontalFill / 100.0), innerRectangle.height());

	painter->setClipPath(path - (innerPath & (verticalPath + horizonallPath)));
	painter->drawPath(path);
}

QPainterPath Polygon::shape() const {
	return path;
}

/**
 * Nastavi innerPath a path.
 */
void Polygon::fini() {
	VisualSymbol::fini();
	const QPainterPath emptyPath;
	path = emptyPath;
	innerPath = emptyPath;
	xs.clear();
	ys.clear();
	int i = 0;
	for (std::vector<QPointF>::iterator p = vertexes.begin(); p < vertexes.end(); p++) {
		if (i == 0)
			path.moveTo(QPoint((*p).x(), (*p).y()));
		path.lineTo(QPoint((*p).x(), (*p).y()));
		logger.log(LM_DEBUG, "Polygon: %d %d", (*p).x(), (*p).y());
		i++;
	}
	path.closeSubpath();

	//innerPath.moveTo(*(vertexes.begin()));
	unsigned int s = vertexes.size();
	//for (p = vertexes.begin(); p < vertexes.end() - 1; p++){
	for (int i = 0; i < s; i++) {
		std::pair<QPointF, QPointF> line = getInnerLine(vertexes[i % s], vertexes[(i + 1) % s]);
		std::pair<QPointF, QPointF> line2 = getInnerLine(vertexes[(i + 1) % s], vertexes[(i + 2) % s]);
		QPointF intersect;
		if (intersection(intersect, line.first.x(), line.first.y(), line.second.x(), line.second.y(), line2.first.x(), line2.first.y(), line2.second.x(), line2.second.y()) != -1) {
			if (i == 0)
				innerPath.moveTo(intersect);
			else
				innerPath.lineTo(intersect);
			logger.log(LM_DEBUG, "Intersect: %d %d", intersect.x(), intersect.y());
			xs.push_back(intersect.x());
			ys.push_back(intersect.y());
		} else {
			logger.log(LM_DEBUG, "Priamky su paralelne. Nepridavam bod.");
		}
	}
	innerPath.closeSubpath();

	int maxX = 0;
	int minX = 0;
	int maxY = 0;
	int minY = 0;

	std::vector<int>::iterator it;
	it = std::max_element(xs.begin(), xs.end());
	if(it != xs.end())
		maxX = *it;
	it = std::min_element(xs.begin(), xs.end());
	if(it != xs.end())
		minX = *it;
	it = std::max_element(ys.begin(), ys.end());
	if(it != xs.end())
		maxY = *it;
	it = std::min_element(ys.begin(), ys.end());
	if(it != xs.end())
		minY = *it;

	innerRectangle.setBottomRight(QPoint(maxX, maxY));
	innerRectangle.setTopLeft(QPoint(minX, minY));
}

/**
 * Prida bod obsiahnuty v attributes do vektoru vertexes a originalVertexes.
 */
void Polygon::addVertex(const QXmlAttributes &attributes) {
	vertexes.push_back(QPoint(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt()));
	originalVertexes.push_back(QPoint(attributes.value(QString("x")).toInt(), attributes.value(QString("y")).toInt()));
}

/**
 * Premapuje vrcholy polygonu, tak aby sa vosli do opisaneho obdlznika so sirkou width a vyskou height.
 */
void Polygon::setSize(int width, int height) {
	SimpleVisualSymbol::setSize(width, height);
	QMatrix4x4 matrix;
	logger.log(LM_DEBUG, "Original size: %d %d", originalSize.width(), originalSize.height());
	logger.log(LM_DEBUG, "Ratio: %f", float(width) / originalSize.width());
	matrix.scale(float(width) / originalSize.width(), float(height) / originalSize.height());
	std::vector<QPointF>::iterator it;
	std::vector<QPointF>::iterator jt;
	for (it = originalVertexes.begin(), jt = vertexes.begin(); jt != vertexes.end(); ++it, ++jt) {
		*jt = matrix.map(*it);
	}
	fini();
	update();
}

/**
 * Nastavi velkost opisaneho obdlznika tak, ze sirku zachova a vysku nastavi na zadanu.
 * \see void Polygon::setSize(int width, int height)
 */
void Polygon::setHorSize(long value) {
	setSize(value, size.height());
}

/**
 * Nastavi velkost opisaneho obdlznika tak, ze vysku zachova a sirku nastavi na zadanu.
 * \see void Polygon::setSize(int width, int height)
 */
void Polygon::setVertSize(long value) {
	setSize(size.width(), value);
}

