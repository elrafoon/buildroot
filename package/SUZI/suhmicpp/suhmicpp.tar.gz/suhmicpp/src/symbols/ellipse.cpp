/*
 * ellipse.cpp
 *
 *  Created on: Jul 9, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/symbols/ellipse.h"

Ellipse::Ellipse(const QXmlAttributes &attributes) :
	SimpleVisualSymbol(attributes) {
	obType = obType | ELLIPSE;
}

Symbol* Ellipse::clone() {
	Ellipse *e = new Ellipse(*this);
	return static_cast<Symbol*>(e);
}

QRectF Ellipse::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void Ellipse::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
#ifdef PROFILE_TIMER
	std::string timerName("Ellipse");
	ProfileTimer t(timerName);
#endif
#ifdef ANTIALIASING
	painter->setRenderHint(QPainter::Antialiasing);
#endif

	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setBrush(brush);
	painter->setPen(pen);

	QPainterPath okraj, vnutro, vertical, horizontal;
	okraj.addEllipse(0, 0, size.width(), size.height());
	vnutro.addEllipse(lineWidth, lineWidth, size.width() - 2 * lineWidth, size.height() - 2 * lineWidth);
	vertical.addRect(0, 0, size.width(), lineWidth + (size.height() - 2 * lineWidth) * (1 - verticalFill/100.0) );
	horizontal.addRect(lineWidth + (size.width()-2*lineWidth) * (horizontalFill /100.0),
			0,
			(size.width() - 2*lineWidth)*(1 - horizontalFill/100.0),
			size.height());
	painter->setClipPath(okraj - (vnutro & (vertical + horizontal)));

	painter->drawEllipse(0, 0, size.width(), size.height());
}

QPainterPath Ellipse::shape() const {
	QPainterPath path;
	//path.addEllipse(position.x(), position.y(), size.width(), size.height());
	path.addEllipse(0, 0, size.width(), size.height());
	return path;
}

