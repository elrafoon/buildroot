/*
 * compund_symbol_ref.cpp
 *
 *  Created on: Jul 14, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QPainter>
#include <QRectF>
#include <QPainterPath>
#include <map>
#include "suhmicpp/symbols/compound_symbol.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/symbols/value_display.h"
#include "suhmicpp/xml/xml_reader.h"

CompoundSymbol::CompoundSymbol(const QXmlAttributes &attributes, CompoundSymbolTemplate *compoundSymbolTemplate, BoundExpressionsPtrs &boundExpressionsPtrs, ScriptPtrs &scriptPtrs, ValueLinkPtrs &valueLinkPtrs, BlinkLinksSet &blinkLinks) :
		VisualSymbol(attributes), PrefixedLogger("CompoundSymbol: ") {
	setFlags(flags() | QGraphicsItem::ItemClipsToShape | QGraphicsItem::ItemClipsChildrenToShape);
	obType = obType | COMPOUND_SYMBOL;
	this->compoundSymbolTemplate = compoundSymbolTemplate;
	init(compoundSymbolTemplate, boundExpressionsPtrs, scriptPtrs, valueLinkPtrs, blinkLinks);
}

void CompoundSymbol::init(CompoundSymbolTemplate *compoundSymbolTemplate, BoundExpressionsPtrs &boundExpressionsPtrs, ScriptPtrs &scriptPtrs, ValueLinkPtrs &valueLinkPtrs, BlinkLinksSet &blinkLinks) {
	for (std::vector<Symbol*>::iterator it = this->compoundSymbolTemplate->symbol.begin(); it < this->compoundSymbolTemplate->symbol.end(); ++it) {
		Symbol *symbol = (*it)->clone();
		if (symbol->obType & VISUAL_SYMBOL) {
			VisualSymbol *newVS = static_cast<VisualSymbol *>(symbol);
			VisualSymbol *origVS = static_cast<VisualSymbol *>(*it);
			blinkLinks.erase(&origVS->linkList.bgBlinkLink);
			blinkLinks.erase(&origVS->linkList.fgBlinkLink);

			blinkLinks.insert(&newVS->linkList.bgBlinkLink);
			blinkLinks.insert(&newVS->linkList.fgBlinkLink);

			boundExpressionsPtrs.push_back(&newVS->linkList.bgBlinkLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.fgBlinkLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.bgColorLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.fgColorLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.horizontalFillLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.horizontalPositionLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.horizontalSizeLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.verticalFillLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.verticalSizeLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.rotationLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.verticalPositionLink.boundExpression);
			boundExpressionsPtrs.push_back(&newVS->linkList.visibilityLink.boundExpression);

			if ((*it)->obType & LABEL) {
				Label *label = static_cast<Label*>(symbol);
				boundExpressionsPtrs.push_back(&label->boundExpression);
			}

			if ((*it)->obType & VALUE_DISPLAY) {
				ValueDisplay *vd = static_cast<ValueDisplay*>(symbol);
				valueLinkPtrs.push_back(&vd->valueLink);
			}
			newVS->setParentItem(this);
		}

		typedef std::vector<GenericScript *> GenericScriptVector;
		for (GenericScriptVector::iterator it = symbol->genericScriptList.genericScript.begin(); it != symbol->genericScriptList.genericScript.end(); ++it) {
			scriptPtrs.push_back(&(*it)->script);
		}

		assert(symbol != NULL);
		if (symbol != NULL) {
			symbols.push_back(symbol);
		}
	}
}

Symbol* CompoundSymbol::clone() {
	return NULL;
}

QRectF CompoundSymbol::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void CompoundSymbol::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
	QList<QGraphicsItem *> children = QGraphicsItem::childItems();
	for (int i = 0; i < children.size(); ++i) {
		children.at(i)->setVisible(bgBlinkState);
	}
}

QPainterPath CompoundSymbol::shape() const {
	QPainterPath path;
	path.addRect(0, 0, size.width(), size.height());
	return path;
}

void CompoundSymbol::setReplacementTable(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable) {
	this->replacementTable = replacementTable;

	log(LM_DEBUG,"Replecement table:");
	std::map<std::string, SuhubConnectorLight::StatefulTag *>::iterator jt;
	for (jt = replacementTable.begin(); jt != replacementTable.end(); ++jt) {
		log(LM_DEBUG,"%s => %s", (*jt).first.c_str(), (*jt).second->name.c_str());
	}

	std::vector<Symbol*>::iterator it;
	for (it = symbols.begin(); it < symbols.end(); ++it) {
		if ((*it)->obType & VISUAL_SYMBOL) {
			VisualSymbol *vs = static_cast<VisualSymbol *>(*it);
			vs->linkList.replaceTags(replacementTable);
			vs->onshow.setReplacementTable(replacementTable);
			vs->onhide.setReplacementTable(replacementTable);
			vs->onclick.setReplacementTable(replacementTable);
		}
		(*it)->genericScriptList.setReplacementTable(replacementTable);
		(*it)->oncreate.setReplacementTable(replacementTable);
		(*it)->ondestroy.setReplacementTable(replacementTable);
		if ((*it)->obType & LABEL) {
			Label *label = static_cast<Label *>(*it);
			label->boundExpression.replaceTags(replacementTable);
		}
		if ((*it)->obType & VALUE_DISPLAY) {
			ValueDisplay *valueDisplay = static_cast<ValueDisplay *>(*it);
			std::map<std::string, SuhubConnectorLight::StatefulTag *>::const_iterator it = replacementTable.find(valueDisplay->getTagName());
			if (it != replacementTable.end())
				valueDisplay->setTag(it->second);
		}

	}
}

void CompoundSymbol::setBgColor(std::string color) {
}
void CompoundSymbol::setFgColor(std::string color) {
}

void CompoundSymbol::fini() {
	//linkList
	log(LM_TRACE,"fini");
	VisualSymbol::fini();
	for (std::vector<Symbol*>::iterator it = symbols.begin(); it < symbols.end(); ++it) {
		if ((*it)->obType & VISUAL_SYMBOL) {
			VisualSymbol* vs = static_cast<VisualSymbol *>(*it);
			vs->linkList.compileCodes();
		}
		(*it)->genericScriptList.compileCodes();
		if ((*it)->obType & LABEL) {
			Label *label = static_cast<Label *>(*it);
			label->compileCodes();
		}
		if ((*it)->obType & TIMER) {
			Timer *timer = static_cast<Timer *>(*it);
			timer->compileCodes();
		}

		(*it)->fini();
	}
}

std::pair<float, float> CompoundSymbol::getScale() {
	return std::pair<float, float>(transform().m11(), transform().m22());
}

void CompoundSymbol::setScale(const QXmlAttributes &attributes) {
	VisualSymbol::setScale(attributes);

	float x = attributes.value(QString("x")).toFloat();
	float y = attributes.value(QString("y")).toFloat();

	((QGraphicsItem *) this)->setTransform(QTransform::fromScale(x, y), false);
}

void CompoundSymbol::setScale(float width, float height) {
	if (width < 0)
		width = 0;
	if (height < 0)
		height = 0;
	((QGraphicsItem *) this)->setTransform(QTransform::fromScale(width, height), false);
}

std::pair<int, int> CompoundSymbol::getSize() {
	return std::pair<int, int>(size.width() * transform().m11(), size.height() * transform().m22());
}

void CompoundSymbol::setSize(int width, int height) {
	if (width < 0)
		width = 0;
	if (height < 0)
		height = 0;
	VisualSymbol::setSize(width, height);
	setScale(width / (float) originalSize.width(), height / (float) originalSize.height());
}

void CompoundSymbol::setHorSize(long width) {
	setSize(width, size.height());
}

void CompoundSymbol::setVertSize(long height) {
	setSize(size.width(), height);
}

void CompoundSymbol::create() {
	VisualSymbol::create();
	for (std::vector<Symbol*>::iterator it = symbols.begin(); it != symbols.end(); ++it) {
		(*it)->create();
	}
}
