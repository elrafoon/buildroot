/*
 * suzi_view.cpp
 *
 *  Created on: Jul 5, 2010
 *      Author: vlado
 */

#include <QtGui>
#include <QtDebug>
#include "suhmicpp/view.h"


View::View(QGraphicsScene *scene, QWidget *parent) : QGraphicsView(scene, parent){
	setOptimizationFlag(QGraphicsView::DontAdjustForAntialiasing, true);
	setSceneRect(0,0, size().width(), size().height());
	setResizeAnchor(QGraphicsView::NoAnchor);
	setTransformationAnchor(QGraphicsView::NoAnchor);
	setViewportUpdateMode(QGraphicsView::FullViewportUpdate);
}

void View::resizeEvent ( QResizeEvent * event ){
	setSceneRect(0,0, event->size().width(), event->size().height());
	updateSceneRect(QRectF(0,0, event->size().width(), event->size().height()));
	invalidateScene(QRectF(0,0, event->size().width(), event->size().height()));
}
