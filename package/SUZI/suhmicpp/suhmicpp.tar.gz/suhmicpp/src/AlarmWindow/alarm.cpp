#include "suhmicpp/AlarmWindow/alarm.h"
#include "suhmicpp/AlarmWindow/alarmgroup.h"
#include "suhmicpp/AlarmWindow/alarmcondition.h"

Alarm::Alarm(QObject *parent) :
    QObject(parent)
{
}

Alarm::Alarm(bool autoAck, QString joinOp, QString desc, int id, QString name, int parentGroupId, int priority, AlarmGroup * parentGroup)
{
        this->autoAck = autoAck;
        this->conditionJoinOp = joinOp;
        this->description = desc;
        this->id = id;
        this->name = name;
        this->parentGroupId = parentGroupId;
        this->priority = priority;
        this->parentGroup = parentGroup;
        this->effectivePriority = -1;
        this->state = NULL;
}

void Alarm::setActiveParam(int effectivePriority,QString state, QTime updTime, QDate updDate)
{
        this->effectivePriority = effectivePriority;
        if(this->state != NULL)
                delete this->state;
        this->state = new QString(state);
        this->tLatestUpdateDate = updDate;
        this->tLatestUpdateTime = updTime;
}

Alarm::~Alarm()
{
        if(state != NULL)
                delete state;
        QMap<int,AlarmCondition *>::iterator it;
        for(it = this->childConditions.begin(); it!= childConditions.end(); ++it)
                delete it.value();
}

bool Alarm::getAutoAck()
{
        return autoAck;
}

int  Alarm::getId()
{
        return id;
}

int  Alarm::getParenGroupId()
{
        return parentGroupId;
}

int  Alarm::getPriority()
{
        return priority;
}

int  Alarm::geteffectivePriority()
{
        return effectivePriority;
}

QString Alarm::getConditionJoinOp()
{
        return conditionJoinOp;
}

QString Alarm::getDescription()
{
        return description;
}

QString Alarm::getName()
{
        return name;
}

QString * Alarm::getState()
{
        return state;
}

QTime Alarm::getTLatestUpdateTime()
{
        return tLatestUpdateTime;
}

QDate Alarm::getTLatestUpdateDate()
{
        return tLatestUpdateDate;
}

AlarmGroup * Alarm::getParentGroup()
{
        return parentGroup;
}

void Alarm::insertChildAlarmCond(int id, AlarmCondition * cn)
{
        this->childConditions.insert(id,cn);
}

QString Alarm::getConditionString()
{
        QString str;
        QMap<int,AlarmCondition *>::iterator it;
        for(it = this->childConditions.begin(); it!= childConditions.end(); ++it)
                str.append(it.value()->getConditionFormatted()).append(" ").append(getConditionJoinOp()).append(" ");
        str.truncate(str.size() - 4);
        return str;
}
