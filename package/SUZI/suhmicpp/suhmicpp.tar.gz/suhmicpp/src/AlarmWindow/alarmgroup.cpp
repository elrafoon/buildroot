#include "suhmicpp/AlarmWindow/alarmgroup.h"
#include "suhmicpp/AlarmWindow/alarm.h"

AlarmGroup::AlarmGroup(QObject *parent) :
    QObject(parent)
{
}

AlarmGroup::AlarmGroup(bool autoAck, QString desc, int id, QString name, int parentId, AlarmGroup * parentGroup)
{
        this->autoAck = autoAck;
        this->description = desc;
        this->id = id;
        this->name = name;
        this->parentGroupId = parentId;
        this->parentGroup = parentGroup;
        this->worstAlarmEfectivePriority = "";
        this->worstAlarmId = "";
        this->worstAlarmState = "";
}

void AlarmGroup::setActiveParam(QString worstAlarmEfPrio, QString worstAlarmId, QString worstAlarmState)
{
        this->worstAlarmEfectivePriority = worstAlarmEfPrio;
        this->worstAlarmId = worstAlarmId;
        this->worstAlarmState = worstAlarmState;
}

int AlarmGroup::getAlarmsCount() const
{
        int count = 0;
        if(this->childGroups.isEmpty())
                return this->childAlarms.count();

        QMap<int,AlarmGroup *>::const_iterator it;

        for( it = this->childGroups.constBegin(); it != this->childGroups.constEnd(); ++it){
                count += it.value()->getAlarmsCount();
        }
        return count + this->childAlarms.count();

}

QMap<int,Alarm *> * AlarmGroup::getAlarms()
{
        return &childAlarms;
}

QMap<int,AlarmGroup *> * AlarmGroup::getChildGroups()
{
        return &childGroups;
}

bool AlarmGroup::getAutoAck()
{
        return autoAck;
}

int  AlarmGroup::getParentGroupId()
{
        return parentGroupId;
}

QString  AlarmGroup::getWorstAlarmEffectivePriority()
{
        return worstAlarmEfectivePriority;
}

QString  AlarmGroup::getworstAlarmId()
{
        return worstAlarmId;
}

int  AlarmGroup::getId()
{
        return id;
}

QString AlarmGroup::getDescription()
{
        return description;
}

QString AlarmGroup::getName()
{
        return name;
}

QString AlarmGroup::getWorstAlarmState()
{
        return worstAlarmState;
}

AlarmGroup * AlarmGroup::getParentGroup()
{
        return parentGroup;
}

void AlarmGroup::insertChildAlarm(int id, Alarm * al)
{
        this->childAlarms.insert(id,al);
}

void AlarmGroup::insertChildGroup(int id, AlarmGroup * gr)
{
        this->childGroups.insert(id,gr);
}
