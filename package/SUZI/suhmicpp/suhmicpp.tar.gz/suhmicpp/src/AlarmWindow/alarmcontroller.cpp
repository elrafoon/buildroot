#include "suhmicpp/AlarmWindow/alarmcontroller.h"
#include "suhmicpp/AlarmWindow/alarmprotocolhandler.h"
#include "suhmicpp/AlarmWindow/alarmsdatamodel.h"
#include "suhmicpp/AlarmWindow/alarmxmlparser.h"
#include "suhmicpp/AlarmWindow/alarmgroup.h"

AlarmController::AlarmController(AlarmWindow::ColumnVector headers, std::vector<AlarmWindow::EButtonSet> buttons, ACE_INET_Addr add, AlarmWindowSource * source, uint8_t eFilter, int width, QWidget *parent) :
		QWidget(parent), ui(new Ui::AlarmController), logger("AlarmController: ") {
	ui->setupUi(this);
	setWindowFlags(windowFlags() | Qt::FramelessWindowHint);
	this->ackGroup = NULL;
	this->ackAll = NULL;
	this->ackInactive = NULL;
	this->type = type;
	this->id = id;
	this->ackSelected = NULL;
	this->filter = prepareFilters(eFilter);
	prepareCommands(source);
	for (int i = 0; i < buttons.size(); ++i)
		this->prepareButton(buttons[i]);
	this->refreshCommand = describeCommand;
	this->refreshCommand.replace("DESCRIBE", "QUERY");
	this->refreshCommand.truncate(this->refreshCommand.size() - 1);
	this->refreshCommand = this->refreshCommand.append(filter).append("\n");
	this->reactor = ACE_Reactor::instance();
	this->parser = new AlarmXMLParser();
	model = new AlarmsDataModel(headers, this->parser->getAlarmContainer(), NULL);
	this->parser->setModel(this->model);
	this->ui->tableView->setSortingEnabled(true);
	this->ui->tableView->setModel(model);
	if (type == AlarmWindowSource::ALARM)
		this->parser->setAlarmFilter(id);
	this->ui->tableView->horizontalHeader()->setDefaultSectionSize(width / headers.size());
	this->ui->tableView->horizontalHeader()->setResizeMode(QHeaderView::Interactive);
	for (int i = 0; i < headers.size(); ++i) {
		this->ui->tableView->setColumnWidth(i, headers[i]->width);
	}
	if (add.is_any()) {
		this->protHand = NULL;
		return;
	}

	protHand = new AlarmProtocolHandler(this, this->reactor, add, describeCommand.toStdString(), refreshCommand.toStdString());
	QObject::connect(parser, SIGNAL(dataChanged()), this, SLOT(refreshView()));
	QObject::connect(parser, SIGNAL(alarmGroupNotPrepared(int)), this, SLOT(repairCommands(int)));
	QObject::connect(&timer, SIGNAL(timeout()), this, SLOT(runReact()));
	timer.start(10);
	// this->ui->tableView->horizontalHeader()->setResizeMode(QHeaderView::ResizeToContents);
	//    refreshTimer.start(1000);
}

AlarmController::~AlarmController() {
	delete protHand;

	delete model;
	delete ui;
}

void AlarmController::rawDataPrepared(std::string s) {
	this->parser->parse(QString::fromStdString(s));
}

void AlarmController::dataParsed() {
//        this->model->setRootGroup(this->parser.getRootGroup());
//        AlarmGroup * gr = this->parser.getRootGroup();
	logger.log(LM_DEBUG, "PARSED::");
}

void AlarmController::runReact() {
	ACE_Time_Value zero = ACE_Time_Value::zero;
//        qDebug() << "tick";
	do { // must be this way, because when there are only timers scheduled, work_pending returns 0
		reactor->handle_events(zero);
	} while (reactor->work_pending());

	timer.start(150);
}

void AlarmController::refreshView() {
	this->ui->tableView->show();

	this->model->refresh();
}

void AlarmController::prepareButton(AlarmWindow::EButtonSet name) {
	if (name == AlarmWindow::ackSelected) {
		this->ackSelected = new QPushButton(this);
		this->ackSelected->setText("Ack selected");
		this->ui->buttonLayout->addWidget(ackSelected);
		QObject::connect(this->ackSelected, SIGNAL(clicked()), this, SLOT(ackSelectedClicked()));
	}
	if (name == AlarmWindow::ackGroup) {
		this->ackGroup = new QPushButton(this);
		this->ackGroup->setText("Ack group");
		this->ui->buttonLayout->addWidget(ackGroup);
		QObject::connect(this->ackGroup, SIGNAL(clicked()), this, SLOT(ackGroupClicked()));
	}
	if (name == AlarmWindow::ackAll) {
		this->ackAll = new QPushButton(this);
		this->ackAll->setText("Ack all");
		this->ui->buttonLayout->addWidget(ackAll);
		QObject::connect(this->ackAll, SIGNAL(clicked()), this, SLOT(ackAllClicked()));
	}
	if (name == AlarmWindow::ackInactive) {
		this->ackInactive = new QPushButton(this);
		this->ackInactive->setText("Ack inactive");
		this->ui->buttonLayout->addWidget(ackInactive);
		QObject::connect(this->ackInactive, SIGNAL(clicked()), this, SLOT(ackInactiveClicked()));
	}
}

void AlarmController::ackAllClicked() {
	logger.log(LM_DEBUG, "ack all");
	QString ack = describeCommand;
	this->describeCommand;
	ack = ack.remove("TREE ");
	ack.replace("DESCRIBE", "ACK");
	if (type == AlarmWindowSource::ALARM) {
		ack = "ACK ALARM ";
		ack = ack.append(QString::number(id)).append("\n");
	}
	logger.log(LM_DEBUG, "ack: %s", ack.toStdString().c_str());
	if (this->protHand != NULL)
		this->protHand->insertNewMessageToQue(ack.toStdString());
}

void AlarmController::ackSelectedClicked() {
	QModelIndexList l = this->ui->tableView->selectionModel()->selectedRows();
	QModelIndexList::iterator it;
	QList<Alarm *> * alarms = this->model->getAlarmList();
	for (it = l.begin(); it != l.end(); ++it) {
		QString ack = "ACK ALARM ";
		ack.append(QString::number(alarms->at(it->row())->getId())).append("\n");
		if (this->protHand != NULL)
			this->protHand->insertNewMessageToQue(ack.toStdString());
	}
}

void AlarmController::ackGroupClicked() {
	QModelIndexList l = this->ui->tableView->selectionModel()->selectedRows();
	QSet<int> set;
	set.reserve(l.size());
	QModelIndexList::iterator it;
	QList<Alarm *> * alarms = this->model->getAlarmList();
	for (it = l.begin(); it != l.end(); ++it) {
		set.insert(alarms->at(it->row())->getParenGroupId());
	}
	foreach (const int &value, set) {
		QString ack = "ACK GROUP ";
		ack.append(QString::number(value)).append("\n");
		if (this->protHand != NULL)
			this->protHand->insertNewMessageToQue(ack.toStdString());
	}
}

void AlarmController::ackInactiveClicked() {
	QList<Alarm *> * alarms = this->model->getAlarmList();
	QList<Alarm *>::iterator it;
	for (it = alarms->begin(); it != alarms->end(); ++it) {
		if ((*((*it)->getState())) == "NACT_NACK") {
			QString ack = "ACK ALARM ";
			ack.append(QString::number((*it)->getId())).append("\n");
			if (this->protHand != NULL)
				this->protHand->insertNewMessageToQue(ack.toStdString());
		}
	}
}

void AlarmController::repairCommands(int rootId) {
	if (this->describeCommand.lastIndexOf("GROUP") == -1) {
		this->describeCommand = QString("DESCRIBE GROUP ").append(QString::number(rootId)).append("\n");
		this->refreshCommand = QString("QUERY GROUP ").append(QString::number(rootId));
		this->refreshCommand = this->refreshCommand.append(filter).append("\n");
		protHand->insertNewMessageToQue(describeCommand.toStdString());
		protHand->insertNewMessageToQue(refreshCommand.toStdString());
		protHand->setNewCommands(describeCommand.toStdString(), refreshCommand.toStdString());
	}
}

void AlarmController::prepareCommands(AlarmWindowSource * source) {
	type = source->source;
	describeCommand = "DESCRIBE ";
	if (type == AlarmWindowSource::SYSTEM)
		describeCommand.append("SYSTEM");
	if (type == AlarmWindowSource::GROUP) {
		this->describeCommand = describeCommand.append("GROUP ");
		AWSGroup * group = (AWSGroup *) source;
		if (group->withSubGroups) {
			this->describeCommand = this->describeCommand.append("TREE ");
		}
		this->describeCommand = this->describeCommand.append(QString::number(((AWSGroup *) source)->groupId));
		this->id = ((AWSGroup *) source)->groupId;
	}
	if (type == AlarmWindowSource::ALARM) {
		this->describeCommand = describeCommand.append("ALARM ").append(QString::number(((AWSAlarm *) source)->alarmId));
		this->id = ((AWSAlarm *) source)->alarmId;
	}
	this->describeCommand = describeCommand.append("\n");
}

QString AlarmController::prepareFilters(uint8_t eFilter) {
	QStringList filters;
	if (eFilter & AlarmWindow::NACT_NACK)
		filters.append("NACT_NACK");
	if (eFilter & AlarmWindow::NACT_ACK)
		filters.append("NACT_ACK");
	if (eFilter & AlarmWindow::ACT_NACK)
		filters.append("ACT_NACK");
	if (eFilter & AlarmWindow::ACT_ACK)
		filters.append("ACT_ACK");
	QString filter = "";
	foreach(QString fil, filters) {
		filter = filter.append(fil).append(",");
	}
	if (!filter.isEmpty()) {
		filter.truncate(filter.length() - 1);
		filter.prepend(" STATES [");
		filter.append("]");
	}
	return filter;
}
