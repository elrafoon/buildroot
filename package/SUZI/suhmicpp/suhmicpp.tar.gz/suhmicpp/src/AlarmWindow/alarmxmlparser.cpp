#include "suhmicpp/AlarmWindow/alarmxmlparser.h"
#include "suhmicpp/AlarmWindow/alarmgroup.h"
#include "suhmicpp/AlarmWindow/alarm.h"
#include "suhmicpp/AlarmWindow/alarmcondition.h"
#include "suhmicpp/AlarmWindow/alarmsdatamodel.h"

AlarmXMLParser::AlarmXMLParser(QObject *parent) :
		QObject(parent), logger("AlarmXMLParser: ") {
	this->state = READ_STRUCTURE;
	currentAlarm = NULL;
	currentCond = NULL;
	currentGroup = NULL;
	root = NULL;
	rootGroupId = -1;
	alarmFilter = -1;
}

void AlarmXMLParser::parse(QString file) {
	reader = new QXmlStreamReader(file);
	this->nextAlarms.clear();
	while (!reader->atEnd()) {
		reader->readNext();
		if (reader->isStartElement() && reader->name() == "group") {
			state = READ_STRUCTURE;
			lastReadState = GROUP;
			readGroup();
		}
		if (reader->isStartElement() && reader->name() == "alarm") {
			if (readAlarm() == -1) {
				emit alarmGroupNotPrepared(this->rootGroupId);
				delete reader;
				logger.log(LM_DEBUG, "end reading");
				return;
			}
			state = READ_STRUCTURE;
			lastReadState = ALARM;
		}
		if (reader->isStartElement() && reader->name() == "condition") {
			state = READ_STRUCTURE;
			lastReadState = COND;
			readCondition();
		}
		if (reader->isStartElement() && reader->name() == "groupStatus") {
			state = READ_DATA;
			lastReadState = GROUP_STATUS;
			readGroupStatus();
		}
		if (reader->isStartElement() && reader->name() == "alarmStatus") {
			state = READ_DATA;
			lastReadState = ALARM_STATUS;
			readAlarmStatus();
		}
		if (reader->isStartElement() && reader->name() == "conditionStatus") {
			state = READ_DATA;
			lastReadState = COND_STATUS;
			readConditionStatus();
		}
		if (reader->isEndElement()) {
			goUp();
		}
	}

	if (state != READ_STRUCTURE) {
		removeLostAlarms();
		insertNewAlarms();
		emit dataChanged();
	}
	delete reader;

}

void AlarmXMLParser::readGroup() {
	QStringRef ref;
	bool ack = true;
	QString desc = "";
	int id = -5;
	QString name = "";
	int parentId = -5;
	QXmlStreamAttributes attrib = reader->attributes();
	ref = attrib.value("autoAck");
	if (ref != "true")
		ack = false;
	ref = attrib.value("description");
	desc = ref.toString();
	ref = attrib.value("id");
	bool convOk;
	id = ref.toString().toInt(&convOk);
	ref = attrib.value("name");
	name = ref.toString();
	ref = attrib.value("parentGroupId");
	parentId = ref.toString().toInt(&convOk);
	AlarmGroup * gr = NULL;
	this->currentGroup = NULL;
	QMap<int, AlarmGroup*>::const_iterator it = this->createdAlarmGroupStructures.find(parentId);
	if (it == this->createdAlarmGroupStructures.end()) {
		clearData();
		gr = new AlarmGroup(ack, desc, id, name, parentId, currentGroup);
		this->root = gr;
	} else {
		currentGroup = it.value();
		gr = new AlarmGroup(ack, desc, id, name, parentId, currentGroup);
		// currentGroup->insertChildGroup(id,gr);
	}
	this->createdAlarmGroupStructures.insert(id, gr);
	currentGroup = gr;
	logger.log(LM_DEBUG, "inserting group id: %d parent id: %d", id, parentId);
}

int AlarmXMLParser::readAlarm() {
	bool ack = true;
	QString joinCond = "", desc = "", name = "";
	QStringRef ref;
	int id = -1, parentId = -1, priority = 0;
	bool convOk;
	QXmlStreamAttributes attrib = reader->attributes();
	ref = attrib.value("autoAck");
	if (ref != "true")
		ack = false;
	ref = attrib.value("conditionJoinOp");
	joinCond = ref.toString();
	ref = attrib.value("description");
	desc = ref.toString();
	ref = attrib.value("id");
	id = ref.toString().toInt(&convOk);
	ref = attrib.value("name");
	name = ref.toString();
	ref = attrib.value("parentGroupId");
	parentId = ref.toString().toInt(&convOk);
	ref = attrib.value("priority");
	priority = ref.toString().toInt(&convOk);
	currentGroup = NULL;
	if (currentGroup == NULL || (currentGroup->getId() != parentId)) {
		QMap<int, AlarmGroup*>::const_iterator it = this->createdAlarmGroupStructures.find(parentId);
		if (it != this->createdAlarmGroupStructures.end())
			this->currentGroup = it.value();
	}
	if (currentGroup == NULL) {
		this->rootGroupId = parentId;
		return -1;
	}
	if (alarmFilter >= 0)
		if (id != alarmFilter)
			return 0;
	Alarm * al = new Alarm(ack, joinCond, desc, id, name, parentId, priority, currentGroup);
	currentGroup->insertChildAlarm(id, al);
	currentAlarm = al;
	this->createdAlarmSructures.insert(id, al);
	logger.log(LM_DEBUG, "inserting alarm id: %d join cond: %s", id, joinCond.toStdString().c_str());
	return 0;
}

void AlarmXMLParser::readCondition() {
	QString arg = "", desc = "", condOp = "", tagName = "";
	int hyst = 0, id = -1, parentId = -1, value = 0;
	bool overQual = true, hysteRel = true, convOk = false;
	QStringRef ref;
	QXmlStreamAttributes attrib = reader->attributes();
	ref = attrib.value("argument");
	arg = ref.toString();
	ref = attrib.value("description");
	desc = ref.toString();
	ref = attrib.value("hysteresis");
	hyst = ref.toString().toInt(&convOk);
	ref = attrib.value("hysteresisIsRelative");
	if (ref != "true")
		hysteRel = false;
	ref = attrib.value("id");
	id = ref.toString().toInt(&convOk);
	ref = attrib.value("operator");
	condOp = ref.toString();
	ref = attrib.value("overrideQuality");
	if (ref != "true")
		overQual = false;
	ref = attrib.value("parentAlarmId");
	parentId = ref.toString().toInt(&convOk);
	ref = attrib.value("tagName");
	tagName = ref.toString();
	ref = attrib.value("value");
	value = ref.toString().toInt(&convOk);
	currentAlarm = NULL;
	QMap<int, Alarm*>::const_iterator it = this->createdAlarmSructures.find(id);
	if (it == this->createdAlarmSructures.end())
		return;
	currentAlarm = it.value();
	if (alarmFilter >= 0)
		if (parentId != alarmFilter)
			return;
	AlarmCondition * alc = new AlarmCondition(arg, desc, hyst, hysteRel, id, condOp, overQual, parentId, tagName, value, currentAlarm);
	logger.log(LM_DEBUG, "inserting condition id: %d join cond: %s", id, tagName.toStdString().c_str());
	currentAlarm->insertChildAlarmCond(id, alc);
	currentCond = alc;
	this->createdConditionStructures.insert(id, alc);
}

void AlarmXMLParser::readGroupStatus() {
	QString worstAlPrio = "", worstAlId = "";
	int id = -1;
	QString worstAlarmState = "";
	bool convOk;
	QStringRef ref;
	QXmlStreamAttributes attrib = reader->attributes();
	ref = attrib.value("id");
	id = ref.toString().toInt(&convOk);
	ref = attrib.value("worstAlarmEffectivePriority");
	worstAlPrio = ref.toString();
	ref = attrib.value("worstAlarmId");
	worstAlId = ref.toString();
	ref = attrib.value("worstAlarmState");
	worstAlarmState = ref.toString();
	currentGroup = this->createdAlarmGroupStructures.find(id).value();
	currentGroup->setActiveParam(worstAlPrio, worstAlId, worstAlarmState);
}

void AlarmXMLParser::readAlarmStatus() {
	int effectivePrio = -1;
	int id = -1;
	QString state = "";
	QString tLatestUpdate;
	bool convOk;
	QStringRef ref;
	QXmlStreamAttributes attrib = reader->attributes();
	ref = attrib.value("effectivePriority");
	effectivePrio = ref.toString().toInt(&convOk);
	ref = attrib.value("id");
	id = ref.toString().toInt(&convOk);
	ref = attrib.value("state");
	state = ref.toString();
	ref = attrib.value("tLatestUpdate");
	tLatestUpdate = ref.toString();
	QStringList l = tLatestUpdate.split("T");
	QTime time = QTime::fromString(l.at(1), "hh:mm:ss");
	QDate date = QDate::fromString(l.at(0), "yyyy-MM-dd");
	QMap<int, Alarm*>::const_iterator it = this->createdAlarmSructures.find(id);
	if (it == this->createdAlarmSructures.end())
		return;
	currentAlarm = it.value();
	currentAlarm->setActiveParam(effectivePrio, state, time, date);
	this->nextAlarms.append(currentAlarm);
}

void AlarmXMLParser::readConditionStatus() {
	int hystLastValue = -1;
	int id = -1;
	QString tLatestUpdate;
	bool convOk, fullfilled = true;
	QStringRef ref;
	QXmlStreamAttributes attrib = reader->attributes();
	ref = attrib.value("fulfilled");
	if (ref != "true")
		fullfilled = false;
	ref = attrib.value("hystLastValue");
	hystLastValue = ref.toString().toInt(&convOk);
	ref = attrib.value("id");
	id = ref.toString().toInt(&convOk);
	ref = attrib.value("tLatestUpdate");
	tLatestUpdate = ref.toString();
	QStringList l = tLatestUpdate.split("T");
	QTime time = QTime::fromString(l.at(1), "hh:mm:ss");
	QDate date = QDate::fromString(l.at(0), "yyyy-MM-dd");
	QMap<int, AlarmCondition*>::const_iterator it = this->createdConditionStructures.find(id);
	if (it == this->createdConditionStructures.end())
		return;
	currentCond = it.value();
	currentCond->setActiveParam(fullfilled, hystLastValue, time, date);
}

void AlarmXMLParser::goUp() {
	switch (lastReadState) {
	case GROUP:
		currentGroup = NULL;
		break;
	case ALARM:
		currentAlarm = NULL;
		break;
	case COND:
		currentCond = NULL;
		break;
	case GROUP_STATUS:
		currentGroup = NULL;
		break;
	case ALARM_STATUS:
		currentAlarm = NULL;
		break;
	case COND_STATUS:
		currentCond = NULL;
		break;

	default:
		logger.log(LM_ERROR, "unexpected state");
	}
	return;
}

AlarmGroup * AlarmXMLParser::getRootGroup() {
	return root;
}

void AlarmXMLParser::setAlarmFilter(int filter) {
	this->alarmFilter = filter;
}

QList<Alarm*> * AlarmXMLParser::getAlarmContainer() {
	return &this->activeAlarms;
}

void AlarmXMLParser::setModel(AlarmsDataModel *model) {
	this->model = model;
}

void AlarmXMLParser::clearData() {
	this->model->callBeginRemoveRows(0, this->activeAlarms.size());
	this->activeAlarms.clear();
	this->nextAlarms.clear();
	QMap<int, AlarmGroup *>::iterator it;
	for (it = this->createdAlarmGroupStructures.begin(); it != this->createdAlarmGroupStructures.end(); ++it)
		delete (it.value());
	this->createdAlarmGroupStructures.clear();
	QMap<int, Alarm *>::iterator jt;
	for (jt = this->createdAlarmSructures.begin(); jt != this->createdAlarmSructures.end(); ++jt)
		delete (jt.value());
	this->createdAlarmSructures.clear();
	this->createdConditionStructures.clear();
	this->model->callEndRemoveRows();
}

AlarmXMLParser::~AlarmXMLParser() {
	clearData();
}

void AlarmXMLParser::removeLostAlarms() {
	for (int i = 0; i < this->activeAlarms.size(); ++i) {
		Alarm * al = this->activeAlarms.at(i);
		if (!this->nextAlarms.contains(al)) {
			this->model->callBeginRemoveRows(i, i);
			this->activeAlarms.removeAt(i);
			this->model->callEndRemoveRows();
			--i;
		}
	}
}

void AlarmXMLParser::insertNewAlarms() {
	for (int i = 0; i < this->nextAlarms.size(); ++i) {
		Alarm * al = this->nextAlarms.at(i);
		if (!this->activeAlarms.contains(al)) {
			this->model->callBeginInsertRows(activeAlarms.size(), activeAlarms.size());
			this->activeAlarms.append(al);
			this->model->callEndInsertRows();
		}
	}

}
