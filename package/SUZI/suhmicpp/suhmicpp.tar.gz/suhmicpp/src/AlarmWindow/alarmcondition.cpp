#include "suhmicpp/AlarmWindow/alarmcondition.h"
#include "suhmicpp/AlarmWindow/alarm.h"

AlarmCondition::AlarmCondition(QObject * parent) :
        QObject(parent)
{
}

AlarmCondition::AlarmCondition(QString condArg, QString desc, int hyster, bool hystRel, int id, QString condOp, bool overQual, int parentAlarmId, QString tagName, int value, Alarm *parentAlarm)
{
        this->conditionArgument = condArg;
        this->descrition = desc;
        this->hysteresis = hyster;
        this->hysteresisIsRelative = hystRel;
        this->id = id;
        this->condOperator = condOp;
        this->overideQuality = overQual;
        this->parentAlarmId = parentAlarmId;
        this->tagName = tagName;
        this->value = value;
        this->fullfilled = false;
        this->hystLastvalue = -1;
}

void AlarmCondition::setActiveParam(bool fullfilled, int hystLastvalue, QTime updTime, QDate updDate)
{
        this->fullfilled = fullfilled;
        this->hystLastvalue = hystLastvalue;
        this->tLatestUpdateDate = updDate;
        this->tLatestUpdateTime = updTime;
}

bool AlarmCondition::getHysteresisIsRelative()
{
        return hysteresisIsRelative;
}

bool AlarmCondition::getOverideQuality()
{
        return overideQuality;
}

bool AlarmCondition::getFullfilled()
{
        return fullfilled;
}

int  AlarmCondition::getHysteresis()
{
        return hysteresis;
}

int  AlarmCondition::getId()
{
        return id;
}

int  AlarmCondition::getValue()
{
        return value;
}

int  AlarmCondition::getParentAlarmId()
{
        return parentAlarmId;
}

QString AlarmCondition::getConditionArgument()
{
        return conditionArgument;
}

QString AlarmCondition::getDescription()
{
        return descrition;
}

QString AlarmCondition::getCondOperator()
{
        if(this->condOperator == "gt")
                return ">";
        if(this->condOperator == "lt")
                return "<";
        if(this->condOperator == "ge")
                return ">=";
        if(this->condOperator == "le")
                return "<=";
        if(this->condOperator == "eq")
                return "==";
        return "!=";
}

QString AlarmCondition::getTagName()
{
        return tagName;
}

QTime AlarmCondition::getTLatestUpdatetime()
{
        return tLatestUpdateTime;
}

QDate AlarmCondition::getTLatestUpdateDate()
{
        return tLatestUpdateDate;
}

Alarm * AlarmCondition::getParentAlarm()
{
        return parentAlarm;
}

QString AlarmCondition::getConditionFormatted()
{
        QString con ="";
        con.append(this->tagName).append(".").append(conditionArgument).append(" ").append(getCondOperator()).append(" ").append(QString::number(value));
        if(this->fullfilled)
                con.prepend("[").append("]");
        else
                con.prepend("(").append(")");
        return con;
}
