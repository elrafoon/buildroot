#include "suhmicpp/AlarmWindow/alarmsdatamodel.h"
#include "suhmicpp/AlarmWindow/alarmgroup.h"


AlarmColumn::EType AlarmsDataModel::sortParam = AlarmColumn::alarmName;

AlarmsDataModel::AlarmsDataModel(AlarmWindow::ColumnVector headerVector, QList<Alarm *> * alarms, QObject *parent) :
	QAbstractTableModel(parent) {
	rootGroup = NULL;
	this->headers = headerVector;
	setHeaders(headerVector);
	this->alarms = alarms;
}

AlarmsDataModel::~AlarmsDataModel() {
}

int AlarmsDataModel::rowCount(const QModelIndex &parent) const {
	return alarms->count();
}

int AlarmsDataModel::columnCount(const QModelIndex &parent) const {
	return columnNames.size();
}

QVariant AlarmsDataModel::data(const QModelIndex &index, int role) const {
	int r = index.row();
	int c = index.column();
	//        QString name = this->columnNames.at(c);
	Alarm * al = alarms->at(r);
	if (r < alarms->size() && c < columnNames.size()) {
		if (role == Qt::DisplayRole) {
			AlarmColumn* type = headers[c];
			return getValueFromAlarmByName(al, type);
		}
	}
	return QVariant();

}

QVariant AlarmsDataModel::headerData(int section, Qt::Orientation orientation, int role) const {
	if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
		return this->columnNames.at(section);
	return QVariant();
}

void AlarmsDataModel::refresh() {
	qDebug() << " REFRESH MODEL";
emit this->dataChanged(QModelIndex(),createIndex(alarms->size(),columnNames.size()));
}

QVariant AlarmsDataModel::getValueFromAlarmByName(Alarm * alarm, AlarmColumn *param) const {
	if (param->type == AlarmColumn::alarmLatestUpdateTime) {
		QString time = alarm->getTLatestUpdateTime().toString("hh:mm:ss") + " " + alarm->getTLatestUpdateDate().toString("yyyy-MM-dd");
		return time;
	}
	if (param->type == AlarmColumn::alarmName) {
		return alarm->getName();
	}
	if (param->type == AlarmColumn::groupName) {
		return alarm->getParentGroup()->getName();
	}
	if (param->type == AlarmColumn::alarmPriority) {
		return alarm->getPriority();
	}
	if (param->type == AlarmColumn::alarmEffectivePriority) {
		return alarm->geteffectivePriority();
	}
	if (param->type == AlarmColumn::alarmState) {
		return *alarm->getState();
	}
	if (param->type == AlarmColumn::groupState) {
		return alarm->getParentGroup()->getWorstAlarmState();
	}
	if (param->type == AlarmColumn::alarmConditions) {
		return alarm->getConditionString();
	}
	if (param->type == AlarmColumn::groupEffectivePriority) {
		return alarm->getParentGroup()->getWorstAlarmEffectivePriority();
	}
	return QVariant();
}

inline bool alarmPointerCompareAsc(Alarm * al, Alarm * al2) {
	AlarmColumn::EType param = AlarmsDataModel::getSortParam();

	if (param == AlarmColumn::alarmLatestUpdateTime) {
		QString time1 = al->getTLatestUpdateTime().toString("hh:mm:ss") + " " + al->getTLatestUpdateDate().toString("yyyy-MM-dd");
		QString time2 = al2->getTLatestUpdateTime().toString("hh:mm:ss") + " " + al2->getTLatestUpdateDate().toString("yyyy-MM-dd");
		return time1 < time2;
	}
	if (param == AlarmColumn::alarmName) {
		return al->getName() < al2->getName();
	}
	if (param == AlarmColumn::groupName) {
		return al->getParentGroup()->getName() < al2->getParentGroup()->getName();
	}
	if (param == AlarmColumn::alarmPriority) {
		return al->getPriority() < al2->getPriority();
	}
	if (param == AlarmColumn::alarmEffectivePriority) {
		return al->geteffectivePriority() < al2->geteffectivePriority();
	}
	if (param == AlarmColumn::alarmState) {
		return *al->getState() < *al2->getState();
	}
	if (param == AlarmColumn::groupState) {
		return al->getParentGroup()->getWorstAlarmState() < al2->getParentGroup()->getWorstAlarmState();
	}
	if (param == AlarmColumn::alarmConditions) {
		return al->getConditionString() < al2->getConditionString();
	}
	if (param == AlarmColumn::groupEffectivePriority) {
		return al->getParentGroup()->getWorstAlarmEffectivePriority() < al2->getParentGroup()->getWorstAlarmEffectivePriority();
	}
}

inline bool alarmPointerCompareDesc(Alarm * al2, Alarm * al) {
	AlarmColumn::EType param = AlarmsDataModel::getSortParam();

	if (param == AlarmColumn::alarmLatestUpdateTime) {
		QString time1 = al->getTLatestUpdateTime().toString("hh:mm:ss") + " " + al->getTLatestUpdateDate().toString("yyyy-MM-dd");
		QString time2 = al2->getTLatestUpdateTime().toString("hh:mm:ss") + " " + al2->getTLatestUpdateDate().toString("yyyy-MM-dd");
		return time1 < time2;
	}
	if (param == AlarmColumn::alarmName) {
		return al->getName() < al2->getName();
	}
	if (param == AlarmColumn::groupName) {
		return al->getParentGroup()->getName() < al2->getParentGroup()->getName();
	}
	if (param == AlarmColumn::alarmPriority) {
		return al->getPriority() < al2->getPriority();
	}
	if (param == AlarmColumn::alarmEffectivePriority) {
		return al->geteffectivePriority() < al2->geteffectivePriority();
	}
	if (param == AlarmColumn::alarmState) {
		return al->getState() < al2->getState();
	}
	if (param == AlarmColumn::groupState) {
		return al->getParentGroup()->getWorstAlarmState() < al2->getParentGroup()->getWorstAlarmState();
	}
	if (param == AlarmColumn::alarmConditions) {
		return al->getConditionString() < al2->getConditionString();
	}
	if (param == AlarmColumn::groupEffectivePriority) {
		return al->getParentGroup()->getWorstAlarmEffectivePriority() < al2->getParentGroup()->getWorstAlarmEffectivePriority();
	}
}

void AlarmsDataModel::sort(int column, Qt::SortOrder order) {
	if (order == Qt::AscendingOrder) {
		sortParam = headers.at(column)->type;
		qSort(alarms->begin(), alarms->end(), alarmPointerCompareAsc);
	}
	if (order == Qt::DescendingOrder) {
		sortParam = headers.at(column)->type;
		qSort(alarms->begin(), alarms->end(), alarmPointerCompareDesc);
	}
}

AlarmColumn::EType AlarmsDataModel::getSortParam() {
	return AlarmsDataModel::sortParam;
}

QList<Alarm *> * AlarmsDataModel::getAlarmList() {
	return alarms;
}

void AlarmsDataModel::callBeginRemoveRows(int first, int last) {

	this->beginRemoveRows(QModelIndex(), first, last);
}

void AlarmsDataModel::callEndRemoveRows() {
	this->endRemoveRows();
}

void AlarmsDataModel::callEndInsertRows() {
	this->endInsertRows();
}

void AlarmsDataModel::callBeginInsertRows(int first, int last) {
	this->beginInsertRows(QModelIndex(), first, last);
}

void AlarmsDataModel::callBeginResetModel() {
	this->beginResetModel();
}

void AlarmsDataModel::callEndResetModel() {
	this->endResetModel();
}

void AlarmsDataModel::setHeaders(AlarmWindow::ColumnVector & headers) {
	this->columnNames.clear();
	for (int i = 0; i < headers.size(); ++i) {
		if (headers[i]->type == AlarmColumn::alarmLatestUpdateTime)
			this->columnNames.append("Alarm latest update time");
		if (headers[i]->type == AlarmColumn::alarmName)
			this->columnNames.append("Alarm name");
		if (headers[i]->type == AlarmColumn::groupName)
			this->columnNames.append("Group name");
		if (headers[i]->type == AlarmColumn::alarmPriority)
			this->columnNames.append("Alarm priority");
		if (headers[i]->type == AlarmColumn::alarmEffectivePriority)
			this->columnNames.append("Alarm effective priority");
		if (headers[i]->type == AlarmColumn::alarmState)
			this->columnNames.append("Alarm state");
		if (headers[i]->type == AlarmColumn::groupState)
			this->columnNames.append("Group state");
		if (headers[i]->type == AlarmColumn::alarmConditions)
			this->columnNames.append("Alarm condtions");
		if (headers[i]->type == AlarmColumn::groupEffectivePriority)
			this->columnNames.append("Group effective priority");
	}
}

