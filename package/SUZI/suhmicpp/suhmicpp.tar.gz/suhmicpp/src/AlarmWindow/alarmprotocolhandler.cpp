#include "suhmicpp/AlarmWindow/alarmprotocolhandler.h"
#include "suhmicpp/AlarmWindow/alarmcontroller.h"

using namespace SuhubConnectorLight;

#define MESSAGE_TYPE_LENGTH_INFO 1
#define MESSAGE_LENGTH_INFO 4

AlarmProtocolHandler::MyTimerType AlarmProtocolHandler::singleShot;
AlarmProtocolHandler::MyTimerType AlarmProtocolHandler::period;

AlarmProtocolHandler::AlarmProtocolHandler(AlarmController * parent, ACE_Reactor * reactor, ACE_INET_Addr ad, std::string reconnectCommand, std::string refreshCommand) :
	ReconnectingHandler(reactor, ad), PrefixedLogger("AlarmConnectorHandler: ") {

	this->parent = parent;
	acceptResultTimerId = -1;
	periodicalMessageTimerId = -1;
	singleShot.type = MyTimerType::SINGLESHOT;
	period.type = MyTimerType::PERIOD;
	this->reconnectCommand = reconnectCommand;
	this->refreshCommand = refreshCommand;
	curSendPos = 0;
	curGetPos = 0;
	timeout.set(5, 0);
	headerRead = 0;

	this->reactor = reactor;
	restartTimer();
}

int AlarmProtocolHandler::handle_close(ACE_HANDLE fd, ACE_Reactor_Mask mask) {
	log(LM_INFO, " HANDLE CLOSE: \n");
	if (acceptResultTimerId != -1) {
		acceptResultTimerId = reactor->cancel_timer(acceptResultTimerId);
		acceptResultTimerId = -1;
	}
	if (periodicalMessageTimerId != -1) {
		reactor->cancel_timer(periodicalMessageTimerId);
		periodicalMessageTimerId = -1;
	}

	return ReconnectingHandler::handle_close(fd, mask);
}

int AlarmProtocolHandler::handle_input_connected(ACE_HANDLE) {
	ssize_t read;
	ssize_t toRead;
	log(LM_INFO,"handle input\n");
	switch (state) {
	case S_GET_ERROR_OR_COM_RESULT:
		this->message.reset(new uint8_t[MESSAGE_TYPE_LENGTH_INFO]);
		read = peer().recv(message.get(), MESSAGE_TYPE_LENGTH_INFO);
		log(LM_INFO, " Bytes readed %d\n", (int) read);
		if (read <= 0) {
			return -1;
		} else {
			log(LM_INFO, " READED HEADER DATA %d \n", message.get()[0]);
			if (message.get()[0] == 0) {
				state = S_GET_ERROR_SIZE;
				log(LM_INFO, " Going to state : S_GO_TO_EROR\n");
			}
			if (message.get()[0] == 1) {
				state = S_GET_COM_RESULT_SIZE;
				log(LM_INFO, " Going to state : S_GET_COM_RESULT_SIZE\n");

			}
			this->message.reset(new uint8_t[MESSAGE_LENGTH_INFO]);
			headerRead = 0;
		}
		restartTimer();
		break;
	case S_GET_COM_RESULT_SIZE:
		toRead = MESSAGE_LENGTH_INFO - headerRead;
		read = peer().recv(message.get() + headerRead, toRead);
		log(LM_INFO, " Bytes readed %d\n", (int) read);
		log(LM_INFO, " header Read %d, toRead %d, read %d\n", headerRead, toRead, read);
		if (read <= 0)
			return -1;
		if (toRead == read) {
			state = S_GET_COM_RESULT;
			uint32_t messlength = ntohl(*((uint32_t *) message.get()));
			log(LM_INFO, " Header length: %d\n", (long) messlength);
			this->message.reset(new uint8_t[messlength]);
			curMessSize = messlength;
			messageRead = 0;
		} else {
			headerRead += read;
		}
		restartTimer();
		break;

	case S_GET_COM_RESULT:
		toRead = curMessSize - messageRead;
		read = peer().recv(message.get() + messageRead, toRead);
		if (read <= 0)
			return -1;
		if (toRead == read) {
			state = S_SEND_COMMAND;
			std::string str((char*) message.get(), curMessSize);
			log(LM_DEBUG, " MESSAGE: %s\n", str.c_str());
			parent->rawDataPrepared(str);
			messageRead = 0;
			headerRead = 0;
			curMessSize = 0;
			reactor->cancel_wakeup(this, READ_MASK);
			this->currentCommand = refreshCommand;
			this->messageQue.notification_strategy(this->notifStrategy);
			this->messageQue.notify();
		} else {
			messageRead += read;
		}
		restartTimer();
		break;

	case S_GET_ERROR_SIZE:
		toRead = MESSAGE_LENGTH_INFO - headerRead;
		read = peer().recv(message.get() + headerRead, toRead);
		log(LM_INFO, " Error Bytes readed %d\n", (int) read);
		log(LM_INFO, " Error header Read %d, toRead %d, read %d\n", headerRead, toRead, read);
		if (read <= 0)
			return -1;
		if (toRead == read) {
			state = S_GET_ERROR;
			uint32_t messlength = ntohl(*((uint32_t *) message.get()));
			log(LM_DEBUG, " Header length: %d\n", (long) messlength);
			this->message.reset(new uint8_t[messlength]);
			curMessSize = messlength;
			messageRead = 0;
		} else {
			headerRead += read;
		}
		restartTimer();
		break;

	case S_GET_ERROR:
		toRead = curMessSize - messageRead;
		read = peer().recv(message.get() + messageRead, toRead);
		if (read <= 0)
			return -1;
		if (toRead == read) {
			state = S_SEND_COMMAND;
			std::string str((char*) message.get(), curMessSize);
			log(LM_ERROR, " ERROR:  %s\n", str.c_str());
			// parent->rawDataPrepared(str);
			messageRead = 0;
			headerRead = 0;
			curMessSize = 0;
			reactor->cancel_wakeup(this, READ_MASK);
			this->currentCommand = refreshCommand;
			this->messageQue.notification_strategy(this->notifStrategy);
			this->messageQue.notify();
		} else {
			messageRead += read;
		}
		restartTimer();
		break;

	case S_GET_ACK:
		this->message.reset(new uint8_t[MESSAGE_TYPE_LENGTH_INFO]);
		read = peer().recv(message.get(), MESSAGE_TYPE_LENGTH_INFO);
		log(LM_DEBUG, " Bytes readed %d\n", (int) read);
		if (read <= 0) {
			return -1;
		} else {
			state = S_SEND_COMMAND;
			messageRead = 0;
			headerRead = 0;
			curMessSize = 0;
			reactor->cancel_wakeup(this, READ_MASK);
			this->currentCommand = refreshCommand;
			this->messageQue.notification_strategy(this->notifStrategy);
			this->messageQue.notify();
		}
		restartTimer();
		break;

	default:
		return -1;
		return 0;
	}
	return 0;

}

int AlarmProtocolHandler::handle_output_connected(ACE_HANDLE fd) {
	if (peer().get_handle() == fd) {
		log(LM_INFO, " Handle_output\n");
		ssize_t sent;
		ssize_t toSend;
		switch (state) {
		case S_SENDING_COMMAND:
			this->messageQue.notification_strategy(NULL);
			toSend = currentCommand.size() - curSendPos;
			log(LM_DEBUG, " Bytes: %d, toSend: %d, curSendPos: %d\n", currentCommand.size(), (int) toSend, (int) curSendPos);
			sent = peer().send(currentCommand.c_str() + curSendPos, toSend);
			log(LM_INFO, "Send %B\n",sent);
			if (sent > 0) {
				curSendPos = curSendPos + sent;
				toSend -= sent;

				if (toSend == 0) {
					if (this->currentCommand[0] == 'A')
						this->state = S_GET_ACK;
					else
						this->state = S_GET_ERROR_OR_COM_RESULT;
					curSendPos = 0;
					log(LM_INFO, "END WRITE %s\n", currentCommand.c_str());
					reactor->cancel_wakeup(this, WRITE_MASK);
					reactor->schedule_wakeup(this, READ_MASK);
				}
			} else {
				return -1;
			}
			restartTimer();

			break;

		default:
			{
				if (periodicalMessageTimerId != -1){
							reactor->cancel_timer(periodicalMessageTimerId);
							periodicalMessageTimerId = -1;
				}
				return -1;
			}
		}
	} else {
		//SET MESSAGE//
		if (state == S_SEND_COMMAND) {
			if (!this->messageQue.is_empty()) {
				log(LM_INFO, " SET MESSAGE\n");
				ACE_Message_Block * bl;
				if (messageQue.dequeue_head(bl) != -1) {
					std::auto_ptr<Message> mes(*reinterpret_cast<Message **> (bl->rd_ptr()));
					bl->rd_ptr(sizeof(Message*));
					delete bl;
					std::string s = mes->mess;
					log(LM_DEBUG, " Velkost %d\n", s.size());
					log(LM_DEBUG, " %s\n", s.c_str());
					currentCommand = s;
					state = S_SENDING_COMMAND;
					this->messageQue.notification_strategy(NULL);
					reactor->schedule_wakeup(this, WRITE_MASK);
				}
			} else {
				this->messageQue.notification_strategy(notifStrategy);
				reactor->cancel_wakeup(this, WRITE_MASK);

			}
		} else {
			return 0;

		}

	}
	return 0;
}

int AlarmProtocolHandler::handle_timeout(const ACE_Time_Value &currentTime, const void *act) {
	log(LM_DEBUG, " ADRESA %@\n", act);
	log(LM_DEBUG, " ADRESA %@\n", &singleShot);
	log(LM_DEBUG, " ADRESA %@\n", &period);

	if (act == NULL) {
		if (periodicalMessageTimerId != -1){
			reactor->cancel_timer(periodicalMessageTimerId);
			periodicalMessageTimerId = -1;
		}
		if (acceptResultTimerId != -1){
			reactor->cancel_timer(acceptResultTimerId);
			acceptResultTimerId = -1;
		}
		return ReconnectingHandler::handle_timeout(currentTime, act);
	}

	if (((MyTimerType *) act)->type == MyTimerType::SINGLESHOT) {
		log(LM_INFO, "RECONNECT\n");
		this->currentCommand = reconnectCommand;
		this->messageQue.notification_strategy(NULL);
		if (periodicalMessageTimerId != -1){
			reactor->cancel_timer(periodicalMessageTimerId);
			periodicalMessageTimerId = -1;
		}
		reconnect();
		return 0;
	}
	if (((MyTimerType *) act)->type == MyTimerType::PERIOD) {
		ACE_Message_Block * mess = new ACE_Message_Block(sizeof(Message));
		Message * m = new Message();
		m->mess = refreshCommand;

		*reinterpret_cast<Message **> (mess->wr_ptr()) = m;
		mess->wr_ptr(sizeof(m));
		if(this->messageQue.enqueue(mess) == -1) {
			delete m;
			delete mess;
			log(LM_WARNING, " Message queue is full.\n");
			cleanQueue();
		}
		log(LM_INFO, " NOT RECONNECT\n");
		reactor->schedule_wakeup(this, WRITE_MASK);
		return 0;
	}
	return ReconnectingHandler::handle_timeout(currentTime, act);
}

int AlarmProtocolHandler::open(void * arg) {
	clearMsqQueue();
	state = S_SENDING_COMMAND;
	currentCommand = reconnectCommand;
	curSendPos = 0;
	curGetPos = 0;
	this->notifStrategy = new ACE_Reactor_Notification_Strategy(reactor, this, WRITE_MASK);
	state = S_SENDING_COMMAND;
	reactor->cancel_wakeup(this, ALL_EVENTS_MASK);
	reactor->schedule_wakeup(this, WRITE_MASK);
	periodicalMessageTimerId = reactor->schedule_timer(this, &period, ACE_Time_Value(0, 0), ACE_Time_Value(0, 50 * 10000));
	//  restartTimer();
	return ReconnectingHandler::open(arg);
}

void AlarmProtocolHandler::restartTimer() {
	if (acceptResultTimerId != -1) {
		reactor->cancel_timer(acceptResultTimerId);
		acceptResultTimerId = -1;
	}
	log(LM_DEBUG, " Adresa timer: %@\n", &singleShot);
	acceptResultTimerId = reactor->schedule_timer(this, &singleShot, timeout);
}

AlarmProtocolHandler::~AlarmProtocolHandler() {
	delete notifStrategy;
}

void AlarmProtocolHandler::insertNewMessageToQue(std::string message) {
	ACE_Message_Block * mess = new ACE_Message_Block(sizeof(Message));
	Message * m = new Message();
	m->mess = message;

	*reinterpret_cast<Message **> (mess->wr_ptr()) = m;
	mess->wr_ptr(sizeof(m));
	if(this->messageQue.enqueue(mess) == -1) {
			delete m;
			delete mess;
			log(LM_WARNING, " Message queue is full.\n");
			cleanQueue();
	}
	log(LM_INFO, " INSERT MESSAGE TO QUEUE, NOT RECONNECT %s\n", message.c_str());
}

void AlarmProtocolHandler::setNewCommands(std::string describe, std::string refresh) {
	this->refreshCommand = refresh;
	this->reconnectCommand = describe;
}

void AlarmProtocolHandler::cleanQueue() {

	size_t high_mark = messageQue.high_water_mark();
	size_t toClean = high_mark / 10;
	for (int i = 0; i < toClean; ++i) {
		ACE_Message_Block * bl;
		if (messageQue.dequeue_head(bl) != -1) {
			std::auto_ptr < Message
					> mes(*reinterpret_cast<Message **>(bl->rd_ptr()));
			bl->rd_ptr(sizeof(Message*));
			delete bl;
		}
	}
	log(LM_INFO, " CLEAN QUEUE\n");
}

void AlarmProtocolHandler::clearMsqQueue(){
	size_t high_mark = messageQue.high_water_mark();
	for (int i = 0; i < high_mark; ++i) {
			ACE_Message_Block * bl;
			if (messageQue.dequeue_head(bl) != -1) {
				std::auto_ptr < Message
						> mes(*reinterpret_cast<Message **>(bl->rd_ptr()));
				bl->rd_ptr(sizeof(Message*));
				delete bl;
			}
		}

}
