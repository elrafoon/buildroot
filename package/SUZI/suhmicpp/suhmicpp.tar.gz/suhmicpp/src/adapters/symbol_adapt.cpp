/*
 * symbol_adapt.cpp
 *
 *  Created on: Dec 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/adapters/symbol_adapt.h"
#include "suhmicpp/symbols/alarm_window.h"
#include "suhmicpp/util/util.h"
#include "suhmicpp/adapters/compound_symbol_adapt.h"

//TODO(vlado): presunut obsah konstruktora do setAdaptee pozri windowAdapt a hmiAdapt
SymbolAdapt::SymbolAdapt(Symbol * const symbol) :
		symbol(symbol), parent(NULL), CSParent(NULL) {
	GenericScriptList::GenericScriptVector::iterator it;
	for (it = symbol->genericScriptList.genericScript.begin(); it != symbol->genericScriptList.genericScript.end(); ++it) {
		(*it)->script.code.setSymbolSelf(this);
	}
	symbol->oncreate.handlerCode.setSymbolSelf(this);
	symbol->ondestroy.handlerCode.setSymbolSelf(this);
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->onclick.handlerCode.setSymbolSelf(this);
		static_cast<VisualSymbol *>(symbol)->onshow.handlerCode.setSymbolSelf(this);
		static_cast<VisualSymbol *>(symbol)->onhide.handlerCode.setSymbolSelf(this);
		static_cast<VisualSymbol *>(symbol)->linkList.setSymbolSelf(this);
	}
	if (symbol->obType & LABEL) {
		static_cast<Label *>(symbol)->onchange.handlerCode.setSymbolSelf(this);
		static_cast<Label *>(symbol)->boundExpression.expression.setSymbolSelf(this);
	}
	if (symbol->obType & TIMER) {
		static_cast<Timer *>(symbol)->onTick.handlerCode.setSymbolSelf(this);
	}
	if (symbol->obType & ALARM_WINDOW) {
		static_cast<AlarmWindow*>(symbol)->onshow.handlerCode.setSymbolSelf(this);
		static_cast<AlarmWindow*>(symbol)->onhide.handlerCode.setSymbolSelf(this);
	}
}

void SymbolAdapt::setWinParent(WindowAdapt *parent) {
	this->parent = parent;
}

void SymbolAdapt::setCSParent(CompoundSymbolAdapt *parent){
	this->CSParent = parent;
}

/**
 * Prepisana v hmi_adapt.i
 */
void SymbolAdapt::getParent() {

}

WindowAdapt* SymbolAdapt::getWinParent() {
	return parent;
}

CompoundSymbolAdapt* SymbolAdapt::getCSParent() {
	return CSParent;
}

bool SymbolAdapt::isInCS(){
	return CSParent != NULL;
}

std::string SymbolAdapt::getName() {
	if (symbol->obType & SYMBOL) {
		return symbol->name;
	}
	return "";
}

unsigned int SymbolAdapt::getType() {
	return symbol->obType;
}

//Timer
void SymbolAdapt::setEnabled(bool enabled) {
	if (symbol->obType & TIMER) {
		return static_cast<Timer *>(symbol)->setEnabled(enabled);
	}
}

//VisualSymbol

float SymbolAdapt::getRotation() {
	if (symbol->obType & VISUAL_SYMBOL) {
		return static_cast<VisualSymbol *>(symbol)->rotation;
	}
}

void SymbolAdapt::setRotation(float rotation) {
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->setRotation(rotation);
	}
}

int SymbolAdapt::getZOrder() {
	if (symbol->obType & VISUAL_SYMBOL) {
		return static_cast<VisualSymbol *>(symbol)->zOrder;
	}
}

void SymbolAdapt::setZOrder(int zOrder) {
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->setZOrder(zOrder);
	}
}

std::pair<int, int> SymbolAdapt::getPosition() {
	if (symbol->obType & VISUAL_SYMBOL) {
		std::pair<int, int> pos;
		QPoint qPos = static_cast<VisualSymbol *>(symbol)->position;
		pos.first = qPos.x();
		pos.second = qPos.y();
		return pos;
	}
}

void SymbolAdapt::setPosition(int x, int y) {
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->setPosition(x, y);
	}
}

std::pair<int, int> SymbolAdapt::getRotCenter() {
	if (symbol->obType & VISUAL_SYMBOL) {
		return std::pair<int, int>(static_cast<VisualSymbol *>(symbol)->rotCenter.x(), static_cast<VisualSymbol *>(symbol)->rotCenter.y());
	}
}

void SymbolAdapt::setRotCenter(int x, int y) {
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->setRotCenter(x, y);
	}
}

std::pair<int, int> SymbolAdapt::getSize() {
	if (symbol->obType & VISUAL_SYMBOL) {
		return static_cast<VisualSymbol *>(symbol)->getSize();
	}
}

void SymbolAdapt::setSize(int width, int height) {
	if (symbol->obType & VISUAL_SYMBOL) {
		if (symbol->obType & COMPOUND_SYMBOL) {
		} else {
			static_cast<VisualSymbol *>(symbol)->setSize(width, height);
		}
	}
}

std::pair<float, float> SymbolAdapt::getScale() {
	if (symbol->obType & VISUAL_SYMBOL)
		return static_cast<VisualSymbol *>(symbol)->getScale();
}

void SymbolAdapt::setScale(float x, float y) {
	if (symbol->obType & VISUAL_SYMBOL) {
		if (symbol->obType & COMPOUND_SYMBOL) {
			if (x == y)
				static_cast<VisualSymbol *>(symbol)->setScale(x, y);
		} else {
			static_cast<VisualSymbol *>(symbol)->setScale(x, y);
		}
	}
}

void SymbolAdapt::setScale(float scale) {
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->setScale(scale, scale);
	}
}

void SymbolAdapt::setVisibility(bool value) {
	if (symbol->obType & VISUAL_SYMBOL) {
		static_cast<VisualSymbol *>(symbol)->setVisibility(value);
	}
}

bool SymbolAdapt::getVisibility() {
	if (symbol->obType & VISUAL_SYMBOL) {
		return static_cast<VisualSymbol *>(symbol)->isVisible();
	}
}

// Simple Visual Symbol
int SymbolAdapt::getLineWidth() {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		return static_cast<SimpleVisualSymbol *>(symbol)->lineWidth;
	}
}

void SymbolAdapt::setLineWidth(int lineWidth) {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		static_cast<SimpleVisualSymbol *>(symbol)->setLineWidth(lineWidth);
	} else {
		std::cerr << "[SymbolAdapt::setLineWidth] symbol nie je simple visual" << std::endl;
	}
}

void SymbolAdapt::setFgColor(std::string color) {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		static_cast<SimpleVisualSymbol *>(symbol)->setFgColor(Util::colorNameToCode(color));
	}
}

std::string SymbolAdapt::getFgColor() {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		return static_cast<SimpleVisualSymbol *>(symbol)->fgColor.name().toStdString();
	}
	return std::string("");
}

void SymbolAdapt::setFgStyle(int style) {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		static_cast<SimpleVisualSymbol *>(symbol)->setFgStyle(style);
	}
}
int SymbolAdapt::getFgStyle() {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		return static_cast<SimpleVisualSymbol *>(symbol)->getFgStyle();
	}
}

void SymbolAdapt::setBgColor(std::string color) {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		static_cast<SimpleVisualSymbol *>(symbol)->setBgColor(Util::colorNameToCode(color));
	}
}

std::string SymbolAdapt::getBgColor() {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		return static_cast<SimpleVisualSymbol *>(symbol)->bgColor.name().toStdString();
	}
	return std::string("");
}

void SymbolAdapt::setBgStyle(int style) {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		static_cast<SimpleVisualSymbol *>(symbol)->setBgStyle(style);
	}
}
int SymbolAdapt::getBgStyle() {
	if (symbol->obType & SIMPLE_VISUAL_SYMBOL) {
		return static_cast<SimpleVisualSymbol *>(symbol)->getBgStyle();
	}
}

//ARC
void SymbolAdapt::setAngleStart(int angleStart) {
	if (symbol->obType & ARC) {
		static_cast<Arc *>(symbol)->setAngleStart(angleStart);
	}
}

int SymbolAdapt::getAngleStart() {
	if (symbol->obType & ARC) {
		return static_cast<Arc *>(symbol)->getAngleStart();
	}
}

void SymbolAdapt::setAngleSize(int angleSize) {
	if (symbol->obType & ARC) {
		static_cast<Arc *>(symbol)->setAngleSize(angleSize);
	}
}

int SymbolAdapt::getAngleSize() {
	if (symbol->obType & ARC) {
		return static_cast<Arc *>(symbol)->getAngleSize();
	}
}

bool SymbolAdapt::setArcType(int arcType) {
	if (symbol->obType & ARC) {
		static_cast<Arc *>(symbol)->setArctype(arcType);
	}
}

int SymbolAdapt::getArcType() {
	if (symbol->obType & ARC) {
		return static_cast<Arc *>(symbol)->arctype;
	}
}

// LINE
void SymbolAdapt::setStart(int x, int y) {
	if (symbol->obType & LINE) {
		static_cast<Line*>(symbol)->setStart(x, y);
	}
}

void SymbolAdapt::setEnd(int x, int y) {
	if (symbol->obType & LINE) {
		static_cast<Line*>(symbol)->setEnd(x, y);
	}
}

// BaseLabel
int SymbolAdapt::getFontSize() {
	if (symbol->obType & BASE_LABEL) {
		return static_cast<BaseLabel *>(symbol)->getFont().getSize();
	}
}

void SymbolAdapt::setFontSize(int size) {
	if (symbol->obType & BASE_LABEL) {
		//TODO(vlado): asi by bolo lepsie spravit (symbol)->setFontSize();
		static_cast<BaseLabel *>(symbol)->getFont().setSize(size);
		static_cast<BaseLabel *>(symbol)->update();
	}
}

int SymbolAdapt::getFontName() {
	if (symbol->obType & BASE_LABEL) {
		return static_cast<BaseLabel *>(symbol)->getFont().getName();
	}
}

bool SymbolAdapt::setFontName(int fontName) {
	if (symbol->obType & BASE_LABEL) {
		static_cast<BaseLabel *>(symbol)->getFont().setName(fontName);
		static_cast<BaseLabel *>(symbol)->update();
	}
}

int SymbolAdapt::getFontStyle() {
	if (symbol->obType & BASE_LABEL) {
		return static_cast<BaseLabel *>(symbol)->getFont().getStyle();

	}
}

bool SymbolAdapt::setFontStyle(int fontStyle) {
	if (symbol->obType & BASE_LABEL) {
		static_cast<BaseLabel *>(symbol)->getFont().setStyle(fontStyle);
		static_cast<BaseLabel *>(symbol)->update();
	}
}

int SymbolAdapt::getAlignment() {
	if (symbol->obType & BASE_LABEL) {
		return static_cast<BaseLabel *>(symbol)->getFont().getAlign();
	}
}

bool SymbolAdapt::setAlignment(int alignment) {
	if (symbol->obType & BASE_LABEL) {
		static_cast<BaseLabel *>(symbol)->getFont().setAlign(alignment);
		static_cast<BaseLabel *>(symbol)->update();
	}
}

//Label & ValueDisplays
bool SymbolAdapt::getWriteEnabled() {
	if (symbol->obType & LABEL) {
		return static_cast<Label *>(symbol)->writeEnabled;
	} else if (symbol->obType & VALUE_DISPLAY) {
		return static_cast<ValueDisplay *>(symbol)->writeEnabled;
	}

	return false;
}

// TODO: toto zrejme bude treba prerobit na setter aby sa objekt dozvedel o zmnene povolenia zapisu
void SymbolAdapt::setWriteEnabled(bool enabled) {
	if (symbol->obType & LABEL) {
		static_cast<Label *>(symbol)->writeEnabled = enabled;
	} else if (symbol->obType & VALUE_DISPLAY) {
		static_cast<ValueDisplay *>(symbol)->writeEnabled = enabled;
	}
}

std::string SymbolAdapt::getText() {
	if (symbol->obType & LABEL) {
		return static_cast<Label *>(symbol)->getText();
	} else if (symbol->obType & STATIC_LABEL) {
		return static_cast<StaticLabel *>(symbol)->getText();
	}
	return "";
}

void SymbolAdapt::setText(std::string text) {
	if (symbol->obType & LABEL) {
		static_cast<Label *>(symbol)->setText(text);
	} else if (symbol->obType & STATIC_LABEL) {
		static_cast<StaticLabel *>(symbol)->setText(text);
	}
}

//Image
int SymbolAdapt::getExtension() {
	if (symbol->obType & IMAGE) {
		return static_cast<Image *>(symbol)->extension;
	}
	return -1;
}

SymbolAdapt* SymbolAdapt::getSymbol(std::string name) {
	if (symbol->obType & COMPOUND_SYMBOL)
		return static_cast<CompoundSymbolAdapt *>(this)->getSymbol(name);
	else
		return NULL;
}
