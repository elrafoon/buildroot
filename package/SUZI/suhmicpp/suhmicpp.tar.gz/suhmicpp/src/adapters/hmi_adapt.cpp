/*
 * hmi_adapt.cpp
 *
 *  Created on: Dec 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/hmi.h"
#include "suhmicpp/adapters/hmi_adapt.h"

HmiAdapt::HmiAdapt() :
	ObjectBaseAdapt(), hmi(NULL) {
}

/**
 * Nastavi adaptovany objekt.
 * Kodom hmi nastavi pointer hmi na seba. Pre okna hmi vytvori WindowAdaptery a nastavi ich.
 */
void HmiAdapt::setAdaptee(Hmi *hmi) {
	this->hmi = hmi;

	this->hmi->oncreate.handlerCode.setHmiSelf(this);
	this->hmi->ondestroy.handlerCode.setHmiSelf(this);

	GenericScriptList::GenericScriptVector::iterator jt;
	for (jt = hmi->genericScriptList.genericScript.begin(); jt != hmi->genericScriptList.genericScript.end(); ++jt) {
		(*jt)->script.code.setHmiSelf(this);
	}

	WindowList::WindowVector::iterator it;
	for (it = hmi->windowList.windows.begin(); it != hmi->windowList.windows.end(); ++it) {
		WindowAdapt *windowAdapt = new WindowAdapt();
		windowAdapt->setAdaptee(*it);
		windowAdapt->setParent(this);
		this->windows[(*it)->name] = windowAdapt;
	}
}

HmiAdapt* HmiAdapt::getParent(){
	return NULL;
}

/**
 * Vrati verziu runtime. 'workstation' alebo 'embedded'
 */
std::string HmiAdapt::getRuntimePlatform(){
	return std::string("embedded");
}

void HmiAdapt::setColor(std::string color) {
	hmi->bgColor.setNamedColor(color.c_str());
}

std::string HmiAdapt::getColor() {
	return hmi->bgColor.name().toStdString();
}

/**
 * Vrati pointer na Window s menom name.
 * \retval NULL ak okno s pozadovanym menom neexistuje.
 */
WindowAdapt* HmiAdapt::getWindow(std::string name) {
	WindowMap::iterator it = windows.find(name);
	if (it == windows.end()) {
		return NULL;
	} else {
		return it->second;
	}
}

WindowAdapt* HmiAdapt::getDefaultWindow() {
	std::string name = hmi->windowList.defaultWindow;
	WindowMap::iterator it = windows.find(name);
	if (it == windows.end()) {
		return NULL;
	} else {
		return it->second;
	}
}

std::string HmiAdapt::getAppName() {
	return hmi->appName;
}

std::string HmiAdapt::getAppVersion() {
	return hmi->appVersion;
}

std::string HmiAdapt::getMadeFor() {
	return hmi->madeFor;
}

std::string HmiAdapt::getAuthor() {
	return hmi->author;
}

std::string HmiAdapt::getCompany() {
	return hmi->company;
}

std::string HmiAdapt::getDate() {
	return hmi->date;
}

void HmiAdapt::exit(){
	hmi->exitApp();
}
