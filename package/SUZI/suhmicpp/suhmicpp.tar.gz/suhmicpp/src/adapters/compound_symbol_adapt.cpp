/*
 * compound_symbol_adapt.cpp
 *
 *  Created on: Oct 14, 2011
 *      Author: vlado
 */

#include "suhmicpp/adapters/compound_symbol_adapt.h"

CompoundSymbolAdapt::CompoundSymbolAdapt(CompoundSymbol * cs) : SymbolAdapt(cs){
	for(CompoundSymbol::SybolVector::iterator s = cs->symbols.begin(); s!= cs->symbols.end(); ++s){
		SymbolAdapt *sa = new SymbolAdapt(*s);
		symbolAdapts[(*s)->name] = sa;
		sa->setCSParent(this);
	}
}

SymbolAdapt* CompoundSymbolAdapt::getSymbol(std::string name){
	SymbolAdaptMap::iterator it = symbolAdapts.find(name);
	if (it == symbolAdapts.end()) {
		return NULL;
	} else {
		return it->second;
	}
}
/*
 *
 * 			std::vector<Symbol*>::iterator kt;
			for (kt = static_cast<CompoundSymbol *> ((*jt))->symbols.begin(); kt != static_cast<CompoundSymbol *> ((*jt))->symbols.end(); ++kt) {
				SymbolAdapt *symbolAdapt = new SymbolAdapt(*kt);
				symbolAdapt->parent = this;
			}
 *
 */
