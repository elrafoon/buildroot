/*
 * object_base_adapt.cpp
 *
 *  Created on: Jan 19, 2011
 *      Author: vlado
 */

#include "suhmicpp/adapters/object_base_adapt.h"

ObjectBaseAdapt* ObjectBaseAdapt::getParent(){
	return NULL;
}
