/*
 * window_adapt.cpp
 *
 *  Created on: Dec 13, 2010
 *      Author: vlado
 */

#include <utility>
#include "suhmicpp/adapters/window_adapt.h"
#include "suhmicpp/symbols/compound_symbol.h"

WindowAdapt::WindowAdapt() :
		ObjectBaseAdapt(), window(NULL) {
}

void WindowAdapt::setAdaptee(Window *window) {
	this->window = window;

	this->window->oncreate.handlerCode.setWindowSelf(this);
	this->window->ondestroy.handlerCode.setWindowSelf(this);
	this->window->onshow.handlerCode.setWindowSelf(this);
	this->window->onhide.handlerCode.setWindowSelf(this);

	GenericScriptList::GenericScriptVector::iterator it;
	for (it = window->genericScriptList.genericScript.begin(); it != window->genericScriptList.genericScript.end(); ++it) {
		(*it)->script.code.setWindowSelf(this);
	}

	SymbolList::SymbolVector::iterator jt;
	for (jt = window->symbolList.symbol.begin(); jt != window->symbolList.symbol.end(); ++jt) {
		if ((*jt)->obType & COMPOUND_SYMBOL) {
			CompoundSymbol *cs = static_cast<CompoundSymbol *>(*jt);
			CompoundSymbolAdapt *compoundSymbolAdapt = new CompoundSymbolAdapt(cs);
			compoundSymbolAdapt->setWinParent(this);
			this->symbols[(*jt)->name] = compoundSymbolAdapt;
		} else {
			SymbolAdapt *symbolAdapt = new SymbolAdapt(*jt);
			symbolAdapt->setWinParent(this);
			this->symbols[(*jt)->name] = symbolAdapt;
		}
	}
}

void WindowAdapt::setParent(HmiAdapt *parent) {
	this->parent = parent;
}

HmiAdapt* WindowAdapt::getParent() {
	return parent;
}

void WindowAdapt::setName(std::string name) {
	window->name = name.c_str();
}

std::string WindowAdapt::getName() {
	return window->name;
}

SymbolAdapt* WindowAdapt::getSymbol(std::string name) {
	SymbolMap::iterator it = symbols.find(name);
	if (it == symbols.end()) {
		return NULL;
	} else {
		return it->second;
	}
}

std::string WindowAdapt::getBgColor() {
	return window->bgColor.name().toStdString();
}

void WindowAdapt::setBgColor(std::string color) {
	window->bgColor.setNamedColor(color.c_str());
}

std::pair<int, int> WindowAdapt::getSize() {
	std::pair<int, int> size;
	size.first = window->size.width();
	size.first = window->size.height();
	return size;
}

void WindowAdapt::setSize(int width, int height) {
	window->setSize(width, height);
}

std::pair<int, int> WindowAdapt::getPosition() {
	return std::pair<int, int>(0, 0);
}

void WindowAdapt::setPosition(int x, int y) {

}

void WindowAdapt::setVisibility(bool value) {
	window->setVisibility(value);
}

bool WindowAdapt::getVisibility() {
	return window->getVisibility();
}

int WindowAdapt::getType() {
	return 0;
}

void WindowAdapt::printScreen(std::string fullFfileName) {
	window->printScreen(fullFfileName);
}

void WindowAdapt::hardCopy(std::string printerName, int size, int orientation, bool fitToPage){
	window->hardCopy(printerName, size, orientation, fitToPage);
}
