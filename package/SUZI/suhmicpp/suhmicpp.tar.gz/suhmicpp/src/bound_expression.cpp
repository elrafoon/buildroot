/*
 * bound_expression.cpp
 *
 *  Created on: Sep 30, 2010
 *      Author: vlado
 */

#include "suhmicpp/bound_expression.h"
#include <time.h>
#include <algorithm>
#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/result_listener.h"
#include "suhmicpp/symbols/label.h"

BoundExpression::BoundExpression(ObjectBase *ob, ResultListener *resultListener) :
	SuhubConnectorLight::UpdateListener(), PrefixedLogger("BoundExpression: "), expression(ob, this), resultListener(resultListener) {
}

BoundExpression::BoundExpression(const BoundExpression &be) :
	expression(be.expression), inputList(be.inputList), sensitivityList(be.sensitivityList), resultListener(be.resultListener) {
}

BoundExpression::BoundExpression(const BoundExpression &be, ObjectBase *ob, ResultListener *resultListener = NULL) :
	expression(be.expression, ob), inputList(be.inputList), sensitivityList(be.sensitivityList), resultListener(resultListener) {
	fini();
}

/**
 * Skontruluje ci sa zmenil tag zo sensitivityListu, pripadne vykona expression a vysledok odovzda resultListenerovi tzn. objektu triedy Link.
 */
void BoundExpression::onUpdate(const SuhubConnectorLight::UpdateList &updateList) {
#ifdef PROFILE_TIMER
	std::string timerName("BoundExpression::onUpdate");
	ProfileTimer t(timerName);
#endif
	bool execute = false;

	SuhubConnectorLight::UpdateList::const_iterator it;
	for (it = updateList.begin(); it != updateList.end(); ++it) {
		log(LM_DEBUG, "Update: %s %f", (*it).pTag->name.c_str(), (*it).vtq.v);

		// Zistim ci prisiel update na tag zo sensitivityListu
		TagList::StatefulTagVector::iterator jt;
		for (jt = sensitivityList.tags.begin(); jt != sensitivityList.tags.end(); ++jt) {
			if ((*it).pTag->name.compare((*jt)->name) == 0) {
				execute = true;
				break;
			}
		}
		if (execute) // ak uz viem, ze sa ma sputit, nemusim dalej hladat
			break;
	}
	if (execute) {
		log(LM_DEBUG, "Update tagu zo sensitivity listu");
		if (resultListener->resultType == ResultListener::STRING) {
			std::string text;
			int rv = expression.exec(updateList, text);
			switch (rv) {
			case -1:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "Error occured in expression.");
				break;
			case 0:
				resultListener->handleResult(text);
				break;
			case 1:
				// pass
				break;
			case 2:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "result is neither a string nor a None.");
				break;

			default:
				break;
			}
		} else if (resultListener->resultType == ResultListener::BOOL_INT) {
			bool result;

			int rv = expression.exec(updateList, result);
			switch (rv) {
			case -1:
				log(LM_ERROR, "Error occured in expression.");
				break;
			case 0:
				resultListener->handleResult(result);
				break;
			case 1:
				// pass
				break;
			case 2:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "result is neither a bool nor a None.");
				break;

			default:
				break;
			}
		} else if (resultListener->resultType == ResultListener::INT_DOUBLE) {
			double result = 0;
			int rv = expression.exec(updateList, result);
			switch (rv) {
			case -1:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "Error occured in expression.");
				break;
			case 0:
				resultListener->handleResult(result);
				break;
			case 1:
				// pass
				break;
			case 2:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "result is neither a number nor a None.");
				break;

			default:
				break;
			}
		} else if (resultListener->resultType == ResultListener::PERC) {
			double result = 0;
			int rv = expression.exec(updateList, result);
			switch (rv) {
			case -1:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "Error occured in expression.");
				break;
			case 0:
				if (result > 100) {
					log(LM_ERROR, "%s", expression.getPathString().c_str());
					log(LM_WARNING, "Result from FillLink should be from interval <0, 100>. Actual result: %f.", result);
					result = 100;
				}
				if (result < 0) {
					log(LM_ERROR, "%s", expression.getPathString().c_str());
					log(LM_WARNING, "Result from FillLink should be from interval <0, 100>. Actual result: %f.", result);
					result = 0;
				}
				resultListener->handleResult(result);
				break;
			case 1:
				// pass
				break;
			case 2:
				log(LM_ERROR, "%s", expression.getPathString().c_str());
				log(LM_ERROR, "result is neither a number nor a None.");
				break;

			default:
				break;
			}
		} else {
			log(LM_ERROR, "ResultListener has unknown type.");
		}
	}
}

void BoundExpression::setAttributes(const QXmlAttributes &attributes) {
	expression.setCode(attributes.value("expression").toStdString());
}

/**
 * Nahradi tagy v expression, input a sensitivityListe.
 */
void BoundExpression::replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable) {
	expression.replaceTags(replacementTable, &inputList.tags, &sensitivityList.tags);

	std::map<std::string, SuhubConnectorLight::StatefulTag *>::iterator replacement;
	for (replacement = replacementTable.begin(); replacement != replacementTable.end(); ++replacement) {
		std::string oldName = (*replacement).first;
		std::string newName = (*replacement).second->name;

		TagList::StatefulTagVector::iterator jt = std::find_if(inputList.tags.begin(), inputList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != inputList.tags.end()) {
			inputList.tags.erase(jt);
			inputList.uniquePush((*replacement).second);
		}

		jt = std::find_if(sensitivityList.tags.begin(), sensitivityList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != sensitivityList.tags.end()) {
			sensitivityList.tags.erase(jt);
			sensitivityList.uniquePush((*replacement).second);
		}
	}
}

void BoundExpression::fini() {
	for (TagList::StatefulTagVector::iterator it = inputList.tags.begin(); it != inputList.tags.end(); ++it) {
		expression.addTag(*it);
	}

	for (TagList::StatefulTagVector::iterator it = sensitivityList.tags.begin(); it != sensitivityList.tags.end(); ++it) {
		expression.addTag(*it);
	}
}
