/*
 * main.cpp
 *
 *  Created on: Jul 6, 2010
 *      Author: vlado
 */
/*! \mainpage Suhmi-cpp
 *
 * \section symbols_sec Symbols
 * \link VisualSymbol VisualSymbol \endlink \n
 * \link SimpleVisualSymbol SimpleVisualSymbol \endlink \n
 *
 * \section graphs_sec Graphs
 * \link OnlineGraph OnlineGraph \endlink \n
 *
 * \section adapters_sec Adapters
 * \link ObjectBaseAdapt ObjectBaseAdapt \endlink \n
 * \link HmiAdapt HmiAdapt \endlink \n
 * \link SymbolAdapt SymbolAdapt \endlink \n
 * \link WindowAdapt WindowAdapt \endlink \n
 */

//Hlavne, ze sme zdravi
#include <QtGui>
#include <vector>
#include <string>
#include <sys/stat.h>
#include <ace/streams.h>
#include <ace/Service_Config.h>
#include <ace/Log_Msg.h>
#include <ace/Dynamic_Service.h>
#include <ace/Logging_Strategy.h>
#include "WidgetKeyboard.h"
#include "suhmicpp/swindow.h"
#include "suhmicpp/window/window.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/util/config.h"
#include "scl/hlapi/connector.h"
#include "suhmicpp/error_indication/error_button.h"
#ifdef GPROF_HEAP
#include <google/heap-profiler.h>
#endif
#ifdef GPROF_CPU
#include <google/profiler.h>
#endif

#define confFile "/etc/suhmicpp/suhmi-cpp.conf"

SuhubConnectorLight::Connector *con = NULL;
HmiAdapt *hmiAdapt;
HmiAdapt *currentHmi;
SymbolAdapt *currentSymbol;
WindowAdapt *currentWindow;

WidgetKeyboard *virtualKeyBoard;

ErrorButton *errorButton;
int opterr = 0; //getopt

/**
 * Prida do PYTHONPATH cestu z konfiguracneho suboru basePythonDir.
 */
void updatePythonPath() {
	char *pyPath = getenv("PYTHONPATH");
	std::string path;
	if (pyPath) {
		path += pyPath;
	}
	path += ":";
	path += config->basePythonDir;
	if (setenv("PYTHONPATH", path.c_str(), 1)) {
		//logger.log(LM_ERROR, "Setting PYTHONPATH failed!");
	}
}

void printHelp() {
	std::cout << "Usage: suhmicpp [OPTION]\nor:\tsuhmicpp -o filename" << std::endl;
	std::cout << "-v\t output version information and exit" << std::endl;
	std::cout << "-h\t show this help" << std::endl;
}

int main(int argc, char *argv[]) {

	int c;
	QString fileName("");
	int svcFileNamePosition = 0;
	while ((c = getopt(argc, argv, "hvo:f:q:")) != -1){
		switch (c) {
		case 'h':
			printHelp();
			exit(EXIT_SUCCESS);
			break;
		case 'v':
			std::cout << "Version: " << VER << std::endl;
			exit(EXIT_SUCCESS);
			break;
		case 'o':
			fileName = optarg;
			break;
		case 'f':
			svcFileNamePosition = optind-1;
			break;
		case 'q':
			//ignore qws
			break;
		case '?':
			std::cerr << "Option " << (char)optopt << " requires an argument." << std::endl;
			return EXIT_FAILURE;
		default:
			break;
		}
	}

	char* aceArgv[] = {(char*)"suhmicpp",(char*)"-f", (char*)argv[svcFileNamePosition]};
	if(ACE_Service_Config::open(4, aceArgv, ACE_DEFAULT_LOGGER_KEY, 0, 0, 1) == -1){
		std::cerr<< "ACE Service Configuration was not opened. " << strerror(errno) <<std::endl;
	}

    ACE_Logging_Strategy *ls = ACE_Dynamic_Service<ACE_Logging_Strategy>::instance("Logger");
    if(ls)
        ls->log_msg(ACE_LOG_MSG);

	int ret = -1;
	{
		config = new Configuration(confFile);
		updatePythonPath();
		Py_SetProgramName("suhmi-cpp");
		Py_Initialize();
		hmiAdapt = new HmiAdapt();

		QApplication app(argc, argv);
		QStringList arguments = QCoreApplication::arguments();
		errorButton = new ErrorButton;
		QPixmap pixmap(":/images/suzi_banner.jpg");
		QSplashScreen splash(pixmap);
		splash.show();
		app.processEvents();

#ifdef GPROF_HEAP
		HeapProfilerStart("suhmi.hprof");
#endif
#ifdef GPROF_CPU
		ProfilerStart("suhmi.cprof");
#endif
		SWindow *mainWindow = new SWindow(fileName);

		virtualKeyBoard = new WidgetKeyboard(mainWindow);
		splash.finish(mainWindow);

		ret = app.exec();
#ifdef GPROF_HEAP
		HeapProfilerStop();
#endif
#ifdef GPROF_CPU
		ProfilerStop();
#endif
		delete mainWindow;
	}
	std::cout << "Py_Finalize" << std::endl;
	Py_Finalize();
	return ret;
}
