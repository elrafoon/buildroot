#include "suhmicpp/links/positionlink.h"
#include "suhmicpp/symbols/visual_symbol.h"

HorizontalPositionLink::HorizontalPositionLink(VisualSymbol *vs) : Link(vs){
	resultType = INT_DOUBLE;
	QObject::connect((QObject *)this, SIGNAL(horPositionChanged(long)), (QObject *)vs, SLOT(setHorPosition(long)));
	identification = "HorizontalPositionLink";
}

HorizontalPositionLink::HorizontalPositionLink(const  HorizontalPositionLink &hpl, VisualSymbol *vs) : Link(hpl, vs){
	QObject::connect((QObject *)this, SIGNAL(horPositionChanged(long)), (QObject *)vs, SLOT(setHorPosition(long)));
}

VerticalPositionLink::VerticalPositionLink(VisualSymbol *vs) : Link(vs){
	resultType = INT_DOUBLE;
	QObject::connect((QObject *)this, SIGNAL(vertPositionChanged(long)), (QObject *)vs, SLOT(setVertPosition(long)));
	identification = "VerticalPositionLink";
}

VerticalPositionLink::VerticalPositionLink(const VerticalPositionLink &vpl, VisualSymbol *vs) : Link(vpl, vs){

}

void HorizontalPositionLink::handleResult(double result){
	emit horPositionChanged((long)result);
}

void VerticalPositionLink::handleResult(double result){
	emit vertPositionChanged((long)result);
}
