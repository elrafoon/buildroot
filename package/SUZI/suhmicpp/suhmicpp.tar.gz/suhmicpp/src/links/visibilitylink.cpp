#include "suhmicpp/links/visibilitylink.h"
#include "suhmicpp/symbols/visual_symbol.h"


VisibilityLink::VisibilityLink(VisualSymbol *vs): Link(vs) {
	resultType = BOOL_INT;
	QObject::connect((QObject *)this, SIGNAL(visibilityChanged(bool)), (QObject *)vs, SLOT(setVisibility(bool)));
	identification = "VisibilityLink";
}

VisibilityLink::VisibilityLink(const VisibilityLink &vl, VisualSymbol *vs) : Link(vl, vs){
	QObject::connect((QObject *)this, SIGNAL(visibilityChanged(bool)), (QObject *)vs, SLOT(setVisibility(bool)));
}

void VisibilityLink::handleResult(bool result){
	emit visibilityChanged((bool)result);
}
