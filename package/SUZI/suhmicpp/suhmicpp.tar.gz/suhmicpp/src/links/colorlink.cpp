/*
 * colorlink.h
 *
 *  Created on: Sep 28, 2010
 *      Author: vlado
 */

#include "suhmicpp/links/colorlink.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/symbols/simple_visual_symbol.h"

ColorLink::ColorLink(VisualSymbol *vs) :
	Link(vs) {
	resultType = INT_DOUBLE;
	qRegisterMetaType<std::string> ("std::string");
	identification = "ColorLink";
}

ColorLink::ColorLink(const ColorLink &cl, VisualSymbol *vs) :
	Link(cl, vs) {

}

BgColorLink::BgColorLink(VisualSymbol *vs) :
	ColorLink(vs) {
	QObject::connect((QObject *) this, SIGNAL(bgColorChanged(std::string)), (QObject *) (SimpleVisualSymbol *) vs, SLOT(setBgColor(std::string)));
	identification = "BgColorLink";
}

BgColorLink::BgColorLink(const BgColorLink &bcl, VisualSymbol *vs) :
	ColorLink(bcl, vs) {

}

FgColorLink::FgColorLink(VisualSymbol *vs) :
	ColorLink(vs) {
	QObject::connect((QObject *) this, SIGNAL(fgColorChanged(std::string)), (QObject *) (SimpleVisualSymbol *) vs, SLOT(setFgColor(std::string)));
	identification = "FgColorLink";
}

FgColorLink::FgColorLink(const FgColorLink &fcl, VisualSymbol *vs) :
	ColorLink(fcl, vs) {

}

void BgColorLink::handleResult(double result) {
	for (RangeValueList::RangeValueVector::iterator it = colorTable.rangeValueItem.begin(); it < colorTable.rangeValueItem.end(); it++) {
		if (result >= (int) (*it)->rangeLow && result < (int) (*it)->rangeHigh) {
			emit bgColorChanged((*it)->value.toStdString());
		}
	}
}

void FgColorLink::handleResult(double result) {
	for (RangeValueList::RangeValueVector::iterator it = colorTable.rangeValueItem.begin(); it < colorTable.rangeValueItem.end(); it++) {
		if (result >= (int) (*it)->rangeLow && result < (int) (*it)->rangeHigh) {
			emit fgColorChanged((*it)->value.toStdString());
		}
	}
}
