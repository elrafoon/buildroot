
#include "suhmicpp/links/sizelink.h"
#include "suhmicpp/symbols/visual_symbol.h"

VerticalSizeLink::VerticalSizeLink(VisualSymbol *vs) : Link(vs){
	resultType = INT_DOUBLE;
	QObject::connect((QObject *)this, SIGNAL(vertSizeChanged(long)), (QObject *)vs, SLOT(setVertSize(long)));
	identification = "VerticalSizeLink";
}

VerticalSizeLink::VerticalSizeLink(const VerticalSizeLink &vsl, VisualSymbol *vs) : Link(vsl, vs){
	QObject::connect((QObject *)this, SIGNAL(vertSizeChanged(long)), (QObject *)vs, SLOT(setVertSize(long)));
}

HorizontalSizeLink::HorizontalSizeLink(VisualSymbol *vs) : Link(vs){
	resultType = INT_DOUBLE;
	QObject::connect((QObject *)this, SIGNAL(horSizeChanged(long)), (QObject *)vs, SLOT(setHorSize(long)));
	identification = "HorizontalSizeLink";
}

HorizontalSizeLink::HorizontalSizeLink(const HorizontalSizeLink &hsl, VisualSymbol *vs) : Link(hsl, vs){
	QObject::connect((QObject *)this, SIGNAL(horSizeChanged(long)), (QObject *)vs, SLOT(setHorSize(long)));
}

void VerticalSizeLink::handleResult(double result){
	emit vertSizeChanged((long)result);
}

void HorizontalSizeLink::handleResult(double result){
	emit horSizeChanged((long)result);
}
