/*
 * link.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/links/link.h"
#include "suhmicpp/symbols/visual_symbol.h"

Link::Link(VisualSymbol *vs) :
	ResultListener(), boundExpression(vs, this), vs(vs) {
}

Link::Link(const Link &l) :
	ResultListener(l), boundExpression(l.boundExpression, vs, this) {
}

Link::Link(const Link &l, VisualSymbol *vs) :
	ResultListener(l), boundExpression(l.boundExpression, vs, this), vs(vs) {
}

void Link::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	boundExpression.expression.setDebugInfo(this->debugInfo, identification);
}
