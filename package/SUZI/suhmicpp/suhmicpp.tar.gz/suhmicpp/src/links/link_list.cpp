/*
 * link_list.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef LINK_LIST_CPP_
#define LINK_LIST_CPP_

#include "suhmicpp/links/link_list.h"
#include "suhmicpp/symbols/visual_symbol.h"

LinkList::LinkList(VisualSymbol *vs) :
	bgBlinkLink(vs), fgBlinkLink(vs), bgColorLink(vs), fgColorLink(vs), horizontalFillLink(vs), horizontalPositionLink(vs), horizontalSizeLink(vs), rotationLink(vs), verticalFillLink(vs),
			verticalSizeLink(vs), verticalPositionLink(vs), visibilityLink(vs) {

}

LinkList::LinkList(const LinkList &ll, VisualSymbol* vs = NULL) :
	bgBlinkLink(ll.bgBlinkLink, vs), fgBlinkLink(ll.fgBlinkLink, vs), bgColorLink(ll.bgColorLink, vs), fgColorLink(ll.fgColorLink, vs), horizontalFillLink(ll.horizontalFillLink, vs),
			horizontalPositionLink(ll.horizontalPositionLink, vs), horizontalSizeLink(ll.horizontalSizeLink, vs), rotationLink(ll.rotationLink, vs), verticalFillLink(ll.verticalFillLink, vs),
			verticalSizeLink(ll.verticalSizeLink, vs), verticalPositionLink(ll.verticalPositionLink, vs), visibilityLink(ll.visibilityLink, vs) {
}

void LinkList::replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable) {
	bgBlinkLink.boundExpression.replaceTags(replacementTable);
	fgBlinkLink.boundExpression.replaceTags(replacementTable);
	bgColorLink.boundExpression.replaceTags(replacementTable);
	fgColorLink.boundExpression.replaceTags(replacementTable);
	horizontalFillLink.boundExpression.replaceTags(replacementTable);
	horizontalPositionLink.boundExpression.replaceTags(replacementTable);
	horizontalSizeLink.boundExpression.replaceTags(replacementTable);
	rotationLink.boundExpression.replaceTags(replacementTable);
	verticalFillLink.boundExpression.replaceTags(replacementTable);
	verticalSizeLink.boundExpression.replaceTags(replacementTable);
	verticalPositionLink.boundExpression.replaceTags(replacementTable);
	visibilityLink.boundExpression.replaceTags(replacementTable);
}

void LinkList::compileCodes(){
	bgBlinkLink.boundExpression.expression.compileCode();
	fgBlinkLink.boundExpression.expression.compileCode();
	bgColorLink.boundExpression.expression.compileCode();
	fgColorLink.boundExpression.expression.compileCode();
	horizontalFillLink.boundExpression.expression.compileCode();
	horizontalPositionLink.boundExpression.expression.compileCode();
	horizontalSizeLink.boundExpression.expression.compileCode();
	rotationLink.boundExpression.expression.compileCode();
	verticalFillLink.boundExpression.expression.compileCode();
	verticalSizeLink.boundExpression.expression.compileCode();
	verticalPositionLink.boundExpression.expression.compileCode();
	visibilityLink.boundExpression.expression.compileCode();
}

void LinkList::setSymbolSelf(SymbolAdapt* self){
	bgBlinkLink.boundExpression.expression.setSymbolSelf(self);
	fgBlinkLink.boundExpression.expression.setSymbolSelf(self);
	bgColorLink.boundExpression.expression.setSymbolSelf(self);
	fgColorLink.boundExpression.expression.setSymbolSelf(self);
	horizontalFillLink.boundExpression.expression.setSymbolSelf(self);
	horizontalPositionLink.boundExpression.expression.setSymbolSelf(self);
	horizontalSizeLink.boundExpression.expression.setSymbolSelf(self);
	rotationLink.boundExpression.expression.setSymbolSelf(self);
	verticalFillLink.boundExpression.expression.setSymbolSelf(self);
	verticalSizeLink.boundExpression.expression.setSymbolSelf(self);
	verticalPositionLink.boundExpression.expression.setSymbolSelf(self);
	visibilityLink.boundExpression.expression.setSymbolSelf(self);
}

void LinkList::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	bgBlinkLink.setDebugInfo(this->debugInfo, identification);
	fgBlinkLink.setDebugInfo(this->debugInfo, identification);
	bgColorLink.setDebugInfo(this->debugInfo, identification);
	fgColorLink.setDebugInfo(this->debugInfo, identification);
	horizontalFillLink.setDebugInfo(this->debugInfo, identification);
	verticalFillLink.setDebugInfo(this->debugInfo, identification);
	horizontalPositionLink.setDebugInfo(this->debugInfo, identification);
	verticalPositionLink.setDebugInfo(this->debugInfo, identification);
	horizontalSizeLink.setDebugInfo(this->debugInfo, identification);
	verticalSizeLink.setDebugInfo(this->debugInfo, identification);
	rotationLink.setDebugInfo(this->debugInfo, identification);
	visibilityLink.setDebugInfo(this->debugInfo, identification);
}
#endif /* LINK_LIST_CPP_ */
