#include "suhmicpp/links/rotationlink.h"
#include "suhmicpp/symbols/visual_symbol.h"

RotationLink::RotationLink(VisualSymbol *vs) : Link(vs){
	resultType = INT_DOUBLE;
	QObject::connect((QObject *)this, SIGNAL(rotationChanged(long)), (QObject *)vs, SLOT(setRotation(long)));
	identification = "RotationLink";
}

RotationLink::RotationLink(const RotationLink &rl, VisualSymbol *vs) : Link(rl, vs){
	QObject::connect((QObject *)this, SIGNAL(rotationChanged(long)), (QObject *)vs, SLOT(setRotation(long)));
}

void RotationLink::handleResult(double result){
	emit rotationChanged((long)result);
}
