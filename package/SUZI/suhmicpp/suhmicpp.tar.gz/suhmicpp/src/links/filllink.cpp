#include "suhmicpp/links/filllink.h"
#include "suhmicpp/symbols/visual_symbol.h"

HorizontalFillLink::HorizontalFillLink(VisualSymbol *vs) : Link(vs){
	resultType = PERC;
	QObject::connect((QObject *)this, SIGNAL(horFillChanged(long)), (QObject *)vs, SLOT(setHorFill(long)));
	identification = "HorizontalFillLink";
}

HorizontalFillLink::HorizontalFillLink(const HorizontalFillLink &hfl, VisualSymbol *vs) : Link(hfl, vs){
	QObject::connect((QObject *)this, SIGNAL(horFillChanged(long)), (QObject *)vs, SLOT(setHorFill(long)));
}

VerticalFillLink::VerticalFillLink(VisualSymbol *vs) : Link(vs){
	resultType = PERC;
	QObject::connect((QObject *)this, SIGNAL(vertFillChanged(long)), (QObject *)vs, SLOT(setVertFill(long)));
	identification = "VerticalFillLink";
}

VerticalFillLink::VerticalFillLink(const VerticalFillLink &vfl, VisualSymbol *vs): Link(vfl, vs){
	QObject::connect((QObject *)this, SIGNAL(vertFillChanged(long)), (QObject *)vs, SLOT(setVertFill(long)));
}

void HorizontalFillLink::handleResult(double result){
	emit horFillChanged((long)result);
}

void VerticalFillLink::handleResult(double result){
	emit vertFillChanged((long)result);
}
