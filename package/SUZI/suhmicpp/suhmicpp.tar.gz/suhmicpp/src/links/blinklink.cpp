#include <QString>
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/links/blinklink.h"

BlinkLink::BlinkLink(VisualSymbol *vs) :
	Link(vs), period(1), ticks(0), blink(false){
	//QObject::connect((QObject *)this, SIGNAL(valueChanged(long)), (QObject *)	vs, SLOT(setValue(long)));
	resultType = BOOL_INT;
	identification = "BlinkLink";
}

BlinkLink::BlinkLink(const BlinkLink &bl, VisualSymbol *vs) :
	Link(bl, vs), period(bl.period), ticks(0), blink(false), blinkColor(bl.blinkColor){
	identification = "BgBlinkLink";
}

BgBlinkLink::BgBlinkLink(VisualSymbol *vs) :
	BlinkLink(vs) {
	QObject::connect((QObject *) this, SIGNAL(blinkChanged()), (QObject *) vs, SLOT(changeBgBlinkState()));
}

BgBlinkLink::BgBlinkLink(const BgBlinkLink &bbl, VisualSymbol *vs) :
	BlinkLink(bbl, vs) {
	QObject::connect((QObject *) this, SIGNAL(blinkChanged()), (QObject *) vs, SLOT(changeBgBlinkState()));
}

BgBlinkLink::~BgBlinkLink(){
	QObject::disconnect((QObject *) this, SIGNAL(blinkChanged()), (QObject *) vs, SLOT(changeBgBlinkState()));
}

FgBlinkLink::FgBlinkLink(VisualSymbol *vs) :
	BlinkLink(vs) {
	QObject::connect((QObject *) this, SIGNAL(blinkChanged()), (QObject *) vs, SLOT(changeFgBlinkState()));
	identification = "FgBlinkLink";
}

FgBlinkLink::FgBlinkLink(const FgBlinkLink &fbl, VisualSymbol *vs) :
	BlinkLink(fbl, vs) {
	QObject::connect((QObject *) this, SIGNAL(blinkChanged()), (QObject *) vs, SLOT(changeFgBlinkState()));
}

FgBlinkLink::~FgBlinkLink(){
	QObject::disconnect((QObject *) this, SIGNAL(blinkChanged()), (QObject *) vs, SLOT(changeFgBlinkState()));
}

void BlinkLink::setAttributes(const QXmlAttributes &attributes) {
	boundExpression.expression.setCode(attributes.value("blinkWhen").toStdString());
	if (attributes.value(QString("period")).isEmpty()) {
		period = 500; //ms
	} else {
		period = attributes.value("period").toFloat();
	}
	blinkColor.setNamedColor(attributes.value("blinkColor"));
}

void BlinkLink::handleResult(bool result) {
	blink = result;
}

void BgBlinkLink::handleTimeout() {
	//tato funkcia sa zavola kazdych 50 ms
	// period v ms
	const unsigned int timerInterval = 50; //ms
	if (blink) {
		if (ticks < ((period * 1000) / timerInterval)) {
			ticks++;
		} else {
			emit blinkChanged();
			ticks = 0;
		}
	} else {
		// aby sa nastavila povodna farba pozadia ak ma prestat blikat
		if (!vs->bgBlinkState) //blinkState == true znamena vykreslenie povodnou farbou
			emit blinkChanged();
	}
}

void FgBlinkLink::handleTimeout() {
	//tato funkcia sa zavola kazdych 50 ms
	// period v ms
	const unsigned int timerInterval = 50; //ms
	if (blink) {
		if (ticks < ((period * 1000) / timerInterval)) {
			ticks++;
		} else {
			emit blinkChanged();
			ticks = 0;
		}
	} else {
		// aby sa nastavila povodna farba pozadia ak ma prestat blikat
		if (!vs->fgBlinkState) //blinkState == true znamena vykreslenie povodnou farbou
			emit blinkChanged();
	}
}
