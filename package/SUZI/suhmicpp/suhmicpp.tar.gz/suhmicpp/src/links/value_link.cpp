/*
 * value_link.cpp
 *
 *  Created on: Oct 25, 2010
 *      Author: vlado
 */

#include "suhmicpp/links/value_link.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/symbols/value_display.h"

ValueLink::ValueLink(VisualSymbol *vs) :
	SuhubConnectorLight::UpdateListener(), vs(vs) {
	//resultType = INT;
QObject::connect((QObject *)this, SIGNAL(valueChanged(double)), (QObject *)vs, SLOT(setValue(double)));
}

ValueLink::ValueLink(const ValueLink &vl, VisualSymbol *vs) :
	SuhubConnectorLight::UpdateListener(), vs(vs) {
QObject::connect((QObject *)this, SIGNAL(valueChanged(double)), (QObject *)vs, SLOT(setValue(double)));
}

void ValueLink::setTag(SuhubConnectorLight::StatefulTag *tag) {
	this->tag = tag;
}

void ValueLink::onUpdate(const SuhubConnectorLight::UpdateList &updateList) {
	if (updateList.size() == 1) {
		SuhubConnectorLight::UpdateList::const_iterator valueIt = updateList.begin();
		if ((*valueIt).pTag->name == tag->name) {
			double value = (*valueIt).vtq.v;
			emit valueChanged(value);
		}
	}
}

