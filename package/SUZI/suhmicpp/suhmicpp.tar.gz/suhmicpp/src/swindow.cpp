/*
 * window.cpp
 *
 *  Created on: Jun 28, 2010
 *      Author: vlado
 */

#include <QtGui>
#include <QFile>
#include <ace/Logging_Strategy.h>
#include "suhmicpp/swindow.h"
#include "suhmicpp/connector_instance.h"
#ifdef GPROF_HEAP
#include <google/heap-profiler.h>
#endif
#ifdef GPROF_CPU
#include <google/profiler.h>
#endif
#include "suhmicpp/util/config.h"
#include "suhmicpp/util/prefixed_logger.h"

#define pathToXsd "/usr/share/suhmicpp/schemas/hmi.xsd"
extern SuhubConnectorLight::Connector *con;
extern HmiAdapt *hmiAdapt;

SWindow::SWindow(QString &fileName) :
		QMainWindow(), hmi(NULL), reactorTimer(this), logger("SWINDOW: ") {
#ifdef NO_BORDERS
	setWindowFlags(windowFlags() | Qt::FramelessWindowHint);
#endif

	con = new SuhubConnectorLight::Connector;
	connect(&reactorTimer, SIGNAL(timeout()), this, SLOT(update()));
#ifdef GPROF_HEAP
	connect(&heapTimer, SIGNAL(timeout()), this, SLOT(heapDump()));
	heapTimer.start(1000);
#endif
#ifdef GPROF_CPU
	connect(&cpuTimer, SIGNAL(timeout()), this, SLOT(cpuDump()));
	cpuTimer.start(1000);
#endif
	reactorTimer.start(250);
	scene = new Scene(this);
	view = new View(scene, this);

	setCentralWidget(view);

	init(fileName);
}

SWindow::~SWindow() {
	ACE_Reactor::instance(NULL, 1);
	hmi->destroy(); //spusti onDestroy scripty na vsetkych prvkoch

	//Odstranim prvky zo sceny, inak by ich destruktory volala scena
	QList<QGraphicsItem *> items = scene->items();
	for (int i = 0; i < items.size(); ++i) {
		scene->removeItem(items.at(i));
	}
	delete scene;
	delete view;
}

void SWindow::init(QString &fileName) {
	// Spracovanie xml
	QXmlSimpleReader reader;
	reader.setContentHandler(&handler);
	reader.setErrorHandler(&handler);
	QFile file;
	bool ok = false;
	while (ok != true) {
		if (fileName == "") {
			fileName = QFileDialog::getOpenFileName(this, "Open XML", QDir::currentPath(), "XBEL Files (*.xbel *.xml)");
		}
		file.setFileName(fileName);
		if (file.open(QIODevice::ReadOnly)) {
			QUrl schemaUrl(pathToXsd);
			QXmlSchema schema;
			bool loaded = schema.load(schemaUrl);
			if (schema.isValid()) {
				QXmlSchemaValidator validator(schema);
				int isValid = validator.validate(&file, QUrl::fromLocalFile(fileName));
				if (isValid) {
					logger.log(LM_INFO, "XML instance document is valid");
					ok = true;
				} else {
					logger.log(LM_WARNING, "XML instance document is invalid");
					QMessageBox msgBox(QMessageBox::Warning, "Invalid XML file!", "Invalid XML file! Application may not work properly.\nDo you want to continue?", 0, this);
					msgBox.addButton("Continue", QMessageBox::AcceptRole);
					msgBox.addButton("Select another file", QMessageBox::RejectRole);
					if (msgBox.exec() == QMessageBox::AcceptRole)
						ok = true;
					else
						ok = false;
				}
			} else {
				QMessageBox msgBox(QMessageBox::Warning, "Invalid XSD file!", "Invalid XSD file!", 0, this);
				msgBox.addButton("Continue", QMessageBox::AcceptRole);
				msgBox.addButton("Select another file", QMessageBox::RejectRole);
				if (msgBox.exec() == QMessageBox::AcceptRole)
					ok = true;
				else
					ok = false;
				logger.log(LM_WARNING, "XSD schema is invalid");
			}
			file.close();
		}
		else{
			fileName = QFileDialog::getOpenFileName(this, "Open XML", QDir::currentPath(), "XBEL Files (*.xbel *.xml)");
		}
	}
	QXmlInputSource xmlInputSource(&file);

	struct timeval start, stop;
	gettimeofday(&start, NULL);

	reader.parse(xmlInputSource);
	gettimeofday(&stop, NULL);
	std::cout << "SWindow::init: " << stop.tv_sec - start.tv_sec << "." << stop.tv_usec - start.tv_usec << std::endl;

	hmi = handler.getHmi();
	hmiAdapt->setAdaptee(hmi);
	hmi->scene = getScene();

	logger.log(LM_INFO, "RTagList: ");
	hmi->rTagList.eraseTemplateTags();
	for (std::vector<SuhubConnectorLight::StatefulTag *>::iterator it = hmi->rTagList.tags.begin(); it != hmi->rTagList.tags.end(); ++it) {
		logger.log(LM_INFO, "name: %s\tinternal:%d", (*it)->name.c_str(), (*it)->internal);
	}

	logger.log(LM_INFO, "WTagList: ");
	hmi->wTagList.eraseTemplateTags();
	for (std::vector<SuhubConnectorLight::StatefulTag *>::iterator it = hmi->wTagList.tags.begin(); it != hmi->wTagList.tags.end(); ++it) {
		logger.log(LM_INFO, "name: %s\tinternal:%d", (*it)->name.c_str(), (*it)->internal);
	}

	TagList::StatefulTagVector::iterator tag;
	for (Handler::BoundExpressionsPtrs::iterator it = handler.boundExpressionsPtrs.begin(); it != handler.boundExpressionsPtrs.end(); ++it) {
		if ((*it)->sensitivityList.tags.size() > 0) { // ak ma prazdny sensitivity list nikdy mu nemoze prist update, nema teda zmysel aby sa registroval
			for (tag = (*it)->inputList.tags.begin(); tag != (*it)->inputList.tags.end(); ++tag) {
				logger.log(LM_INFO, "UpdateListener: pridavam tag BE inputList: %s", (*tag)->name.c_str());
				(*it)->addTag(*tag);
			}
			for (tag = (*it)->sensitivityList.tags.begin(); tag != (*it)->sensitivityList.tags.end(); ++tag) {
				logger.log(LM_INFO, "UpdateListener: pridavam tag BE sensitivityList: %s", (*tag)->name.c_str());
				(*it)->addTag(*tag);
			}
			logger.log(LM_INFO, "Connector: Registering UpdateListener BE");
			con->registerUpdateListener(*it);
		}
	}

	for (Handler::ScriptPtrs::iterator it = handler.scriptPtrs.begin(); it != handler.scriptPtrs.end(); ++it) {
		if ((*it)->sensitivityList.tags.size() > 0) {
			for (tag = (*it)->inputList.tags.begin(); tag != (*it)->inputList.tags.end(); ++tag) {
				logger.log(LM_INFO, "UpdateListener: pridavam tag SC inputList: %s", (*tag)->name.c_str());
				(*it)->addTag(*tag);
			}
			for (tag = (*it)->sensitivityList.tags.begin(); tag != (*it)->sensitivityList.tags.end(); ++tag) {
				logger.log(LM_INFO, "UpdateListener: pridavam tag SC sensitivityList: %s", (*tag)->name.c_str());
				(*it)->addTag(*tag);
			}
			logger.log(LM_INFO, "Connector: Registering UpdateListener SC");
			con->registerUpdateListener(*it);
		}
	}

	for (Handler::PenPtrs::iterator it = handler.penPtrs.begin(); it != handler.penPtrs.end(); ++it) {
		(*it)->addTag((*it)->tag);
		logger.log(LM_INFO, "Connector: Registering UpdateListener Pen");
		con->registerUpdateListener(*it);
	}

	for (Handler::ValueLinkPtrs::iterator it = handler.valueLinkPtrs.begin(); it != handler.valueLinkPtrs.end(); ++it) {
		(*it)->addTag((*it)->tag);
		con->registerUpdateListener(*it);
	}

	con->configure(hmi->rTagList.tags, hmi->wTagList.tags, ACE_INET_Addr(hmi->configurations.suhubConfiguration.notifyPort, hmi->configurations.suhubConfiguration.host.c_str(), AF_INET), ACE_INET_Addr(hmi->configurations.suhubConfiguration.inputPort, hmi->configurations.suhubConfiguration.host.c_str(), AF_INET), hmi->configurations.suhubConfiguration.timeout);

	hmi->create(); //spusti onCreate scripty na vsetkych prvkoch
	setHmi(*hmi);
#ifdef TEST
	exit(0);
#endif
	showMaximized();
}

void SWindow::setHmi(Hmi &hmi) {
	scene->setHmi(hmi);
}

void SWindow::resizeEvent(QResizeEvent *event) {
}

Scene* SWindow::getScene() {
	return scene;
}

void SWindow::update() {
	if (con)
		con->stepReactor();
	else
		logger.log(LM_WARNING, "Connector not createted");
}
#ifdef GPROF_HEAP
void SWindow::heapDump() {
	qDebug() << "Heap dump";
	HeapProfilerDump("periodic");
}
#endif

#ifdef GPROF_CPU
void SWindow::cpuDump() {
	qDebug() << "CPU dump";
	ProfilerFlush();
}
#endif
