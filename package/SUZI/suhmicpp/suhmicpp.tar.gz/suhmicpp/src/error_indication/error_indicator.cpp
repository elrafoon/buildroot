/*
 * error_indicator.cpp
 *
 *  Created on: Sep 26, 2011
 *      Author: vlado
 */

#include "suhmicpp/error_indication/error_indicator.h"
