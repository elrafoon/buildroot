/*
 * error_button.cpp
 *
 *  Created on: Sep 26, 2011
 *      Author: vlado
 */

/**
 * Implementacia ErrorIndicator. Zobrazuje sa ako polopriehladna ikona v pravom dolnom rohu okna. Potvrdzuje sa lavym tlacidlom mysi.
 */

#define MAX_Z_VALUE 300 //maximalna hodnota z indexu v suxploreri
#define OPACITY 0.5
#include "suhmicpp/error_indication/error_button.h"

ErrorButton::ErrorButton() : ErrorIndicator(), pixmap(":/images/error.png"){
	QGraphicsPixmapItem::setPixmap(pixmap);
	setZValue(MAX_Z_VALUE + 1);
	setOpacity(OPACITY);
	setVisible(false);
	setAcceptedMouseButtons(Qt::LeftButton);
}

/**
 * Zobrazi tlacidlo, ak je priority vaznejsia ako ERROR.
 */
void ErrorButton::setActive(ACE_Log_Priority priority){
	if(priority >= LM_ERROR)
		setVisible(true);
}

/**
 * Umiestni tlacidlo do praveho dolneho rohu okna s velkostou winSize.
 */
void ErrorButton::move(QSize winSize){
	int width = pixmap.size().width();
	int height = pixmap.size().height();
	int x = winSize.width() - width;
	int y = winSize.height() - height;
	setPos(x, y);
	update();
}

/**
 * Potvrdenie lavym tlacidlom mysi.
 */
void ErrorButton::mousePressEvent(QGraphicsSceneMouseEvent * event){
	setVisible(false);
}
