/*
 * configurations.cpp
 *
 *  Created on: Aug 22, 2011
 *      Author: vlado
 */

#include "suhmicpp/configurations/configurations.h"

Configurations::Configurations(const QXmlAttributes &attributes){

}

void Configurations::setSuhubConfiguration(const QXmlAttributes &attributes){
	suhubConfiguration.setAttributes(attributes);
}

void Configurations::setArcherConfiguration(const QXmlAttributes &attributes){
	archerConfiguration.setAttributes(attributes);
}

void Configurations::setAlarmConfiguration(const QXmlAttributes &attributes){
	alarmConfiguration.setAttributes(attributes);
}
