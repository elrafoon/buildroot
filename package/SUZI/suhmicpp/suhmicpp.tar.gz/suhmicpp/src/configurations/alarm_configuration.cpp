/*
 * alarm_configuration.cpp
 *
 *  Created on: Sep 6, 2011
 *      Author: vlado
 */

#include "suhmicpp/configurations/alarm_configuration.h"


AlarmConfiguration::AlarmConfiguration() : host("localhost"), port(61007){

}

void AlarmConfiguration::setAttributes(const QXmlAttributes &attributes){
	host = attributes.value("host").toStdString();
	port  = attributes.value("port").toInt();
}

