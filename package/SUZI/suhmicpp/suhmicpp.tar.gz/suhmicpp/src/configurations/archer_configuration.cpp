/*
 * archer_configuration.cpp
 *
 *  Created on: Aug 22, 2011
 *      Author: vlado
 */

#include <QString>
#include <QXmlAttributes>
#include "suhmicpp/configurations/archer_configuration.h"


void ArcherConfiguration::setAttributes(const QXmlAttributes &attributes){
	host = attributes.value("host").toStdString();
	port = attributes.value("port").toInt();
	timeout = attributes.value("timeout").toInt();
	driverName = attributes.value("driverName").toStdString();;
}
