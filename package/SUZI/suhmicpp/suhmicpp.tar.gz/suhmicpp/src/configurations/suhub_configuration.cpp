/*
 * suhub_configuration.cpp
 *
 *  Created on: Aug 22, 2011
 *      Author: vlado
 */

#include "suhmicpp/configurations/suhub_configuration.h"


void SuhubConfiguration::setAttributes(const QXmlAttributes &attributes){
	host = attributes.value("host").toStdString();
	notifyPort  = attributes.value("notifyPort").toInt();;
	inputPort = attributes.value("inputPort").toInt();;
	timeout = attributes.value("timeout").toInt();
}
