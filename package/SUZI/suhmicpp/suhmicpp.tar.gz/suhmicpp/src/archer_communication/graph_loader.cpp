/*
 * graph_loader.cpp
 *
 *  Created on: Sep 7, 2011
 *      Author: matus
 */

#include "suhmicpp/archer_communication/graph_loader.h"

GraphLoader::GraphLoader(ArcherConnector const * const archerCon) {
	this->archerCon = archerCon;
	resultContainer.clear();
}

GraphLoader::~GraphLoader() {
	;
}

void GraphLoader::run(){
	QString queryString = QString("select t,v from archive(now - %1 seconds, now) where tagname='%2' order by t").arg(QString::number(seconds)).arg(tagName);
	archerCon->callQuery(queryString.toStdString(), resultContainer);
	emit sigDataAcquired(resultContainer);
}

/**
 * Starts run function, which will select data from archer and emit sigDataAcquired signal with result.
 */
void GraphLoader::getData(uint64_t seconds, QString tagName){
	this->seconds = seconds;
	this->tagName = tagName;
	if (this->archerCon == NULL) {
		//error
		qDebug() << "Error, ArcherConnector not alocated.";
	}
	this->start();
	QThread::moveToThread(this);
}
