/*
 * archer_connector.cpp
 *
 *  Created on: Sep 7, 2011
 *      Author: matus
 */

#include "SimpleDB.h"
#include "suhmicpp/archer_communication/archer_connector.h"

ArcherConnector::ArcherConnector(const ArcherConfiguration & archerConf) {

	driverName = archerConf.driverName;
	port = (archerConf.port);
	host = (archerConf.host);
	timeout = (archerConf.timeout);
}

bool ArcherConnector::callQuery(std::string preparedQueryString, std::map<double, double> & resultContainer) const {
	std::string timeoutStr;
	std::stringstream timeoutStream;
	timeoutStream << timeoutStr;
	timeoutStr = timeoutStream.str();
	std::string portStr;
	std::stringstream portStream;
	portStream << port;
	portStr = portStream.str();
	try {
		std::string dsn = "DRIVER={" + driverName + "};TCPIP{host=" + host + ";port=" + portStr + ";timeout=" + timeoutStr + "};Server=" + host + ";";
		SimpleDB::Database db(dsn, SimpleDB::Database::CONNECTION_METHOD_SQLDriverConnect);

		SimpleDB::DoubleColumn tColumn;
		SimpleDB::DoubleColumn vColumn;
		SimpleDB::Column * columns[2] = { &tColumn, &vColumn };
		SimpleDB::Query query(db);
		query.bind(columns, 2);
		query.execute(preparedQueryString);
		while (query.fetchRow()) {
			double t = tColumn.value();
			double v = vColumn.value();
			resultContainer.insert(std::pair<double, double>(t * 1000, v));
		}
	} catch (const SimpleDB::Exception& exception) {
		std::cerr << exception << std::endl;
		return false;
	} catch (const SimpleDB::Database::Exception& exception) {
		std::cerr << exception << std::endl;
		return false;
	} catch (SimpleDB::Column::UnboundException) {
		std::cerr << "A column was not bound!" << std::endl;
		return false;
	}
	return true;
}

ArcherConnector::~ArcherConnector() {
}
