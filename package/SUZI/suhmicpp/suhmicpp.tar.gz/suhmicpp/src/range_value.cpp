/*
 * range_value.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/range_value.h"


RangeValue::RangeValue(const QXmlAttributes &attributes){
	rangeLow = attributes.value("rangeLow").toFloat();
	rangeHigh = attributes.value("rangeHigh").toFloat();
	value = attributes.value("value");
	/*qDebug() << "RangeValue:rangeLow: " << rangeLow;
	qDebug() << "RangeValue:rangeHigh: " << rangeHigh;
	qDebug() << "RangeValue:rangeLow: " << value;
	*/
}
