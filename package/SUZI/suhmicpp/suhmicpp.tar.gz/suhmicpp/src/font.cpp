/*
 * font.cpp
 *
 *  Created on: Jan 18, 2011
 *      Author: vlado
 */

#include "suhmicpp/font.h"
#include "suhmicpp/symbols/base_label.h"

Font::Font() :
	size(12), align(LEFT), name(SERIF), style(PLAIN) {

}

int Font::getSize() const {
	return size;
}

Font::Align Font::getAlign() const {
	return align;
}

Font::Name Font::getName() const {
	return name;
}

Font::Style Font::getStyle() const {
	return style;
}

QFont const& Font::getQFont() {
	return font;
}

void Font::setSize(int size) {
	this->size = size;
	updateQFont();
}

void Font::setAlign(const std::string &align) {
	if (align == "left") {
		setAlign(LEFT);
	} else if (align == "center") {
		setAlign(CENTER);
	} else {
		setAlign(RIGHT);
	}
}

void Font::setAlign(Align align) {
	this->align = align;
	if (align == LEFT){
		flags |= Qt::AlignLeft;
		flags &= ~Qt::AlignHCenter;
		flags &= ~Qt::AlignRight;
	}
	else if (align == CENTER) {
		flags |= Qt::AlignHCenter;
		flags &= ~Qt::AlignLeft;
		flags &= ~Qt::AlignRight;
	} else {
		flags |= Qt::AlignRight;
		flags &= ~Qt::AlignHCenter;
		flags &= ~Qt::AlignLeft;
	}
}

/**
 * Podla constants.py.
 */
void Font::setAlign(int align) {
	if (align == 0)
		setAlign(LEFT);
	else if (align == 1)
		setAlign(CENTER);
	else
		setAlign(RIGHT);
}

void Font::setName(const std::string &name) {
	if (name == "Serif") {
		setName(Font::SERIF);
	} else if (name == "Monospaced") {
		setName(Font::MONOSPACED);
	} else {
		setName(Font::SANSSERIF);
	}
}

void Font::setName(const Name name) {
	this->name = name;
	updateQFont();
}

void Font::setName(int name) {
	this->name = static_cast<Name> (name);
	updateQFont();
}

void Font::setStyle(const std::string &style) {
	if (style == "bold") {
		setStyle(BOLD);
	} else if (style == "italic") {
		setStyle(ITALIC);
	} else {
		setStyle(PLAIN);
	}
}

void Font::setStyle(Style style) {
	this->style = style;
	updateQFont();
}

void Font::setStyle(int style) {
	this->style = static_cast<Style> (style);
	updateQFont();
}

/* Premietne nastavenia Font-u do QFont */
void Font::updateQFont() {
	font.setPixelSize(size);
	switch (style) {
	case Font::BOLD:
		font.setWeight(QFont::Bold);
		break;
	case Font::ITALIC:
		font.setStyle(QFont::StyleItalic);
		break;
	default:
		font.setStyle(QFont::StyleNormal);
		break;
	}

	switch (name) {
	case Font::SANSSERIF:
		font.setStyleHint(QFont::SansSerif);
		font.setFamily(QString("DejaVu Sans"));
		break;
	case Font::MONOSPACED:
		font.setStyleHint(QFont::TypeWriter);
		font.setFamily(QString("DejaVu Sans Mono"));
		break;
	default:
		font.setStyleHint(QFont::Serif);
		font.setFamily(QString("DejaVu Serif"));
		break;
	}
}
