/*
 * suzi_xml_handler.cpp
 *
 *  Created on: Jul 6, 2010
 *      Author: vlado
 */

/**
 * [volanie]
 *	<tns:replacement> [start()] [characters()]
 *		<tns:key>[start()] ?LEVEL [characters()]</tns:key> [end()] [characters()]
 *		<tns:value>[start()] LEVEL_3 [characters()]</tns:value>[end()] [characters()]
 *	</tns:replacement> [end()]
 *
 *	<tns:replacement> [start()] [characters()]
 *		<tns:key>[start()] ?TICK [characters()]</tns:key> [end()] [characters()]
 *		<tns:value/> [start()] [end()] - bez [characters()]
 *	</tns:replacement>
 */

#include <QtDebug>
#include <QXmlAttributes>
#include <QObject>
#include <vector>
#include <utility>
#include <string>
#include <set>
#include "suhmicpp/xml/xml_reader.h"
#include "suhmicpp/hmi.h"
#include "suhmicpp/symbols/rect.h"
#include "suhmicpp/symbols/ellipse.h"
#include "suhmicpp/symbols/line.h"
#include "suhmicpp/symbols/arc.h"
#include "suhmicpp/symbols/label.h"
#include "suhmicpp/symbols/static_label.h"
#include "suhmicpp/symbols/value_display.h"
#include "suhmicpp/symbols/polygon.h"
#include "suhmicpp/symbols/polyline.h"
#include "suhmicpp/symbols/image.h"
#include "suhmicpp/symbols/timer.h"
#include "suhmicpp/window/window_list.h"
#include "suhmicpp/window/window.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/events/oncreate.h"
#include "suhmicpp/events/ondestroy.h"
#include "suhmicpp/events/onshow.h"
#include "suhmicpp/events/onclick.h"
#include "suhmicpp/events/onhide.h"
#include "suhmicpp/lists/tag_list.h"
#include "suhmicpp/lists/generic_script_list.h"
#include "suhmicpp/script.h"
#include "suhmicpp/symbols/compound_symbol.h"
#include "suhmicpp/symbols/compound_symbol_template.h"
#include "suhmicpp/lists/compound_symbol_list.h"

#define VOID_TAG_NAME	"___void___"
#define MAX_ZVALUE 300

Handler::Handler() :
	QXmlDefaultHandler(),PrefixedLogger("XML: "), currentWindowList(NULL), currentWindow(NULL), currentSymbol(NULL), currentEvent(NULL), currentTagList(NULL), currentGenericScriptList(NULL), currentGenericScript(NULL),
			currentScript(NULL), currentCompoundSymbolTemplate(NULL), currentCompoundSymbol(NULL), currentCompoundSymbolList(NULL), currentSymbolList(NULL), currentPair(NULL),
			currentReplacementTable(NULL), currentLink(NULL), currentLinkList(NULL), currentBoundExpression(NULL), currentBgBlinkLink(NULL), currentFgBlinkLink(NULL), currentBgColorLink(NULL),
			currentFgColorLink(NULL), currentHorizontalFillLink(NULL), currentVerticalFillLink(NULL), currentHorizontalPositionLink(NULL), currentVerticalPositionLink(NULL),
			currentHorizontalSizeLink(NULL), currentVerticalSizeLink(NULL), currentRotationLink(NULL), currentVisibilityLink(NULL), currentHandlerCode(NULL), currentRangeValueList(NULL),
			currentOnlineGraph(NULL), currentOnlineGraphPen(NULL), currentPythonModule(NULL), currentAlarmWindow(NULL), currentTimer(NULL) {
}

Handler::~Handler() {
}

bool Handler::startElement(const QString &namespaceURI, const QString &localName, const QString &qName, const QXmlAttributes &attributes) {
	if (localName == "hmi") {
		log(LM_DEBUG, "<hmi");
		hmi.setAttributes(attributes);
	} else if (localName == "configurations") {
		log(LM_DEBUG, "<configurations");
		hmi.setConfigurations(attributes);
		currentConfigurations = &hmi.configurations;
	} else if (localName == "suhubConfiguration") {
		log(LM_DEBUG, "<suhubConfiguration");
		if (currentConfigurations) {
			currentConfigurations->setSuhubConfiguration(attributes);
		} else {
			log(LM_ERROR, "suhubConfiguration outside configurations");
		}
	} else if (localName == "archerConfiguration") {
		log(LM_DEBUG, "<archerConfiguration");
		if (currentConfigurations) {
			currentConfigurations->setArcherConfiguration(attributes);
		} else {
			log(LM_ERROR, "archerConfiguration outside configurations");
		}
	} else if (localName == "alarmConfiguration") {
		log(LM_DEBUG, "<alarmConfiguration");
		if (currentConfigurations) {
			currentConfigurations->setAlarmConfiguration(attributes);
		} else {
			log(LM_ERROR, "alarmConfiguration outside configurations");
		}

	} else if (localName == "compoundSymbolList") {
		log(LM_DEBUG, "<compoundSymbolList");
		currentCompoundSymbolList = &(hmi.compoundSymbolList);
	} else if (localName == "windowList") {
		log(LM_DEBUG, "<windowList");
		currentWindowList = &(hmi.windowList);
		currentWindowList->setAttributes(attributes);
	} else if (localName == "window") {
		log(LM_DEBUG, "<Window");
		Window *w = new Window(attributes);
		hmi.windowList.windows.push_back(w);
		currentWindow = w;
	} else if (localName == "symbolList") {
		log(LM_DEBUG, "<symbolList");
		if (currentWindow) {
			currentSymbolList = &(currentWindow->symbolList);
		} else {
			log(LM_ERROR, "symbolList outside currentWindow");
		}
	} else if (localName == "compoundSymbolTemplate") {
		log(LM_DEBUG, "<compoundSymbolTemplate");
		if (currentCompoundSymbolList) {
			CompoundSymbolTemplate *compoundSymbolTemplate = new CompoundSymbolTemplate(attributes);
			currentCompoundSymbolList->compoundSymbol.push_back(compoundSymbolTemplate);
			//currentCompoundSymbolTemplate = compoundSymbolTemplate;
			currentCompoundSymbolTemplate = currentCompoundSymbolList->compoundSymbol.back();
		} else {
			log(LM_ERROR, "compoundSymbolTemplate outside currentCompoundSymbolList");
		}
	} else if (localName == "visualSymbol") {
		log(LM_DEBUG, "<visualSymbol");
		log(LM_DEBUG, "currentCompoundSymbolTemplate: %s", currentCompoundSymbolTemplate->className.toStdString().c_str());
		if (currentCompoundSymbolTemplate) {
			if (attributes.value(QString("xsi:type")) == "tns:Rectangle") {
				createVisualSymbol<Rect> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Ellipse") {
				createVisualSymbol<Ellipse> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Line") {
				createVisualSymbol<Line> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Arc") {
				createVisualSymbol<Arc> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Label") {
				createVisualSymbol<Label> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:StaticLabel") {
				createVisualSymbol<StaticLabel> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:ValueDisplay") {
				ValueDisplay* vd = createVisualSymbol<ValueDisplay> (attributes);
				SuhubConnectorLight::StatefulTag *tag = hmi.tagList.uniquePush(attributes.value("tagName").toStdString());
				hmi.rTagList.uniquePush(tag);
				vd->setTag(tag);
			} else if (attributes.value(QString("xsi:type")) == "tns:Polygon") {
				createVisualSymbol<Polygon> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Image") {
				createVisualSymbol<Image> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Polyline") {
				createVisualSymbol<Polyline> (attributes);
			} else if (attributes.value(QString("xsi:type")) == "tns:Timer") {
				createVisualSymbol<Timer> (attributes);
			} else {
				log(LM_ERROR, "visualSymbol with unknown type");
			}
		} else {
			log(LM_ERROR, "visualSymbol outside currentCompoundSymbolTemplate");
		}
	} else if (localName == "symbol") {
		log(LM_DEBUG, "<symbol");
		if (currentWindow) {
			if (attributes.value(QString("xsi:type")) == "tns:Rectangle") {
				Rect *rect = new Rect(attributes);
				rect->setParentItem(currentWindow);
				log(LM_DEBUG, "<Rectangle");
				currentWindow->symbolList.symbol.push_back(rect);
				currentSymbol = rect;
			} else if (attributes.value(QString("xsi:type")) == "tns:Ellipse") {
				log(LM_DEBUG, "<Ellipse");
				Ellipse *ellipse = new Ellipse(attributes);
				ellipse->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(ellipse);
				currentSymbol = ellipse;
			} else if (attributes.value(QString("xsi:type")) == "tns:Line") {
				log(LM_DEBUG, "<Line");
				Line *line = new Line(attributes);
				line->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(line);
				currentSymbol = line;
			} else if (attributes.value(QString("xsi:type")) == "tns:Arc") {
				log(LM_DEBUG, "<Arc");
				Arc *arc = new Arc(attributes);
				arc->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(arc);
				currentSymbol = arc;
			} else if (attributes.value(QString("xsi:type")) == "tns:Label") {
				log(LM_DEBUG, "<Label");
				Label *label = new Label(attributes);
				label->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(label);
				currentSymbol = label;
			} else if (attributes.value(QString("xsi:type")) == "tns:StaticLabel") {
				log(LM_DEBUG, "<StaticLabel");
				StaticLabel *staticLabel = new StaticLabel(attributes);
				staticLabel->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(staticLabel);
				currentSymbol = staticLabel;
			} else if (attributes.value(QString("xsi:type")) == "tns:ValueDisplay") {
				log(LM_DEBUG, "<ValueDisplay");
				SuhubConnectorLight::StatefulTag *tag = hmi.tagList.uniquePush(attributes.value("tagName").toStdString());
				hmi.rTagList.uniquePush(tag);
				ValueDisplay *valueDisplay = new ValueDisplay(attributes);
				valueDisplay->setTag(tag);
				valueDisplay->setParentItem(currentWindow);
				log(LM_DEBUG, "boundExpressionsPtrs vkladam valueLink");
				valueLinkPtrs.push_back(&(valueDisplay->valueLink));
				currentWindow->symbolList.symbol.push_back(valueDisplay);
				currentSymbol = valueDisplay;
			} else if (attributes.value(QString("xsi:type")) == "tns:Polygon") {
				log(LM_DEBUG, "<Polygon");
				Polygon *polygon = new Polygon(attributes);
				polygon->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(polygon);
				currentSymbol = polygon;
			} else if (attributes.value(QString("xsi:type")) == "tns:Polyline") {
				log(LM_DEBUG, "<Polyline");
				Polyline *polyline = new Polyline(attributes);
				polyline->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(polyline);
				currentSymbol = polyline;
			} else if (attributes.value(QString("xsi:type")) == "tns:Image") {
				log(LM_DEBUG, "<Image");
				Image *image = new Image(attributes);
				image->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(image);
				currentSymbol = image;
			} else if (attributes.value(QString("xsi:type")) == "tns:OnlineGraph") {
				log(LM_DEBUG, "<OnlineGraph");
				OnlineGraph *onlineGraph = new OnlineGraph(attributes, hmi.configurations.archerConfiguration);
				onlineGraph->setParentItem(currentWindow);
				currentWindow->symbolList.symbol.push_back(onlineGraph);
				currentOnlineGraph = onlineGraph;
				currentSymbol = onlineGraph;
			} else if (attributes.value(QString("xsi:type")) == "tns:AlarmWindow") {
				log(LM_DEBUG, "<AlarmWindow");
				AlarmWindow *alarmWindow = new AlarmWindow(attributes, hmi.configurations.alarmConfiguration.port, hmi.configurations.alarmConfiguration.host);
				currentWindow->alarmWindows.push_back(alarmWindow);
				currentSymbol = alarmWindow;
				currentAlarmWindow = alarmWindow;
			} else if (attributes.value(QString("xsi:type")) == "tns:Timer") {
				log(LM_DEBUG, "<Timer");
				Timer *timer = new Timer(attributes);
				currentTimer = timer;
				currentWindow->symbolList.symbol.push_back(timer);
				currentSymbol = timer;
			} else if (attributes.value(QString("xsi:type")) == "tns:CompoundSymbol") {
				log(LM_DEBUG, "<CompoundSymbol");
				std::vector<CompoundSymbolTemplate *>::iterator ti;
				for (ti = hmi.compoundSymbolList.compoundSymbol.begin(); ti < hmi.compoundSymbolList.compoundSymbol.end(); ti++) {
					log(LM_DEBUG, "template ClassName: %s", (*ti)->className.toStdString().c_str());
					log(LM_DEBUG, "compound ClassName: %s", attributes.value(QString("className")).toStdString().c_str());
					if (((*ti)->className != "") && ((*ti)->className == attributes.value(QString("className")))) {
						log(LM_DEBUG, "Mam template: %s", attributes.value(QString("className")).toStdString().c_str());

						CompoundSymbol *compoundSymbol = new CompoundSymbol(attributes, (*ti), boundExpressionsPtrs, scriptPtrs, valueLinkPtrs, hmi.blinkLinks);
						compoundSymbol->setParentItem(currentWindow);
						currentSymbol = compoundSymbol;
						currentWindow->symbolList.symbol.push_back(compoundSymbol);
					}
				}

			} else {
				log(LM_ERROR, "Symbol with unknown type");
			}
		}
	} else if (localName == "replacementTable") {
		log(LM_DEBUG, "<replacementTable");
		currentReplacementTable = new ReplacementTable;
	} else if (localName == "replacement") {
		log(LM_DEBUG, "<replacement");
		currentPair = new ReplacementTablePair;
	} else if (localName == "key") {
		isKey = true;
	} else if (localName == "value") {
		isKey = false;
	}

	/************************
	 *
	 * EVENTY
	 *
	 ************************/
	else if (localName == "onCreate") {
		log(LM_DEBUG, "<onCreate");
		if (currentSymbol) {
			currentEvent = &(currentSymbol->oncreate);
		} else if (currentWindow) {
			currentEvent = &(currentWindow->oncreate);
		} else {
			currentEvent = &(hmi.oncreate); // patri to hmi
		}
	} else if (localName == "onDestroy") {
		log(LM_DEBUG, "<onDestroy");
		if (currentSymbol) {
			currentEvent = &(currentSymbol->ondestroy);
		} else if (currentWindow) {
			currentEvent = &(currentWindow->ondestroy);
		} else {
			currentEvent = &(hmi.ondestroy); // patri to hmi
		}
	} else if (localName == "onShow") {
		log(LM_DEBUG, "<onShow");
		if (currentSymbol && (currentSymbol->obType & VISUAL_SYMBOL)) {
			currentEvent = &(static_cast<VisualSymbol*> (currentSymbol)->onshow);
		}
		else if (currentSymbol && (currentSymbol->obType & ALARM_WINDOW)) {
			currentEvent = &(static_cast<AlarmWindow*> (currentSymbol)->onshow);
		} else if (currentWindow) {
			currentEvent = &(currentWindow->onshow);
		} else {
			log(LM_ERROR, "onShow outside currentSymbol and currentWindow");
		}
	}

	else if (localName == "onHide") {
		log(LM_DEBUG, "<onHide");
		if (currentSymbol && (currentSymbol->obType & VISUAL_SYMBOL)) {
			currentEvent = &(static_cast<VisualSymbol*> (currentSymbol)->onhide);
		} else if (currentSymbol && (currentSymbol->obType & ALARM_WINDOW)) {
			currentEvent = &(static_cast<AlarmWindow*> (currentSymbol)->onhide);
		} else if (currentWindow) {
			currentEvent = &(currentWindow->onhide);
		} else {
			log(LM_ERROR, "onHide outside currentSymbol and currentWindow");
		}
	}

	else if (localName == "onClick") {
		log(LM_DEBUG, "<onClick");
		if (currentSymbol && (currentSymbol->obType & VISUAL_SYMBOL)) {
			currentEvent = &(static_cast<VisualSymbol*> (currentSymbol)->onclick);
		} else {
			log(LM_ERROR, "onClick outside currentSymbol or currentSymbol is not VisualSymbol.");
		}
	}

	else if (localName == "onChange") {
		log(LM_DEBUG, "<onChange");
		if (currentSymbol && (currentSymbol->obType & LABEL)) {
			currentEvent = &(static_cast<Label *> (currentSymbol)->onchange);
		} else {
			log(LM_ERROR, "onChange outside currentSymbol or currentSymbol is not Label.");
		}
	}

	else if (localName == "onTick") {
		log(LM_DEBUG, "<onTick");
		if (currentSymbol && (currentSymbol->obType & TIMER)) {
			currentEvent = &(static_cast<Timer *> (currentSymbol)->onTick);
		} else {
			log(LM_ERROR, "onTick outside currentSymbol or currentSymbol is not Timer.");
		}
	}

	else if (localName == "handlerCode") {
		log(LM_DEBUG, "<handlerCode");
		if (currentEvent) {
			currentHandlerCode = &(currentEvent->handlerCode);
		} else {
			log(LM_ERROR, "handlerCode outside currentEvent.");
		}
	}

	/*********************
	 *
	 * LINKY
	 *
	 *********************/
	else if (localName == "linkList") {
		log(LM_DEBUG, "<linkList");
		if (currentSymbol && (currentSymbol->obType & VISUAL_SYMBOL)) {
			currentLinkList = &(static_cast<VisualSymbol*> (currentSymbol)->linkList);
		} else {
			log(LM_ERROR, "linkList outside currentSymbol or currentSymbol is not VisualSymbol");
		}
	}

	else if (localName == "boundExpression") {
		log(LM_DEBUG, "<boundExpression");

		if (currentLink) {
			currentBoundExpression = &(currentLink->boundExpression);
			if (currentCompoundSymbolTemplate == NULL) {
				log(LM_ERROR, "boundExpressionsPtrs vkladam currentBoundExpression");
				boundExpressionsPtrs.push_back(currentBoundExpression);
			}
		} else if (currentSymbol) {
			currentBoundExpression = &(static_cast<Label *> (currentSymbol)->boundExpression);
			if (currentCompoundSymbolTemplate == NULL) {
				log(LM_ERROR, "boundExpressionsPtrs vkladam currentBoundExpression");
				boundExpressionsPtrs.push_back(currentBoundExpression);
			}
		} else {
			log(LM_ERROR, "boundExpression oustide currentLink and currentSymbol");
		}
	}

	else if (localName == "expression") {
		log(LM_DEBUG, "<expression");
		if (currentBoundExpression) {
			currentHandlerCode = &(currentBoundExpression->expression);
		} else {
			log(LM_ERROR, "expression outside currentBoundExpression");
		}
	}

	else if (localName == "bgBlinkLink") {
		log(LM_DEBUG, "<bgBlinkLink");
		if (currentLinkList) {
			currentBgBlinkLink = &(currentLinkList->bgBlinkLink);
			currentBgBlinkLink->setAttributes(attributes);
			currentLink = currentBgBlinkLink;
			std::pair<std::set<BlinkLink *>::iterator, bool> res = hmi.blinkLinks.insert(currentBgBlinkLink);
			if (!res.second) {
				log(LM_ERROR, "bgBlinkLink sa nepodarilo vlozit do hmi.blinkLinks");
			}
		} else {
			log(LM_ERROR, "bgBlinkLink outside currentLinkList");
		}
	}

	else if (localName == "fgBlinkLink") {

		log(LM_DEBUG, "<fgBlinkLink");
		if (currentLinkList) {
			currentFgBlinkLink = &(currentLinkList->fgBlinkLink);
			currentFgBlinkLink->setAttributes(attributes);
			currentLink = currentFgBlinkLink;
			std::pair<std::set<BlinkLink *>::iterator, bool> res = hmi.blinkLinks.insert(currentFgBlinkLink);
			if (!res.second) {
				log(LM_ERROR, "bgBlinkLink sa nepodarilo vlozit do hmi.blinkLinks");
			}

		} else {
			log(LM_ERROR, "fgBlinkLink outside currentLinkList");
		}
	}

	else if (localName == "bgColorLink") {
		log(LM_DEBUG, "<bgColorLink");
		if (currentLinkList) {
			currentBgColorLink = &(currentLinkList->bgColorLink);
			currentLink = currentBgColorLink;
		} else {
			log(LM_ERROR, "bgColorLink outside currentLinkList");
		}
	}

	else if (localName == "fgColorLink") {
		log(LM_DEBUG, "<fgColorLink");
		if (currentLinkList) {
			currentFgColorLink = &(currentLinkList->fgColorLink);
			currentLink = currentFgColorLink;
		} else {
			log(LM_ERROR, "fgColorLink outside currentLinkList");
		}
	}

	else if (localName == "horizontalFillLink") {
		log(LM_DEBUG, "<horizontalFillLink");
		if (currentLinkList) {
			currentHorizontalFillLink = &(currentLinkList->horizontalFillLink);
			currentLink = currentHorizontalFillLink;
		} else {
			log(LM_ERROR, "horizontalFillLink outside horizontalFillLink");
		}
	}

	else if (localName == "verticalFillLink") {
		log(LM_DEBUG, "<verticalFillLink");
		if (currentLinkList) {
			currentVerticalFillLink = &(currentLinkList->verticalFillLink);
			currentLink = currentVerticalFillLink;
		} else {
			log(LM_ERROR, "verticalFillLink outside currentLinkList");
		}
	}

	else if (localName == "horizontalPositionLink") {
		log(LM_DEBUG, "<horizontalPositionLink");
		if (currentLinkList) {
			currentHorizontalPositionLink = &(currentLinkList->horizontalPositionLink);
			currentLink = currentHorizontalPositionLink;
		} else {
			log(LM_ERROR, "currentLinkList outside currentLinkList");
		}
	}

	else if (localName == "verticalPositionLink") {
		log(LM_DEBUG, "<verticalPositionLink");
		if (currentLinkList) {
			currentVerticalPositionLink = &(currentLinkList->verticalPositionLink);
			currentLink = currentVerticalPositionLink;
		} else {
			log(LM_ERROR, "verticalPositionLink outside currentLinkList");
		}
	}

	else if (localName == "horizontalSizeLink") {
		log(LM_DEBUG, "<horizontalSizeLink");
		if (currentLinkList) {
			currentHorizontalSizeLink = &(currentLinkList->horizontalSizeLink);
			currentLink = currentHorizontalSizeLink;
		} else {
			log(LM_ERROR, "horizontalSizeLink outside currentLinkList");
		}
	}

	else if (localName == "verticalSizeLink") {
		log(LM_DEBUG, "<verticalSizeLink");
		if (currentLinkList) {
			currentVerticalSizeLink = &(currentLinkList->verticalSizeLink);
			currentLink = currentVerticalSizeLink;
		} else {
			log(LM_ERROR, "verticalSizeLink outside currentLinkList");
		}
	}

	else if (localName == "rotationLink") {
		log(LM_DEBUG, "<rotationLink");
		if (currentLinkList) {
			currentRotationLink = &(currentLinkList->rotationLink);
			currentLink = currentRotationLink;
		} else {
			log(LM_ERROR, "currentLinkList outside currentLinkList");
		}
	}

	else if (localName == "visibilityLink") {
		log(LM_DEBUG, "<visibilityLink");
		if (currentLinkList) {
			currentVisibilityLink = &(currentLinkList->visibilityLink);
			currentLink = currentVisibilityLink;
		} else {
			log(LM_ERROR, "visibilityLink outside currentLinkList");
		}
	}

	else if (localName == "colorTable") {
		log(LM_DEBUG, "<colorTable");
		if (currentBgColorLink) {
			currentRangeValueList = &(currentBgColorLink->colorTable);
		} else if (currentFgColorLink) {
			currentRangeValueList = &(currentFgColorLink->colorTable);
		} else {
			log(LM_ERROR, "colorTable outside currentBgColorLink and currentFgColorLink");
		}
	} else if (localName == "rangeValueItem") {
		log(LM_DEBUG, "<rangeValueItem");
		if (currentRangeValueList) {
			RangeValue *rvi = new RangeValue(attributes);
			currentRangeValueList->rangeValueItem.push_back(rvi);
		} else {
			log(LM_ERROR, "rangeValueItem outside currentRangeValueList");
		}
	} else if (localName == "inputList") {
		log(LM_DEBUG, "<inputList");
		tagListType = in;
		if (currentEvent) {
			assert(currentBoundExpression == NULL);
			assert(currentScript == NULL);
			currentTagList = &(currentEvent->inputList);
		} else if (currentBoundExpression) {
			assert(currentEvent == NULL);
			assert(currentScript == NULL);
			currentTagList = &(currentBoundExpression->inputList);
		} else if (currentScript) {
			assert(currentEvent == NULL);
			assert(currentBoundExpression == NULL);
			currentTagList = &(currentScript->inputList);
		} else {
			log(LM_ERROR, "inputList outside Event, BoundExpression and Script");
		}

	} else if (localName == "sensitivityList") {
		log(LM_DEBUG, "<sensitivityList");
		tagListType = in;
		if (currentScript) {
			currentTagList = &(currentScript->sensitivityList);
		} else if (currentBoundExpression) {
			currentTagList = &(currentBoundExpression->sensitivityList);
		} else {
			log(LM_ERROR, "sensitivityList outside Script and BoundExpression");
		}
	}

	else if (localName == "outputList") {
		log(LM_DEBUG, "<outputList");
		tagListType = out;
		if (currentEvent) {
			currentTagList = &(currentEvent->outputList);
		} else if (currentScript) {
			currentTagList = &(currentScript->outputList);
		} else {
			log(LM_ERROR, "outputList outside Event and Script");
		}

	} else if (localName == "tagName") {
		log(LM_DEBUG, "<tagName");
	} else if (localName == "position") {
		if (currentSymbol) {
			log(LM_DEBUG, "<position type: %d", currentSymbol->obType);
			if (currentSymbol->obType & VISUAL_SYMBOL) {
				VisualSymbol *vs = static_cast<VisualSymbol*> (currentSymbol);
				vs->setPosition(attributes);
			} else if (currentSymbol->obType & ALARM_WINDOW) {
				AlarmWindow *aw = static_cast<AlarmWindow*> (currentAlarmWindow);
				aw->setPosition(attributes);
			} else {
				log(LM_ERROR, "tagName outside Symbol or Symbol is not VisualSymbol.");
			}
		} else {
			log(LM_ERROR, "tagName outside Symbol");
		}
	} else if (localName == "size") {
		if (currentSymbol) {
			if (currentSymbol->obType & VISUAL_SYMBOL) {
				static_cast<VisualSymbol*> (currentSymbol)->setSize(attributes);
			} else if (currentSymbol->obType & ALARM_WINDOW) {
				static_cast<AlarmWindow*> (currentAlarmWindow)->setSize(attributes);
			} else {
				log(LM_ERROR, "size outside Symbol or Symbol is not VisualSymbol.");
			}
		} else if (currentWindow) {
			currentWindow->setSize(attributes);
		} else {
			log(LM_ERROR, "size outside Symbol.");
		}
	} else if (localName == "vertexes") {
		if (currentSymbol) {
			if (currentSymbol->obType & POLYGON) {
				static_cast<Polygon *> (currentSymbol)->addVertex(attributes);
			} else if (currentSymbol->obType & POLYLINE) {
				static_cast<Polyline *> (currentSymbol)->addVertex(attributes);
			} else if (currentSymbol->obType & LINE) {
				static_cast<Line *> (currentSymbol)->addVertex(attributes);
			} else {
				log(LM_ERROR, "vertexes: symbol is not Polygon, Polyline, Line");
			}
		} else {
			log(LM_ERROR, "vertexes outside currentSymbol");
		}

	} else if (localName == "genericScriptList") {
		log(LM_DEBUG, "<genericScriptList");
		if (currentSymbol) {
			if (currentSymbol->obType & SYMBOL) {
				currentGenericScriptList = &(currentSymbol->genericScriptList);
			} else {
				log(LM_ERROR, "genericScriptList outside Symbol or Symbol is not VisualSymbol");
			}
		} else {
			currentGenericScriptList = &(hmi.genericScriptList);
		}
	} else if (localName == "genericScript") {
		log(LM_DEBUG, "<genericScript");
		if (currentGenericScriptList) {
			log(LM_DEBUG, "Vytvaram novy genericScript");
			GenericScript *genericScript = new GenericScript(currentGenericScriptList->ob, attributes);
			currentGenericScriptList->genericScript.push_back(genericScript);
			//currentGenericScript = genericScript;
			currentGenericScript = currentGenericScriptList->genericScript.back();
		} else {
			log(LM_ERROR, "genericScript outside GenericScriptList");
		}
	} else if (localName == "script") {
		log(LM_DEBUG, "<script");
		if (currentGenericScript) {
			currentScript = &(currentGenericScript->script);
			if (currentCompoundSymbolTemplate == NULL) {
				scriptPtrs.push_back(currentScript);
			}
		} else {
			log(LM_ERROR, "script outside GenericScript");
		}

	} else if (localName == "code") {
		log(LM_DEBUG, "<code");
		if (currentScript) {
			currentHandlerCode = &(currentScript->code);
		} else {
			log(LM_ERROR, "code outside Script");
		}

	} else if (localName == "font") {
		log(LM_DEBUG, "<font");
		if (currentSymbol) {
			static_cast<Label *> (currentSymbol)->setFontAttributes(attributes);
		} else {
			log(LM_ERROR, "font outside Symbol");
		}
	} else if (localName == "scale") {
		// Zatial sa scale vyskytuje iba pri symbol, takze to nijako nekontrolujem
		log(LM_DEBUG, "<scale");
		if (currentSymbol && (currentSymbol->obType & VISUAL_SYMBOL)) {
			static_cast<VisualSymbol *> (currentSymbol)->setScale(attributes);
		}
	} else if (localName == "rotCenter") {
		log(LM_DEBUG, "<rotCenter");
		if (currentSymbol && (currentSymbol->obType & VISUAL_SYMBOL)) {
			static_cast<VisualSymbol *> (currentSymbol)->setRotCenter(attributes);
		}
	} else if (localName == "data") {
		log(LM_DEBUG, "<data");
	} else if (localName == "timeAxis") {
		log(LM_DEBUG, "<timeAxis");
		currentOnlineGraph->timeAxis.setValues(attributes);
	} else if (localName == "valueAxis") {
		log(LM_DEBUG, "<valueAxis");
		currentOnlineGraph->valueAxis.setValues(attributes);
	} else if (localName == "manualRange") {
		log(LM_DEBUG, "<manualRange");
		if (currentOnlineGraphPen) {
			currentOnlineGraphPen->rangeType = OnlineGraphPen::manual;
			currentOnlineGraphPen->range = new OnlineGraphPenRangeManual(attributes);
		} else {
			log(LM_ERROR, "ManualRange outside OnlineGraphPen");
		}
	} else if (localName == "autoRange") {
		log(LM_DEBUG, "<autoRange");
		if (currentOnlineGraphPen) {
			currentOnlineGraphPen->rangeType = OnlineGraphPen::automatic;
			currentOnlineGraphPen->range = new OnlineGraphPenRangeAuto(attributes);
		} else {
			log(LM_ERROR, "ManualRange outside OnlineGraphPen");
		}
	} else if (localName == "tightRange") {
		log(LM_DEBUG, "<tightRange");
		if (currentOnlineGraphPen) {
			currentOnlineGraphPen->rangeType = OnlineGraphPen::tight;
			currentOnlineGraphPen->range = new OnlineGraphPenRangeTight(attributes);
		} else {
			log(LM_ERROR, "ManualRange outside OnlineGraphPen");
		}
	} else if (localName == "titleFont") {
		log(LM_DEBUG, "<titleFont");
		if (currentOnlineGraph) {
			currentOnlineGraph->setFontAttributes(attributes);
		} else {
			log(LM_ERROR, "TitleFont outside OnlineGraph");
		}
	} else if (localName == "labelFont") {
		log(LM_DEBUG, "<labelFont");
		if (currentOnlineGraph) {
			currentOnlineGraph->setLabelFontAttributes(attributes);
		} else {
			log(LM_ERROR, "LabelFont outside OnlineGraph");
		}
	} else if (localName == "pen") {
		log(LM_DEBUG, "<pen");
		if (currentOnlineGraph) {
			SuhubConnectorLight::StatefulTag *tag = hmi.tagList.uniquePush(attributes.value("tagName").toStdString());
			OnlineGraphPen *pen = new OnlineGraphPen(attributes, tag, currentOnlineGraph->timeAxis.getTStart(), hmi.configurations.archerConfiguration);
			currentOnlineGraphPen = pen;
			penPtrs.push_back(pen);
			hmi.rTagList.uniquePush(tag);
			currentOnlineGraph->pens.push_back(pen);
		} else {
			log(LM_ERROR, "OnlineGraphPen outside OnlineGraph");
		}
	} else if (localName == "source") {
		log(LM_DEBUG, "<source");
		if (currentAlarmWindow) {
			//TODO(vlado)
		}

		// Alarm Window Source
	} else if (localName == "system") {
		log(LM_DEBUG, "<system");
		if (currentAlarmWindow) {
			currentAlarmWindow->source = new AWSSystem();
		}
	} else if (localName == "group") {
		log(LM_DEBUG, "<group");
		if (currentAlarmWindow) {
			currentAlarmWindow->source = new AWSGroup(attributes);
		}
	} else if (localName == "alarm") {
		log(LM_DEBUG, "<alarm");
		if (currentAlarmWindow) {
			currentAlarmWindow->source = new AWSAlarm(attributes);
		}
	}
	//
	else if (localName == "columnSet") {
		log(LM_DEBUG, "<columnSet");
		if (currentAlarmWindow) {

		}
		else{
			log(LM_WARNING, "columnSet outside currentAlarmWindow");
		}
	}else if(localName == "alarmColumn"){
		currentAlarmWindow->addColumn(attributes);
	}
	else if (localName == "buttonSet") {
		log(LM_DEBUG, "<buttonSet");
		if (currentAlarmWindow) {
			currentAlarmWindow->setButtonSet(attributes);
		}
	} else if (localName == "filter") {
		log(LM_DEBUG, "<filter");
		if (currentAlarmWindow) {
			currentAlarmWindow->setFilter(attributes);
		}
	} else if (localName == "pythonModules") {
		log(LM_DEBUG, "<pythonModules");
		currentPythonModule = new PythonModule(attributes);
	} else {
		log(LM_ERROR, "Unknown starting element %s ", localName.toStdString().c_str());
	}

	return true;
}

bool Handler::endElement(const QString &namespaceURI, const QString &localName, const QString &qName) {
	if (localName == "windowList") {
		log(LM_DEBUG, "</windowList");
		assert(currentWindowList != NULL);
		currentWindowList->fini();
		currentWindowList = NULL;
		//skoncil window list, mozem zahodit templaty
		for (CompoundSymbolList::CompoundSymbolTemplateVector::iterator temp = hmi.compoundSymbolList.compoundSymbol.begin(); temp != hmi.compoundSymbolList.compoundSymbol.end(); ++temp) {
			for (CompoundSymbolTemplate::SymbolVector::iterator symbolIt = (*temp)->symbol.begin(); symbolIt != (*temp)->symbol.end(); ++symbolIt) {
				if ((*symbolIt)->obType & VISUAL_SYMBOL) {
					VisualSymbol *vs = static_cast<VisualSymbol *> (*symbolIt);
					hmi.blinkLinks.erase(&vs->linkList.bgBlinkLink);
					hmi.blinkLinks.erase(&vs->linkList.fgBlinkLink);
				}
			}
		}

		hmi.compoundSymbolList.deleteTemplates();
	} else if (localName == "window") {
		log(LM_DEBUG, "</window");
		assert(currentWindow != NULL);
		currentWindow->fini();
		currentWindow = NULL;
	} else if (localName == "symbol") {
		log(LM_DEBUG, "</symbol");
		assert(currentSymbol != NULL);
		currentSymbol->fini();
		currentSymbol = NULL;
		if (currentOnlineGraph) {
			currentOnlineGraph = NULL;
		}
		if (currentAlarmWindow) {
			QGraphicsProxyWidget * alarmProxy = new QGraphicsProxyWidget(currentWindow);
			alarmProxy->setZValue(MAX_ZVALUE + 1);
			alarmProxy->setWidget((QWidget *) currentAlarmWindow->getAlarmWindowWidget());
			currentAlarmWindow = NULL;
		}
		if (currentTimer) {
			currentTimer = NULL;
		}
	} else if (localName == "compoundSymbolList") {
		log(LM_DEBUG, "</compoundSymbolList");
		assert(currentCompoundSymbolList != NULL);
		currentCompoundSymbolList = NULL;
	} else if (localName == "compoundSymbol") {
		log(LM_DEBUG, "</compoundSymbol");
		assert(currentSymbol != NULL);
		currentSymbol = NULL;
	} else if (localName == "compoundSymbolTemplate") {
		log(LM_DEBUG, "</compoundSymbolTemplate");
		assert(currentCompoundSymbolTemplate!=NULL);
		currentCompoundSymbolTemplate = NULL;
	} else if (localName == "replacement") {
		log(LM_DEBUG, "</replacement");
		assert(currentReplacementTable != NULL);
		(*currentReplacementTable)[currentPair->first] = currentPair->second;
		assert(currentPair != NULL);
		currentPair = NULL;
	} else if (localName == "key") {
		log(LM_DEBUG, "</key");
	} else if (localName == "value") {
		log(LM_DEBUG, "</value");
		if (currentPair->second == NULL) { //replacement nema uvedene nove meno
			std::string oldName = currentPair->first;
			std::string newName = VOID_TAG_NAME;
			setSubstitutionTag(oldName, newName);
		}
	} else if (localName == "replacementTable") {
		log(LM_DEBUG, "</replacementTable");
		if (currentSymbol) {
			static_cast<CompoundSymbol *> (currentSymbol)->setReplacementTable(*currentReplacementTable);
			assert(currentReplacementTable != NULL);
			currentReplacementTable = NULL;
		} else {
			log(LM_ERROR, "replacementTable outside Symbol");
		}
	}

	else if (localName == "visualSymbol") {
		log(LM_DEBUG, "</visualSymbol");
		assert(currentSymbol != NULL);
		currentSymbol->fini();
		currentSymbol = NULL;
	}

	else if (localName == "onShow" || localName == "onHide" || localName == "onClick" || localName == "onCreate" || localName == "onDestroy" || localName == "onChange" || localName == "onTick") {
		log(LM_DEBUG, "</onShow || onhide || onclick || ondestroy || onChange");
		currentEvent->fini();
		if (currentEvent)
			currentEvent = NULL;
	}

	else if (localName == "handlerCode") {
		log(LM_DEBUG, "</handlerCode");
		currentHandlerCode = NULL;
	}

	/******************
	 *
	 * Linky
	 *
	 ******************/
	else if (localName == "linkList") {
		log(LM_DEBUG, "</linkList");
		assert(currentLinkList != NULL);
		currentLinkList = NULL;
	}

	else if (localName == "boundExpression") {
		log(LM_DEBUG, "</boundExpression");
		assert(currentBoundExpression != NULL);
		currentBoundExpression->fini();
		currentBoundExpression = NULL;
	}

	else if (localName == "expression") {
		log(LM_DEBUG, "</expression");
		assert(currentHandlerCode != NULL);
		currentHandlerCode = NULL;
	}

	else if (localName == "bgBlinkLink") {
		log(LM_DEBUG, "</bgBlinkLink");
		assert(currentBgBlinkLink != NULL);
		currentBgBlinkLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "fgBlinkLink") {
		log(LM_DEBUG, "</fgBlinkLink");
		assert(currentFgBlinkLink != NULL);
		currentFgBlinkLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "rotationLink") {
		log(LM_DEBUG, "</rotationLink");
		assert(currentRotationLink != NULL);
		currentRotationLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "fgColorLink") {
		log(LM_DEBUG, "</fgColorLink");
		assert(currentFgColorLink != NULL);
		currentFgColorLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "bgColorLink") {
		log(LM_DEBUG, "</bgColorLink");
		assert(currentBgColorLink != NULL);
		currentBgColorLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "horizontalFillLink") {
		log(LM_DEBUG, "</horizontalFillLink");
		assert(currentHorizontalFillLink != NULL);
		currentHorizontalFillLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "horizontalPositionLink") {
		log(LM_DEBUG, "</horizontalPositionLink");
		assert(currentHorizontalPositionLink != NULL);
		currentHorizontalPositionLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "horizontalSizeLink") {
		log(LM_DEBUG, "</horizontalSizeLink");
		assert(currentHorizontalSizeLink != NULL);
		currentHorizontalSizeLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "verticalFillLink") {
		log(LM_DEBUG, "</verticalFillLink");
		assert(currentVerticalFillLink != NULL);
		currentVerticalFillLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "verticalSizeLink") {
		log(LM_DEBUG, "</verticalSizeLink");
		assert(currentVerticalSizeLink != NULL);
		currentVerticalSizeLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "verticalPositionLink") {
		log(LM_DEBUG, "</verticalPositionLink");
		assert(currentVerticalPositionLink != NULL);
		currentVerticalPositionLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "visibilityLink") {
		log(LM_DEBUG, "</visibilityLink");
		assert(currentVisibilityLink != NULL);
		currentVisibilityLink = NULL;
		currentLink = NULL;
	}

	else if (localName == "colorTable") {
		log(LM_DEBUG, "</colorTable");
		assert(currentRangeValueList != NULL);
		currentRangeValueList = NULL;
	}

	else if (localName == "inputList" || localName == "outputList" || localName == "sensitivityList") {
		log(LM_DEBUG, "</inputList || outputList || sensitivityList");
		assert(currentTagList != NULL);
		currentTagList = NULL;
	} else if (localName == "genericScriptList") {
		log(LM_DEBUG, "</GenericScriptList");
		assert(currentGenericScriptList != NULL);
		currentGenericScriptList = NULL;
	} else if (localName == "genericScript") {
		log(LM_DEBUG, "</genericScript");
		assert(currentGenericScript != NULL);
		currentGenericScript = NULL;
	} else if (localName == "script") {
		log(LM_DEBUG, "</script");
		assert(currentScript != NULL);
		currentScript->fini();
		currentScript = NULL;
	} else if (localName == "code") {
		log(LM_DEBUG, "</code");
		assert(currentHandlerCode != NULL);
		currentHandlerCode = NULL;
	} else if (localName == "symbolList") {
		log(LM_DEBUG, "</symbolList");
		assert(currentSymbolList != NULL);
		currentSymbolList = NULL;
	} else if (localName == "manualRange") {
		log(LM_DEBUG, "</manualRange");
		assert(currentOnlineGraphPen != NULL);
	} else if (localName == "autoRange") {
		log(LM_DEBUG, "</autoRange");
		assert(currentOnlineGraphPen != NULL);
	} else if (localName == "tightRange") {
		log(LM_DEBUG, "</tightRange");
		assert(currentOnlineGraphPen != NULL);
	} else if (localName == "pen") {
		log(LM_DEBUG, "</pen");
		assert(currentOnlineGraphPen != NULL);
		currentOnlineGraphPen = NULL;
	} else if (localName == "configurations") {
		log(LM_DEBUG, "</configurations");
		assert(currentConfigurations != NULL);
		currentConfigurations = NULL;
	} else if (localName == "pythonModules") {
		log(LM_DEBUG, "</pythonModules");
		assert(currentPythonModule != NULL);
		currentPythonModule = NULL;
	} else if (localName == "hmi") {
		log(LM_DEBUG, "</hmi");
		hmi.fini();
		assert(currentWindowList == NULL);
		assert(currentWindow == NULL);
		assert(currentSymbol == NULL);
		assert(currentEvent == NULL);
		assert(currentLink == NULL);
		assert(currentLinkList == NULL);

		assert(currentBoundExpression == NULL);
		assert(currentBgBlinkLink == NULL);
		assert(currentFgBlinkLink == NULL);
		assert(currentBgColorLink == NULL);
		assert(currentFgColorLink == NULL);
		assert(currentHorizontalFillLink == NULL);
		assert(currentVerticalFillLink == NULL);
		assert(currentHorizontalPositionLink == NULL);
		assert(currentVerticalPositionLink == NULL);
		assert(currentRotationLink == NULL);
		assert(currentHorizontalSizeLink == NULL);
		assert(currentVerticalSizeLink == NULL);
		assert(currentVisibilityLink == NULL);

		assert(currentTagList == NULL);
		assert(currentGenericScriptList == NULL);
		assert(currentGenericScript == NULL);
		assert(currentScript == NULL);
		assert(currentCompoundSymbolTemplate == NULL);
		assert(currentCompoundSymbol == NULL);
		assert(currentCompoundSymbolList == NULL);
		assert(currentSymbolList == NULL);
		assert(currentHandlerCode == NULL);
		assert(currentRangeValueList == NULL);
		assert(currentOnlineGraph == NULL);
		assert(currentOnlineGraphPen == NULL);
		assert(currentConfigurations == NULL);
		assert(currentPythonModule == NULL);
		assert(currentAlarmWindow == NULL);
	} else {
		log(LM_DEBUG, "Nespracovane ukoncenie tagu: %s", localName.toStdString().c_str());
	}
	return true;
}

/**
 * Vytvori tag s menom newName a vlozi ho do zoznamov, kde sa nachadza oldName.
 */
void Handler::setSubstitutionTag(std::string & oldName, std::string & newName) {
	SuhubConnectorLight::StatefulTag *tag;
	if (newName == VOID_TAG_NAME) {
		tag = hmi.tagList.uniquePush(newName, true);
	} else {
		tag = hmi.tagList.uniquePush(newName, false);
	}
	StatefulTagVector::iterator tagIt = std::find_if(hmi.rTagList.tags.begin(), hmi.rTagList.tags.end(), std::bind2nd(find_by_name(), oldName));
	if (tagIt != hmi.rTagList.tags.end()) {
		hmi.rTagList.uniquePush(tag);
		currentPair->second = tag;
	}
	tagIt = std::find_if(hmi.wTagList.tags.begin(), hmi.wTagList.tags.end(), std::bind2nd(find_by_name(), oldName));
	if (tagIt != hmi.wTagList.tags.end()) {
		hmi.wTagList.uniquePush(tag);
		currentPair->second = tag;
	}
}

bool Handler::characters(const QString &str) {
	std::string stdStr = str.trimmed().toStdString();
	log(LM_DEBUG,"Characters: %s", stdStr.c_str());
	if (stdStr != "") {
		if (currentTagList) {
			assert(currentPair == NULL);
			assert(currentHandlerCode == NULL);
			log(LM_DEBUG,"TagName: %s", stdStr.c_str());

			SuhubConnectorLight::StatefulTag *tag = NULL;
			if (tagListType == in) {
				tag = hmi.tagList.uniquePush(stdStr);
				hmi.rTagList.uniquePush(tag);
			} else if (tagListType == out) {
				tag = hmi.tagList.uniquePush(stdStr);
				hmi.wTagList.uniquePush(tag);
			}
			currentTagList->uniquePush(tag);

		} else if (currentPair != NULL) {
			assert(currentTagList == NULL);
			assert(currentHandlerCode == NULL);
			if (isKey == true) {
				log(LM_DEBUG,"Hladam meno: %s", stdStr.c_str());
				hmi.rTagList.printTags();
				hmi.wTagList.printTags();

				currentPair->first = stdStr;
			} else {
				log(LM_DEBUG,"Value: %s", stdStr.c_str());
				//zamenit meno tagu aj v zoznamoch
				std::string oldName = currentPair->first;
				std::string newName = stdStr;
				setSubstitutionTag(oldName, newName);
			}
		} else if (currentHandlerCode) {
			assert(currentTagList == NULL);
			assert(currentPair == NULL);

			std::string code = str.toUtf8().data();
			currentHandlerCode->setCode(code);
			if (currentCompoundSymbolTemplate == NULL) { //ak to nie je CST, mozem ho rovno skompilovat; pri CST treba najskor nahradit nazvy tagov
				currentHandlerCode->compileCode();
			}
		} else if (currentSymbol && (currentSymbol->obType & IMAGE)) {
			static_cast<Image *> (currentSymbol)->setData(stdStr);
		} else if (currentPythonModule) {
			currentPythonModule->setBytes(stdStr);
		} else {
			log(LM_ERROR, "Unhandled characters: %s", stdStr.c_str());
		}
	}
	return true;
}

bool Handler::fatalError(const QXmlParseException &exception) {
	log(LM_CRITICAL, "%s", exception.message().toStdString().c_str());
	return false;
}

bool Handler::error(const QXmlParseException & exception) {
	log(LM_ERROR, "%s", exception.message().toStdString().c_str());
	return false;
}

QString Handler::errorString() const {
	return QString("errorString");
}

Hmi* Handler::getHmi() {
	return &hmi;
}
