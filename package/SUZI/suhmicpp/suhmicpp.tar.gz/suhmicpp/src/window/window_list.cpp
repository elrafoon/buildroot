/*
 * window_list.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#include <QDebug>
#include "suhmicpp/window/window_list.h"

WindowList::WindowList(): windowIndex(0) {
}

WindowList::~WindowList() {
	WindowVector::iterator it;
	for (it = windows.begin(); it != windows.end(); ++it) {
		delete *it;
	}
}

void WindowList::setAttributes(const QXmlAttributes &attributes) {
	defaultWindow = attributes.value("defaultWindow").toStdString();
}

void WindowList::create() {
	WindowVector::iterator it;
	for (it = windows.begin(); it != windows.end(); ++it) {
		(*it)->create();
	}
}

void WindowList::destroy() {
	WindowVector::iterator it;
	for (it = windows.begin(); it != windows.end(); ++it) {
		(*it)->destroy();
	}
}

void WindowList::fini() {
	int i = 0;
	for (WindowVector::iterator it = windows.begin(); it != windows.end(); ++it) {
		if ((*it)->name == defaultWindow) {
			windowIndex = i;
		}
		i++;
	}
}

