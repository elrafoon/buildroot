/*
 * window.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#include <QXmlAttributes>
#include <QPainter>
#include <QPrinterInfo>
#include <QDateTime>
#include "suhmicpp/window/window.h"

Window::Window(const QXmlAttributes &attributes) :
		onshow(this), onhide(this) {
	obType = obType | WINDOW;
	this->name = attributes.value("name").toStdString();
	bgColor.setNamedColor(attributes.value("bgColor"));
	identification = this->name;
}

Window::~Window() {

}

void Window::setSize(const QXmlAttributes &attributes) {
	size.setWidth(attributes.value(QString("width")).toInt());
	size.setHeight(attributes.value(QString("height")).toInt());
}

void Window::setSize(const int widht, const int height) {
	size = QSize(widht, height);
	prepareGeometryChange();
}

void Window::create() {
	ObjectBase::create();
	symbolList.create();
	for (AlarmWindowVector::iterator aw = alarmWindows.begin(); aw != alarmWindows.end(); ++aw) {
		(*aw)->create();
	}
}

void Window::destroy() {
	ObjectBase::destroy();
	symbolList.destroy();
	for (AlarmWindowVector::iterator aw = alarmWindows.begin(); aw != alarmWindows.end(); ++aw) {
		(*aw)->destroy();
	}
}

void Window::show() {
	onshow.exec();
	symbolList.show();
	for (AlarmWindowVector::iterator aw = alarmWindows.begin(); aw != alarmWindows.end(); ++aw) {
		(*aw)->show();
	}
}

void Window::hide() {
	onhide.exec();
	symbolList.hide();
	for (AlarmWindowVector::iterator aw = alarmWindows.begin(); aw != alarmWindows.end(); ++aw) {
		(*aw)->hide();
	}
}

QRectF Window::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void Window::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *widget) {
	QBrush brush(bgColor);
	painter->setBrush(brush);
	painter->drawRect(0, 0, size.width(), size.height());
}

void Window::setVisibility(bool value) {
	QGraphicsItem::setVisible(value);
}

bool Window::getVisibility() {
	return QGraphicsItem::isVisible();

}

void Window::fini() {
	ObjectBase::fini();
	symbolList.setDebugInfo(debugInfo, identification);
}

void Window::printScreen(std::string fullFfileName) {
	QPixmap p(size);
	QPainter painter;
	bool began = painter.begin(&p);
	if (began) {
		scene()->render(&painter, QRectF(0, 0, size.width(), size.height()), QRectF(0, 0, size.width(), size.height()));
		bool saved = p.save(fullFfileName.c_str(), "PNG");
		if (saved) {
			painter.end();
		} else {
			logger.log(LM_WARNING, "PrintScreen could not be saved! Filename:%s", fullFfileName.c_str());
		}
	} else {
		logger.log(LM_WARNING, "PrintScreen could not be painted!");
	}
}

void Window::hardCopy(std::string printerName, int _size, int orientation, bool fitToPage) {
	QPrinterInfo printer;
	QList<QPrinterInfo> printers = QPrinterInfo::availablePrinters();
	for (int i = 0; i < printers.size(); ++i) {
		if(printers.at(i).printerName().toStdString() == printerName){
			printer = printers.at(i);
		}
	}
	if (printer.isNull()){
		logger.log(LM_WARNING, "Printer %s not found!", printerName.c_str());
	}
	else{
		QPainter painter;
		QPrinter pdf(printer);
		QString time = QDateTime::currentDateTime().toString("yyyy_MM_dd_hh_mm_ss");
		pdf.setDocName("/home/vlado/PDF/suzi_" + time + ".pdf"); //pri nastavenom setOutputFileName tlaci iba do suboru
		if (orientation)
			pdf.setOrientation(QPrinter::Landscape);
		else
			pdf.setOrientation(QPrinter::Portrait);
		switch (_size) {
		case A0:
			pdf.setPaperSize(QPrinter::A0);
			break;
		case A1:
			pdf.setPaperSize(QPrinter::A1);
			break;
		case A2:
			pdf.setPaperSize(QPrinter::A2);
			break;
		case A3:
			pdf.setPaperSize(QPrinter::A3);
			break;
		case A4:
			pdf.setPaperSize(QPrinter::A4);
			break;
		case A5:
			pdf.setPaperSize(QPrinter::A5);
			break;
		default:
			pdf.setPaperSize(QPrinter::A4);
			break;
		}
		bool began = painter.begin(&pdf);
		if (began) {
			if (fitToPage) {
				scene()->render(&painter);
			} else {
				scene()->render(&painter, QRectF(0, 0, size.width(), size.height()), QRectF(0, 0, size.width(), size.height()));
			}
			painter.end();
		} else {
			logger.log(LM_WARNING, "Hardcopy could not be painted!");
		}
	}
}
