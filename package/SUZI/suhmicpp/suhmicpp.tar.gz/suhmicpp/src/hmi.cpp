/*
 * hmi.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */
#include "suhmicpp/hmi.h"

#include "suhmicpp/object_base.h"
#include "suhmicpp/scene.h"

Hmi::Hmi() :
	ObjectBase() {
	obType = obType | HMI;
	QObject::connect(&blinkTimer, SIGNAL(timeout()), static_cast<QObject *> (this), SLOT(hadleTimeout()));
}

void Hmi::hadleTimeout() {
	std::set<BlinkLink *>::const_iterator it;
	for (it = blinkLinks.begin(); it != blinkLinks.end(); ++it) {
		(*it)->handleTimeout();
	}
}

void Hmi::setAttributes(const QXmlAttributes &attr) {
	QString bgColorString = attr.value("bgColor");
	if (bgColorString.isEmpty())
		bgColor.setNamedColor("white");
	else
		bgColor.setNamedColor(bgColorString);
	appName = attr.value("appName").toUtf8().data();
	appVersion = attr.value("appVersion").toUtf8().data();
	madeFor = attr.value("madeFor").toUtf8().data();
	author = attr.value("author").toUtf8().data();
	company = attr.value("company").toUtf8().data();
	date = attr.value("date").toUtf8().data();
}

void Hmi::create() {
	ObjectBase::create();
	windowList.create();
}

void Hmi::destroy() {
	ObjectBase::destroy();
	windowList.destroy();
}


void Hmi::setConfigurations(const QXmlAttributes &attributes){

}

void Hmi::fini(){
	blinkTimer.start(50); //ms
}

void Hmi::exitApp(){
	destroy();
	exit(EXIT_SUCCESS);
}
