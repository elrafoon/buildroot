/*
 * python_module.cpp
 *
 *  Created on: Aug 24, 2011
 *      Author: vlado
 */

#include <iostream>
#include <fstream>

#include <errno.h>
#include <fcntl.h>
#include <libtar.h>

#include "suhmicpp/python_module.h"
#include "suhmicpp/util/config.h"

#define MAX_FILE_LENGTH 101
#define MAX_PATH_LENGTH 51

PythonModule::PythonModule(const QXmlAttributes &attributes) {
}

int PythonModule::setBytes(std::string &bytes) {
	const QByteArray ba = QByteArray::fromHex(bytes.c_str());
	path = config->basePythonDir;
	std::string filePath = path + "/suhmi-cpp.tar";

	char fileBuff[MAX_FILE_LENGTH];
	char pathBuff[MAX_PATH_LENGTH];
	path.copy(pathBuff, path.size());
	pathBuff[path.size()] = '\0';
	filePath.copy(fileBuff, filePath.size());
	fileBuff[filePath.size()] = '\0';
	ofstream outfile(fileBuff, ios::out | ios::binary);
	outfile.write(ba.constData(), bytes.size());
	outfile.close();

	TAR *t;
	if (tar_open(&t, fileBuff, NULL, O_RDONLY, 644, TAR_GNU)) {
		log(LM_ERROR, "Opening tar file: %s failed: %s", fileBuff, strerror(errno));
		return -1;
	}
	if (tar_extract_all(t, pathBuff)) {
		log(LM_ERROR, "Extracting tar file to: %s directory failed: %s", pathBuff, strerror(errno));
		return -1;
	}
	return 0;
}

