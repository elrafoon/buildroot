/*
 * onchange.cpp
 *
 *  Created on: Jan 18, 2011
 *      Author: vlado
 */

#include "suhmicpp/events/onchange.h"

OnChange::OnChange(ObjectBase *ob) : Event(ob){
	identification = "OnChange";
}

void OnChange::exec(std::string &newText){
	handlerCode.exec(inputList, outputList, newText);
}

void OnChange::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
