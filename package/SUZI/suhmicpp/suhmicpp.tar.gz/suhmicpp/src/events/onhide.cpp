/*
 * onhide.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */
#include "suhmicpp/events/onhide.h"

OnHide::OnHide(ObjectBase *ob) : Event(ob){
	identification = "OnHide";
}

void OnHide::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
