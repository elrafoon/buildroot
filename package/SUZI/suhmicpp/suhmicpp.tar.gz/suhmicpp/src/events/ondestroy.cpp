/*
 * ondestroy.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/events/ondestroy.h"
#include "suhmicpp/events/event.h"

OnDestroy::OnDestroy(ObjectBase *ob) :
	Event(ob) {
	identification = "OnDestroy";
}

OnDestroy::OnDestroy(const OnDestroy &od, ObjectBase *ob) : Event(od, ob){

}

void OnDestroy::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
