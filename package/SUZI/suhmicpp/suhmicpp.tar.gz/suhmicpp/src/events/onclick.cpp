/*
 * onclick.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/events/onclick.h"

OnClick::OnClick(ObjectBase *ob) : Event(ob){
	identification = "OnClick";
}

OnClick::OnClick(const OnClick &oc, ObjectBase *ob) : Event(oc, ob){
	identification = "OnClick";
}

void OnClick::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
