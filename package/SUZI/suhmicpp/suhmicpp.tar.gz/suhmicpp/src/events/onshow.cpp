/*
 * onshow.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/events/onshow.h"
#include "suhmicpp/events/event.h"

OnShow::OnShow(ObjectBase *ob) : Event(ob){
	identification = "OnShow";
}

void OnShow::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
