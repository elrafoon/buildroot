/*
 * oncreate.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/events/oncreate.h"

OnCreate::OnCreate(ObjectBase *ob) : Event(ob){
	identification = "OnCreate";
}

OnCreate::OnCreate(const OnCreate &oc, ObjectBase *ob) : Event(oc, ob){

}

void OnCreate::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
