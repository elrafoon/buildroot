/*
 * sevent.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include <algorithm>
#include <functional>
#include "suhmicpp/events/event.h"

Event::Event(ObjectBase *ob) :
	handlerCode(ob) {
}

Event::Event(const Event &e, ObjectBase *ob) :
	handlerCode(e.handlerCode, ob), inputList(e.inputList), outputList(e.outputList) {
	fini();
}

int Event::exec() {
	return handlerCode.exec(inputList, outputList);
}

//TODO(vlado): pozri script.cpp a bound_expression.cpp, nahradzovanie tagov treba zjednotit
void Event::setReplacementTable(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable) {
	handlerCode.replaceTags(replacementTable, &inputList.tags, &outputList.tags);

	std::map<std::string, SuhubConnectorLight::StatefulTag *>::iterator replacement;
	for (replacement = replacementTable.begin(); replacement != replacementTable.end(); ++replacement) {
		std::string oldName = (*replacement).first;
		std::string newName = (*replacement).second->name;
		TagList::StatefulTagVector::iterator jt = std::find_if(inputList.tags.begin(), inputList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != inputList.tags.end()) {
			inputList.tags.erase(jt);
			inputList.uniquePush((*replacement).second);
		}

		jt = std::find_if(outputList.tags.begin(), outputList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != outputList.tags.end()) {
			outputList.tags.erase(jt);
			outputList.uniquePush((*replacement).second);
		}
	}
}

void Event::fini(){
	for (TagList::StatefulTagVector::iterator it = inputList.tags.begin(); it != inputList.tags.end(); ++it) {
		handlerCode.addTag(*it);
	}
	for (TagList::StatefulTagVector::iterator it = outputList.tags.begin(); it != outputList.tags.end(); ++it) {
		handlerCode.addTag(*it);
	}
}
