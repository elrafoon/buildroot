/*
 * ontick.cpp
 *
 *  Created on: Sep 10, 2011
 *      Author: vlado
 */

#include "suhmicpp/events/ontick.h"

OnTick::OnTick(ObjectBase *ob) : Event(ob){
	identification = "OnTick";
}

OnTick::OnTick(const OnTick &ot, ObjectBase *ob) : Event(ot, ob){
	identification = "OnTick";
}

void OnTick::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	handlerCode.setDebugInfo(this->debugInfo, identification);
}
