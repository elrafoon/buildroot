/*
 * generic_script.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/generic_script.h"

/*GenericScript::GenericScript(ObjectBase *ob): script(ob){
	this->name += "No name";
}*/

GenericScript::GenericScript(ObjectBase *ob, const QXmlAttributes &attributes): script(ob){
	this->name = attributes.value("name").toStdString();
	identification = name;
}

GenericScript::GenericScript(const GenericScript &gs, ObjectBase *ob) : name(gs.name), script(gs.script, ob){

}

void GenericScript::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	script.code.setDebugInfo(this->debugInfo, identification);
}
