/*
 * suzi_scene.cpp
 *
 *  Created on: Jun 28, 2010
 *      Author: vlado
 */

#include <QtDebug>
#include <QGraphicsItem>
#include <vector>
#include "suhmicpp/scene.h"
#include "suhmicpp/symbols/rect.h"
#include "suhmicpp/hmi.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/lists/compound_symbol_list.h"
#include "suhmicpp/symbols/compound_symbol.h"
#include "suhmicpp/window/window_list.h"
#include "suhmicpp/error_indication/error_button.h"

extern ErrorButton *errorButton;

Scene::Scene(QObject *parent) :
	QGraphicsScene(parent), okno(1) {
	for (int i = 0; i < 1280; i = i + 50) {
		if (0) {
			// Mriezka
			QPen pen;
			pen.setColor(QColor(128, 128, 128, 255));
			addLine(i, 0, i, 1280, pen);
			addLine(0, i, 1024, i, pen);
		}
	}
	addItem(errorButton);
}

/**
 * Priradi scene hlavny objekt hmi. Prida symboly na scenu.
 */
void Scene::setHmi(Hmi &hmi) {
	this->hmi = &hmi;
	setBackgroundBrush(this->hmi->bgColor);
	/*std::vector<Window *>::iterator wi;
	 for (wi = this->hmi->windowList.windows.begin(); wi != this->hmi->windowList.windows.end(); wi++) {
	 std::vector<Symbol *>::iterator si;
	 for (si = (*wi)->symbolList.symbol.begin(); si < (*wi)->symbolList.symbol.end(); si++) {
	 if ((*si)->obType and VISUAL_SYMBOL) {
	 QGraphicsItem *gi = static_cast<VisualSymbol*> (*si);
	 addItem(gi);
	 }
	 }
	 }*/
	qDebug() << "Scene::setHmi nastavujem okno: " << this->hmi->windowList.windowIndex;

	int i = 0;
	for (WindowList::WindowVector::iterator it = this->hmi->windowList.windows.begin(); it != this->hmi->windowList.windows.end(); ++it) {
		if (i == this->hmi->windowList.windowIndex) {
			(*it)->setVisibility(true);
			for (std::vector<AlarmWindow *>::iterator aw = (*it)->alarmWindows.begin(); aw != (*it)->alarmWindows.end(); ++aw) {
				//addWidget(static_cast<QWidget *>(*aw));
			}
			errorButton->move((*it)->size);
		} else {
			(*it)->setVisibility(false);
		}
		addItem(*it);
		(*it)->show();
		i++;
	}
}

/**
 * Vypise tagy z TagListu.
 */
void Scene::printTagList(TagList &taglist) {
	TagList::StatefulTagVector::iterator ti;
	for (ti = taglist.tags.begin(); ti < taglist.tags.end(); ti++) {
		qDebug() << "SCENE: tag " << (*ti)->name.c_str();
		//tagCache.registerTag((*ti));
	}
}

void Scene::keyPressEvent(QKeyEvent * keyEvent) {
	keyEvent->accept();
	qDebug() << "keyPressEvent";
	if (keyEvent->key() == Qt::Key_Right || keyEvent->key() == Qt::Key_Left) {
		int currentWinIndex = this->hmi->windowList.windowIndex;
		int nextWinIndex;
		if (keyEvent->key() == Qt::Key_Right || keyEvent->key() == Qt::Key_Left) {
			if (keyEvent->key() == Qt::Key_Right) {
				nextWinIndex = (hmi->windowList.windowIndex + 1) % hmi->windowList.windows.size();
			} else if (keyEvent->key() == Qt::Key_Left) {
				nextWinIndex = (hmi->windowList.windowIndex - 1) % hmi->windowList.windows.size();
			}
			Window *currentWin = hmi->windowList.windows[this->hmi->windowList.windowIndex];
			Window *nextWin = hmi->windowList.windows[nextWinIndex];

			currentWin->setVisibility(false);
			currentWin->hide();
			hmi->windowList.windowIndex = nextWinIndex;
			nextWin->setVisibility(true);
			nextWin->show();
			errorButton->move(nextWin->size);
			update(0, 0, 1024, 1024);
		}
	}
}

void Scene::setBgColor(QColor &bgColor) {
	QGraphicsScene::setBackgroundBrush(QBrush(bgColor));
}
