/*
 * script.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/util/profile_timer.h"
#include <algorithm>
#include <functional>
#include "suhmicpp/script.h"

Script::Script(ObjectBase *ob) :
	code(ob), ob(ob), logger("Script") {
}

Script::Script(const Script &s, ObjectBase *ob) :
	sensitivityList(s.sensitivityList), inputList(s.inputList), outputList(s.outputList), code(s.code, ob), ob(ob), logger("Script") {
	fini();
}

/**
 * Zisti ci doslo k zmene tagu zo sensitivityListu a pripadne spusti kod code.
 */
void Script::onUpdate(const SuhubConnectorLight::UpdateList &updateList) {
	logger.log(LM_TRACE, "onUpdate");
#ifdef PROFILE_TIMER
	std::string timerName("Script::onUpdate");
	ProfileTimer t(timerName);
#endif


	bool exec = false;
	SuhubConnectorLight::UpdateList::const_iterator it;
	for (it = updateList.begin(); it != updateList.end(); ++it) {
		logger.log(LM_DEBUG, "Update: %s, V: %f", (*it).pTag->name.c_str(), (*it).vtq.v);
		TagList::StatefulTagVector::iterator jt = std::find_if(sensitivityList.tags.begin(), sensitivityList.tags.end(), std::bind2nd(TagList::find_by_name(), (*it).pTag->name));
		if (jt != sensitivityList.tags.end()) {
			exec = true;
			break;
		}
		if (exec)
			break;
	}
	if (exec) {
		logger.log(LM_DEBUG, "Updated tag in sensitivity list, executing script");
		code.exec(updateList, outputList);
	} else {
		logger.log(LM_DEBUG, "Updated tag not in sensitivity list");
	}
}

void Script::fini() {
	for (TagList::StatefulTagVector::iterator it = sensitivityList.tags.begin(); it != sensitivityList.tags.end(); ++it) {
		code.addTag(*it);
	}
	for (TagList::StatefulTagVector::iterator it = inputList.tags.begin(); it != inputList.tags.end(); ++it) {
		code.addTag(*it);
	}
	for (TagList::StatefulTagVector::iterator it = outputList.tags.begin(); it != outputList.tags.end(); ++it) {
		code.addTag(*it);
	}
}

/**
 * Nahradi tagy v code, inputList, sensitivityList, ouputList.
 */
void Script::replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable) {
	code.replaceTags(replacementTable, &inputList.tags, &sensitivityList.tags, &outputList.tags);

	std::map<std::string, SuhubConnectorLight::StatefulTag *>::iterator replacement;
	for (replacement = replacementTable.begin(); replacement != replacementTable.end(); ++replacement) {
		std::string oldName = (*replacement).first;
		std::string newName = (*replacement).second->name;
		logger.log(LM_DEBUG, "Replacing %s for %s", oldName.c_str(), newName.c_str());
		TagList::StatefulTagVector::iterator jt = std::find_if(inputList.tags.begin(), inputList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != inputList.tags.end()) {
			inputList.tags.erase(jt);
			inputList.uniquePush((*replacement).second);
		}

		jt = std::find_if(sensitivityList.tags.begin(), sensitivityList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != sensitivityList.tags.end()) {
			sensitivityList.tags.erase(jt);
			sensitivityList.uniquePush((*replacement).second);
		}

		jt = std::find_if(outputList.tags.begin(), outputList.tags.end(), std::bind2nd(TagList::find_by_name(), oldName));
		if (jt != outputList.tags.end()) {
			outputList.tags.erase(jt);
			outputList.uniquePush((*replacement).second);
		}
	}
}
