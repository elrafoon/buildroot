/*
 * tag_list.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include <QDebug>
#include "suhmicpp/lists/tag_list.h"
#include <algorithm>

TagList::TagList(const TagList &tl) {
	tags = tl.tags;
}

SuhubConnectorLight::StatefulTag* TagList::findTagByName(std::string &name) {
	StatefulTagVector::iterator tag = std::find_if(tags.begin(), tags.end(), std::bind2nd(find_by_name(), name));
	if (tag == tags.end())
		return NULL;
	else
		return *tag;
}

SuhubConnectorLight::StatefulTag * TagList::uniquePush(std::string tagName, bool internal) {
	SuhubConnectorLight::StatefulTag *tag = NULL;
	StatefulTagVector::iterator tagIt = std::find_if(tags.begin(), tags.end(), std::bind2nd(find_by_name(), tagName));
	if (tagIt == tags.end()) {
		tag = new SuhubConnectorLight::StatefulTag(tagName, internal);
		tags.push_back(tag);
	} else {
		tag = *tagIt;
	}
	return tag;
}

void TagList::uniquePush(SuhubConnectorLight::StatefulTag *tag) {
	StatefulTagVector::iterator tagIt = find(tags.begin(), tags.end(), tag);
	if (tagIt == tags.end()) {
		tags.push_back(tag);
	}
}

void TagList::printTags() {
	StatefulTagVector::iterator it;
	for (it = tags.begin(); it != tags.end(); ++it)
		qDebug() << "Tag: " << (*it)->name.c_str();
}

void TagList::eraseTemplateTags() {
	StatefulTagVector::iterator end = std::remove_if(tags.begin(), tags.end(), isTemplateTag());
	for (StatefulTagVector::iterator it = end; it != tags.end();) { // it je posuvane cez erase
		it = tags.erase(it);
	}
}
