/*
 * symbol_list.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#include "suhmicpp/lists/symbol_list.h"
#include "suhmicpp/symbols/visual_symbol.h"

SymbolList::SymbolList(){

}

void SymbolList::create(){
	SymbolVector::iterator it;
	for (it = symbol.begin(); it != symbol.end(); ++it) {
		(*it)->create();
	}
}

void SymbolList::destroy(){
	SymbolVector::iterator it;
	for (it = symbol.begin(); it != symbol.end(); ++it) {
		(*it)->destroy();
	}
}

SymbolList::~SymbolList(){
	for (SymbolVector::iterator it = symbol.begin(); it != symbol.end(); ++it) {
		delete *it;
	}
}

void SymbolList::show(){
	SymbolVector::iterator it;
	for (it = symbol.begin(); it != symbol.end(); ++it) {
		if ((*it)->obType & VISUAL_SYMBOL){
			static_cast<VisualSymbol *>(*it)->show();
		}
	}
}

void SymbolList::hide(){
	SymbolVector::iterator it;
	for (it = symbol.begin(); it != symbol.end(); ++it) {
		if ((*it)->obType & VISUAL_SYMBOL){
			static_cast<VisualSymbol *>(*it)->hide();
		}
	}
}

void SymbolList::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	for(SymbolVector::iterator it = symbol.begin(); it != symbol.end(); ++it){
		(*it)->setDebugInfo(this->debugInfo, identification);
	}
}
