/*
 * range_value_list.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/lists/range_value_list.h"

RangeValueList::RangeValueList(){


}
