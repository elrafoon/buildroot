/*
 * compound_symbol_list.cpp
 *
 *  Created on: Jul 14, 2010
 *      Author: vlado
 */

#include "suhmicpp/lists/compound_symbol_list.h"

CompoundSymbolList::CompoundSymbolList() {

}

/**
 * Zmaze templaty zo zoznamu a vycisti zoznam.
 */
void CompoundSymbolList::deleteTemplates(){
	std::vector<CompoundSymbolTemplate *>::iterator it;
	it = compoundSymbol.begin();
	for (it = compoundSymbol.begin(); it != compoundSymbol.end(); ++it) {
		delete *it;
	}
	compoundSymbol.clear();
}
