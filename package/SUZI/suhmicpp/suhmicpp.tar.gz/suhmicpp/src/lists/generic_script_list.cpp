/*
 * generic_script_list.cpp
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#include "suhmicpp/object_base.h"
#include "suhmicpp/lists/generic_script_list.h"

GenericScriptList::GenericScriptList(ObjectBase *ob): ob(ob){
}

GenericScriptList::GenericScriptList(const GenericScriptList &gsl, ObjectBase *ob): ob(ob){
	std::vector<GenericScript *>::const_iterator it;
	for(it = gsl.genericScript.begin(); it < gsl.genericScript.end(); ++it) {
		GenericScript *gs = new GenericScript(*(*it), ob);
		genericScript.push_back(gs);
	}
}

void GenericScriptList::setReplacementTable(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable){
	for(std::vector<GenericScript *>::iterator it = genericScript.begin(); it != genericScript.end(); ++it){
		(*it)->script.replaceTags(replacementTable);
	}
}

void GenericScriptList::compileCodes(){
	for(std::vector<GenericScript *>::iterator it = genericScript.begin(); it != genericScript.end(); ++it){
		(*it)->script.code.compileCode();
	}
}

void GenericScriptList::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId){
	Traceable::setDebugInfo(debugInfo, parentId);
	for(std::vector<GenericScript *>::iterator it = genericScript.begin(); it != genericScript.end(); ++it){
		(*it)->setDebugInfo(this->debugInfo, identification);
	}
}
