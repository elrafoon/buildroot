/*
 * object_base.cpp
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#include <iostream>
#include "suhmicpp/object_base.h"

ObjectBase::ObjectBase() : genericScriptList(this), oncreate(this), ondestroy(this){
	obType = 0x0;
}

ObjectBase::ObjectBase(const ObjectBase &ob) : obType(ob.obType), genericScriptList(ob.genericScriptList, this), oncreate(ob.oncreate, this), ondestroy(ob.ondestroy, this){
};

ObjectBase::~ObjectBase(){
}

/**
 * Signal na vyvolanie onCreate.
 */
void ObjectBase::create(){
	oncreate.exec();
}

/**
 * Signal na vyvolanie onDestroy.
 */
void ObjectBase::destroy(){
	ondestroy.exec();
}

void ObjectBase::fini(){
	oncreate.handlerCode.compileCode();
	ondestroy.handlerCode.compileCode();
}
