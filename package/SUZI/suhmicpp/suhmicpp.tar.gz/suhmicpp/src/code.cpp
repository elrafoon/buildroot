/*
 * code.cpp
 *
 *  Created on: Sep 29, 2010
 *      Author: vlado
 */

#include <time.h>
#include <stdint.h>

#include "suhmicpp/util/profile_timer.h"
#include "suhmicpp/code.h"
#include "suhmicpp/adapters/symbol_adapt.h"
#include "suhmicpp/adapters/hmi_adapt.h"
#include "suhmicpp/adapters/window_adapt.h"
#include "suhmicpp/object_base.h"
#include <scl/hlapi/data_writer.h>
#include "suhmicpp/connector_instance.h"

#include "suhmicpp/util/profile_timer.h"

#define VOID_TAG_NAME	"___void___"
#define newTextName "newText" //nazov premennej, ktora vstupuje do onChange
#define coding "utf-8"
extern HmiAdapt *currentHmi;
extern SymbolAdapt *currentSymbol;
extern WindowAdapt *currentWindow;

Code::Code(ObjectBase *ob) : PrefixedLogger("Code: "),
	ob(ob), code(""), createTag(NULL), codeObject(NULL) {
	init();
}

Code::Code(const Code &c, ObjectBase *ob) : Traceable(c), ob(ob), code(c.code), codeObject(NULL), debugInfo(c.debugInfo) {
	log(LM_DEBUG,"Skopirovany kod: %s", c.code.c_str());
	init();
}

Code::~Code() {
	if (codeObject) {
		Py_DECREF(codeObject)
			;
	}

	Py_DECREF(globals)
		;
	Py_DECREF(suhmiCppModule)
		;
	Py_DECREF(createTag)
		;
}

/**
 * Vytvori slovnik globals a vlozi do nich moduly __builtins__, hmi, suhmi_cpp a triedy z modulu constants.
 */
int Code::init() {
	PyObject *thisModule = Py_InitModule("suzi_module", NULL);

	PyObject *mainDict = PyModule_GetDict(thisModule); //Borrowed reference
	globals = PyDict_Copy(mainDict);
	Py_INCREF(globals);

	PyObject *builtins = PyImport_ImportModule("__builtin__");
	if (builtins) {
		PyDict_SetItemString(globals, "__builtins__", builtins);
	} else {
		PyErr_Print();
		log(LM_ERROR, "Modul __builtins__ sa nepodarilo naimportovat");
		log(LM_ERROR, "%s", getErrorDesc().c_str());
		exit(EXIT_FAILURE);
	}

	PyObject *hmiImport = PyImport_ImportModule("hmi");
	if (hmiImport) {
		PyDict_SetItemString(globals, "hmi", hmiImport);
		Py_DECREF(hmiImport)
			;
	} else {
		PyErr_Print();
		log(LM_ERROR, "Modul hmi sa nepodarilo naimportovat");
		log(LM_ERROR, "%s", getErrorDesc().c_str());
		exit(EXIT_FAILURE);
	}

	suhmiCppModule = PyImport_ImportModule("suhmi_cpp");
	if (suhmiCppModule) {
		createTag = PyObject_GetAttrString(suhmiCppModule, "createTag");
		if (PyErr_Occurred()) {
			PyErr_Print();
			log(LM_ERROR, "Modul suhmi_cpp neobsahuje metodu createTag");
			log(LM_ERROR, "%s", getErrorDesc().c_str());
		}
		if (createTag == NULL) {
			log(LM_ERROR, "Nepodarilo sa importovat metodu createTag z modulu suhmi_cpp.");
		}
	} else {
		log(LM_ERROR, "Modul suhmi_cpp sa nepodarilo naimportovat");
		log(LM_ERROR, "%s", getErrorDesc().c_str());
		exit(EXIT_FAILURE);
	}

	// Z modulu constants importnem vsetky triedy
	PyObject *suhmi_cpp = PyImport_ImportModule("suhmi_cpp");
	if (suhmi_cpp) {
		PyObject *font = PyObject_GetAttrString(suhmi_cpp, "Font");
		if (font) {
			PyDict_SetItemString(globals, "Font", font);
			Py_DECREF(font)
				;
		} else {
			log(LM_ERROR, "%s", getErrorDesc().c_str());
			exit(EXIT_FAILURE);
		}

		PyObject *print = PyObject_GetAttrString(suhmi_cpp, "Print");
		if (print) {
			PyDict_SetItemString(globals, "Print", print);
			Py_DECREF(print)
				;
		} else {
			log(LM_ERROR, "%s", getErrorDesc().c_str());
			exit(EXIT_FAILURE);
		}

		PyObject *bgstyle = PyObject_GetAttrString(suhmi_cpp, "BgStyle");
		if (bgstyle) {
			PyDict_SetItemString(globals, "BgStyle", bgstyle);
			Py_DECREF(bgstyle)
				;
		} else {
			log(LM_ERROR, "%s", getErrorDesc().c_str());
			exit(EXIT_FAILURE);
		}

		PyObject *fgstyle = PyObject_GetAttrString(suhmi_cpp, "FgStyle");
		if (fgstyle) {
			PyDict_SetItemString(globals, "FgStyle", fgstyle);
			Py_DECREF(fgstyle)
				;
		} else {
			log(LM_ERROR, "%s", getErrorDesc().c_str());
			exit(EXIT_FAILURE);
		}

		PyObject *arcType = PyObject_GetAttrString(suhmi_cpp, "ArcType");
		if (arcType) {
			PyDict_SetItemString(globals, "ArcType", arcType);
			Py_DECREF(arcType)
				;
		} else {
			log(LM_ERROR, "%s", getErrorDesc().c_str());
			exit(EXIT_FAILURE);
		}

		PyObject *alignment = PyObject_GetAttrString(suhmi_cpp, "Alignment");
		if (alignment) {
			PyDict_SetItemString(globals, "Alignment", alignment);
			Py_DECREF(alignment)
				;
		} else {
			log(LM_ERROR, "%s", getErrorDesc().c_str());
			exit(EXIT_FAILURE);
		}

		Py_DECREF(suhmi_cpp)
			;
	} else {
		log(LM_ERROR, "Modul constants sa nepodarilo naimportovat");
		log(LM_ERROR, "%s", getErrorDesc().c_str());
		exit(EXIT_FAILURE);
	}
	return 0;
}

/**
 * Pred string str prida kod na nastavenie premmennych app a current a odstrani znaky '$' a '!' z mien tagov. V mene nahradzovanych tagov zameni '?' za '_'.
 */
void Code::setCode(const std::string &str) {
	code.clear();
	if (!str.empty()) {
		std::string preamble("app = hmi.cvar.hmiAdapt\n");
		if (ob->obType & SYMBOL) {
			preamble += "current = hmi.cvar.currentSymbol\n";
			//preamble += QString("current = hmi.cvar.currentSymbol\n");
		} else if (ob->obType & WINDOW) {
			preamble += "current = hmi.cvar.currentWindow\n";
			//preamble += QString("current = hmi.cvar.currentWindow\n");
		} else if (ob->obType & HMI) {
			preamble += "current = hmi.cvar.currentHmi\n";
			//preamble += QString("current = hmi.cvar.currentHmi\n");
		} else {
			log(LM_WARNING, "setCode: neznamy typ objektu");
		}
		code += preamble;
		code += str;

		//znaky $ a ! treba odobrat iba mimo komentara a stringu
		bool isInComment = false;
		bool isInApostrophes = false;
		bool isInSingleQuotes = false;
		bool isInTripleQuotes = false;
		for (std::string::iterator it = code.begin(); it != code.end(); ++it) {
			switch (*it) {
			case '#':
				isInComment = true;
				break;
			case '\n':
				if (isInComment) {
					isInComment = false;
				}
				break;
			case '\'':
				if (!isInApostrophes) { //otvaraci
					isInApostrophes = true;
				} else { // zatvaraci
					isInApostrophes = false;
				}
				break;
			case '"':
				if (*(it + 1) == '"') { // ide o trojite uvodzovky
					if (!isInTripleQuotes) { // otvaracie uvodzovky
						isInTripleQuotes = true;
					} else { // otvaracie
						isInTripleQuotes = false;
					}
				} else {
					if (!isInSingleQuotes) { // otvaracie uvodzovky
						isInSingleQuotes = true;
					} else { // zatvaracie
						isInSingleQuotes = false;
					}
				}
				break;
			case '$':
				if (!isInComment && !isInApostrophes && !isInSingleQuotes && !isInTripleQuotes) {
					code.replace(it, it + 1, "");
					it--;
				}
				break;
			case '!':
				if (!isInComment && !isInApostrophes && !isInSingleQuotes && !isInTripleQuotes) {
					code.replace(it, it + 1, "");
					it--;
				}
				break;
			case '?':
				if (!isInComment && !isInApostrophes && !isInSingleQuotes && !isInTripleQuotes) {
					code.replace(it, it + 1, "_");
				}
				break;
			default:
				break;
			}
		}

		code += '\n'; // kvoli http://bugs.python.org/issue1184112
	}
	log(LM_DEBUG, "setCode: %s", code.c_str());
}

/**
 * Skompiluje nastaveny zdrojovy kod do codeObject.
 */
void Code::compileCode() {
	log(LM_DEBUG, "Compiling code: ");
	log(LM_DEBUG, "%s", code.c_str());
	codeObject = Py_CompileString(code.c_str(), "code.txt", Py_file_input);
	if (codeObject != NULL) {
		if (PyErr_Occurred()) {
			log(LM_ERROR, "Handler kod sa nepodarilo skompilovat");
			log(LM_ERROR, "%s", getErrorDesc().c_str());
		}
	} else if (PyErr_ExceptionMatches(PyExc_SyntaxError)) {
		codeObject = NULL;
		log(LM_ERROR, "Syntax error");
		log(LM_ERROR, "%s", getErrorDesc().c_str());
		PyErr_Print();
	} else {
		log(LM_ERROR, "CODE Handler Kod sa neda skompilovat!");
		log(LM_ERROR, "%s", getErrorDesc().c_str());
	}
}

std::string& Code::getCode() {
	return code;
}

/**
 * Vytvori a vlozi tag so zadanym menom do zadaneho slovnika.
 * Vola sa pred vykonanim kodu.
 */
void Code::addTag(SuhubConnectorLight::StatefulTag *tag) {
	PyObject *pyTag = PyDict_GetItemString(globals, tag->name.c_str()); //borrowed
	if (!pyTag) {
		if (tag->name.compare(VOID_TAG_NAME) == 0) {
			pyTag = PyObject_GetAttrString(suhmiCppModule, "voidTag"); //new
		} else {
			pyTag = PyObject_CallObject(createTag, NULL); //new
		}
	} else {
		Py_INCREF(pyTag);
	}
	if (PyDict_SetItemString(globals, tag->name.c_str(), pyTag) == -1) {
		log(LM_WARNING, "CODE: Chyba pri vkladani tagu: %s do globals", tag->name.c_str());
	} else {
		log(LM_DEBUG, "Vlozeny tag: %s do globals", tag->name.c_str());
	}

	//tu uz musi existovat pyTag
	PyObject *name = PyString_FromString(tag->name.c_str());
	PyObject *v = PyFloat_FromDouble(tag->value.v);
	PyObject *t = PyFloat_FromDouble(tag->value.t);
	PyObject *q = PyInt_FromLong(tag->value.q);

	PyObject_SetAttrString(pyTag, "name", name);
	PyObject_SetAttrString(pyTag, "v", v);
	PyObject_SetAttrString(pyTag, "t", t);
	PyObject_SetAttrString(pyTag, "q", q);
	Py_DECREF(name)
		;
	Py_DECREF(v)
		;
	Py_DECREF(t)
		;
	Py_DECREF(q)
		;

	Py_XDECREF(pyTag)
		;
}

void Code::updateTags(SuhubConnectorLight::StatefulTag *tag) {
	PyObject *pyTag = PyDict_GetItemString(globals, tag->name.c_str()); //borrowed
	if (!pyTag) {
		if (tag->name.compare(VOID_TAG_NAME) == 0) {
			pyTag = PyObject_GetAttrString(suhmiCppModule, "voidTag"); //new
		} else {
			pyTag = PyObject_CallObject(createTag, NULL); //new
			if (PyDict_SetItemString(globals, tag->name.c_str(), pyTag) == -1) {
				log(LM_ERROR, "Chyba pri vkladani tagu: %s do globals", tag->name.c_str());
			}
		}
	} else {
		Py_INCREF(pyTag);
	}
	//tu uz musi existovat pyTag
	PyObject *name = PyString_FromString(tag->name.c_str());
	PyObject *v = PyFloat_FromDouble(tag->value.v);
	PyObject *t = PyFloat_FromDouble(tag->value.t);
	PyObject *q = PyInt_FromLong(tag->value.q);

	PyObject_SetAttrString(pyTag, "name", name);
	PyObject_SetAttrString(pyTag, "v", v);
	PyObject_SetAttrString(pyTag, "t", t);
	PyObject_SetAttrString(pyTag, "q", q);
	Py_DECREF(name)
		;
	Py_DECREF(v)
		;
	Py_DECREF(t)
		;
	Py_DECREF(q)
		;

	Py_XDECREF(pyTag)
		;

}

void Code::updateTags(const SuhubConnectorLight::Update &update) {
	PyObject *pyTag = PyDict_GetItemString(globals, update.pTag->name.c_str()); //borrowed
	if (!pyTag) {
		if (update.pTag->name.compare(VOID_TAG_NAME) == 0) {
			pyTag = PyObject_GetAttrString(suhmiCppModule, "voidTag"); //new
		} else {
			pyTag = PyObject_CallObject(createTag, NULL); //new
			if (PyDict_SetItemString(globals, update.pTag->name.c_str(), pyTag) == -1) {
				log(LM_ERROR, "Chyba pri vkladani tagu %s do globals", update.pTag->name.c_str());
			}
		}
	} else {
		Py_INCREF(pyTag);
	}
	//tu uz musi existovat pyTag
	PyObject *name = PyString_FromString(update.pTag->name.c_str());
	PyObject *v = PyFloat_FromDouble(update.vtq.v);
	PyObject *t = PyFloat_FromDouble(update.vtq.t);
	PyObject *q = PyInt_FromLong(update.vtq.q);

	PyObject_SetAttrString(pyTag, "name", name);
	PyObject_SetAttrString(pyTag, "v", v);
	PyObject_SetAttrString(pyTag, "t", t);
	PyObject_SetAttrString(pyTag, "q", q);
	Py_DECREF(name)
		;
	Py_DECREF(v)
		;
	Py_DECREF(t)
		;
	Py_DECREF(q)
		;

	Py_XDECREF(pyTag)
		;
}

int Code::exec(const SuhubConnectorLight::UpdateList &updateList, TagList const &outputList) {
	log(LM_TRACE, "exec updateList outputList");
#ifdef PROFILE_TIMER
	std::string timerName("Code::exec_input_output");
	ProfileTimer t(timerName);
#endif

	log(LM_DEBUG, "Executing code: %s", code.c_str());
	if (codeObject != NULL) {
		if (ob->obType & SYMBOL) {
			currentSymbol = thisSymbolAdapt;
		} else if (ob->obType & WINDOW) {
			currentWindow = thisWindowAdapt;
		} else if (ob->obType & HMI) {
			currentHmi = thisHmiAdapt;
		} else {
			log(LM_DEBUG, "neznamy typ objektu");
		}

		SuhubConnectorLight::DataWriter dw(con);

		if (suhmiCppModule == NULL) {
			log(LM_ERROR, "suhmiCppModule == NULL");
			return -1;
		}

		if (codeObject != NULL) {
			for (SuhubConnectorLight::UpdateList::const_iterator update = updateList.begin(); update != updateList.end(); ++update) {
				updateTags(*update);
			}

			PyObject *eval = PyEval_EvalCode((PyCodeObject *) codeObject, globals, NULL); //Bug 610
			Py_XDECREF(eval)
				;
			if (PyErr_Occurred()) {
				PyObject *key, *value;
				Py_ssize_t pos = 0;
				while (PyDict_Next(globals, &pos, &key, &value)) {
					log(LM_ERROR, "%s", PyString_AsString(key));
				}

				log(LM_ERROR, "Error in evaluating code: %s", code.c_str());
				log(LM_ERROR, getErrorDesc().c_str());
				PyErr_Clear();
			} else {
				log(LM_DEBUG, "output Tagy: ");
				for (TagList::StatefulTagVector::const_iterator it = outputList.tags.begin(); it != outputList.tags.end(); ++it) {
					log(LM_DEBUG, "%s", (*it)->name.c_str());
					PyObject *tag = PyDict_GetItemString(globals, (*it)->name.c_str()); //Borrowed
					if (tag == NULL) {
						log(LM_ERROR, "Error in getting tag %s from globals", (*it)->name.c_str());
						return -1;
					}
					PyObject *tag_v = PyObject_GetAttrString(tag, "v"); //New
					PyObject *tag_t = PyObject_GetAttrString(tag, "t"); //New
					PyObject *tag_q = PyObject_GetAttrString(tag, "q"); //New
					if (tag_v && tag_t && tag_q) {
						double v, t;
						uint8_t q;
						v = PyFloat_AsDouble(tag_v);
						t = PyFloat_AsDouble(tag_t);
						q = PyInt_AsLong(tag_q);

						Py_DECREF(tag_v)
							;
						Py_DECREF(tag_t)
							;
						Py_DECREF(tag_q)
							;
						SuhubConnectorLight::VTQ vtq;
						vtq.v = v;
						vtq.t = t;
						vtq.q = q;
						log(LM_DEBUG, "Writing tag %s, V: %f, T: %f, Q: %d", (*it)->name.c_str(), v, t, q);
						dw.updateByPointer(*it, vtq);
					} else {
						log(LM_WARNING, "Tag writing error: %s. Tag is missing one of parameters v, t, q.", (*it)->name.c_str());
						log(LM_WARNING, "%s", code.c_str());
					}
				}
			}
			return 0;
		} else {
			log(LM_ERROR, "CodeObject neexistuje");
			return -1;
		}
	} else {
		log(LM_WARNING, "Kod nebol skompilovany.");
		log(LM_WARNING, "%s", code.c_str());
	}
	return 0;
}

int Code::exec(TagList const &inputList, TagList const &outputList, std::string &newText) {
	log(LM_TRACE, "exec string: %s", newText.c_str());
#ifdef PROFILE_TIMER
	std::string timerName("Code::exec_input_output");
	ProfileTimer t(timerName);
#endif
	log(LM_DEBUG, "Executing: %s", code.c_str());
	if (codeObject != NULL) {
		if (ob->obType & SYMBOL) {
			currentSymbol = thisSymbolAdapt;
		} else if (ob->obType & WINDOW) {
			currentWindow = thisWindowAdapt;
		} else if (ob->obType & HMI) {
			currentHmi = thisHmiAdapt;
		} else {
			log(LM_WARNING, "unknown object type: %X", ob->obType);
		}

		SuhubConnectorLight::DataWriter dw(con);

		if (suhmiCppModule == NULL) {
			log(LM_ERROR, "suhmiCppModule == NULL");
			return -1;
		}

		PyObject* pyNewText = PyString_FromString(newText.c_str());
		if (PyDict_SetItemString(globals, newTextName, pyNewText) == -1) {
			log(LM_ERROR, "CODE: newText");
			log(LM_ERROR, "%s", getErrorDesc().c_str());
		}
		Py_DECREF(pyNewText)
			;

		if (codeObject != NULL) {
			for (TagList::StatefulTagVector::const_iterator it = inputList.tags.begin(); it != inputList.tags.end(); ++it) {
				updateTags(*it);
			}
			PyObject *eval = PyEval_EvalCode((PyCodeObject *) codeObject, globals, NULL); //Bug 610
			Py_XDECREF(eval)
				;
			if (PyErr_Occurred()) {
				log(LM_ERROR, "%s",getErrorDesc().c_str());
			} else {
				for (TagList::StatefulTagVector::const_iterator it = outputList.tags.begin(); it != outputList.tags.end(); ++it) {
					PyObject *tag = PyDict_GetItemString(globals, (*it)->name.c_str()); //Borrowed
					PyObject *tag_v = PyObject_GetAttrString(tag, "v"); //New
					PyObject *tag_t = PyObject_GetAttrString(tag, "t"); //New
					PyObject *tag_q = PyObject_GetAttrString(tag, "q"); //New
					if (tag_v && tag_t && tag_q) {
						double v, t;
						uint8_t q;
						v = PyFloat_AsDouble(tag_v);
						t = PyFloat_AsDouble(tag_t);
						q = PyInt_AsLong(tag_q);

						Py_DECREF(tag_v)
							;
						Py_DECREF(tag_t)
							;
						Py_DECREF(tag_q)
							;
						SuhubConnectorLight::VTQ vtq;
						vtq.v = v;
						vtq.t = t;
						vtq.q = q;
						log(LM_DEBUG, "Writing tag %s, V: %f, T: %f, Q: %d", (*it)->name.c_str(), v, t, q);
						dw.updateByPointer(*it, vtq);
					} else {
						log(LM_WARNING, "Tag writing error: %s. Tag is missing one of parameters v, t, q.", (*it)->name.c_str());
						log(LM_WARNING, "%s", code.c_str());
					}
				}
			}
			return 0;
		} else {
			log(LM_ERROR, "CodeObject neexistuje");
			return -1;
		}
	} else {
		log(LM_WARNING, "Kod nebol skompilovany.");
		log(LM_WARNING, "%s", code.c_str());
	}
	return 0;
}

int Code::exec(TagList const &inputList, TagList const &outputList) {
	log(LM_TRACE, "exec inputList outputList");
#ifdef PROFILE_TIMER
	std::string timerName("Code::exec_input_output");
	ProfileTimer t(timerName);
#endif

	log(LM_DEBUG, "Executing: %s", code.c_str());
	if (codeObject != NULL) {
		if (ob->obType & SYMBOL) {
			currentSymbol = thisSymbolAdapt;
		} else if (ob->obType & WINDOW) {
			currentWindow = thisWindowAdapt;
		} else if (ob->obType & HMI) {
			currentHmi = thisHmiAdapt;
		} else {
			log(LM_WARNING, "unknown object type %X", ob->obType);
		}

		if (suhmiCppModule == NULL) {
			log(LM_ERROR, "suhmiCppModule == NULL");
			return -1;
		}

		if (codeObject != NULL) {
			for (TagList::StatefulTagVector::const_iterator it = inputList.tags.begin(); it != inputList.tags.end(); ++it) {
				updateTags(*it);
			}

			PyObject *eval = PyEval_EvalCode((PyCodeObject *) codeObject, globals, NULL); //Bug 610
			Py_XDECREF(eval)
				;
			if (PyErr_Occurred()) {
				log(LM_ERROR, "Error in evaluating code: %s", code.c_str());
				log(LM_ERROR, "%s", getErrorDesc().c_str());
				PyErr_Clear();
			} else {
				SuhubConnectorLight::DataWriter dw(con);
				for (TagList::StatefulTagVector::const_iterator it = outputList.tags.begin(); it != outputList.tags.end(); ++it) {
					log(LM_DEBUG, "output Tag: %s", (*it)->name.c_str());
					PyObject *tag = PyDict_GetItemString(globals, (*it)->name.c_str()); //Borrowed
					PyObject *tag_v = PyObject_GetAttrString(tag, "v"); //New
					PyObject *tag_t = PyObject_GetAttrString(tag, "t"); //New
					PyObject *tag_q = PyObject_GetAttrString(tag, "q"); //New
					if (tag_v && tag_t && tag_q) {
						double v, t;
						uint8_t q;
						v = PyFloat_AsDouble(tag_v);
						t = PyFloat_AsDouble(tag_t);
						q = PyInt_AsLong(tag_q);

						Py_DECREF(tag_v)
							;
						Py_DECREF(tag_t)
							;
						Py_DECREF(tag_q)
							;
						SuhubConnectorLight::VTQ vtq;
						vtq.v = v;
						vtq.t = t;
						vtq.q = q;
						log(LM_DEBUG, "Writing tag %s, V: %f, T: %f, Q: %d", (*it)->name.c_str(), v, t, q);
						dw.updateByPointer(*it, vtq);
					} else {
						log(LM_WARNING, "Tag writing error: %s. Tag is missing one of parameters v, t, q.", (*it)->name.c_str());
						log(LM_WARNING, "%s", code.c_str());
					}
				}
			}
			return 0;
		} else {
			log(LM_ERROR, "CodeObject neexistuje");
			return -1;
		}
	} else {
		log(LM_WARNING, "Kod nebol skompilovany.");
		log(LM_WARNING, "%s", code.c_str());
	}
	return 0;
}

/**
 * Nahradi mena tagov v kode podla tabulky replacementTable.
 * Kluce v replacementTable su uvedene s ?.
 */
void Code::replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable, TagList::StatefulTagVector* inputList, TagList::StatefulTagVector* sensitivityList, TagList::StatefulTagVector* outputList) {
	log(LM_DEBUG,"Before replacement: %s", code.c_str());
	std::string replacements;

	addReplacement(replacements, replacementTable, inputList);
	addReplacement(replacements, replacementTable, sensitivityList);
	if (outputList)
		addReplacement(replacements, replacementTable, outputList);

	code = replacements + code;
	log(LM_DEBUG,"After replacement: %s", code.c_str());
}

/**
 * Prida do stringu replacements par original = nahrada ak sa orginal nachadza v tagListe. V nazve originalneho tagu nahradi ? za _.
 */
void Code::addReplacement(std::string &replacements, std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable, TagList::StatefulTagVector* tagList) {
	for (TagList::StatefulTagVector::iterator it = tagList->begin(); it != tagList->end(); ++it) {
		std::map<std::string, SuhubConnectorLight::StatefulTag *>::iterator replacementIt;
		replacementIt = replacementTable.find((*it)->name);
		if (replacementIt != replacementTable.end()) {
			std::string first = (*replacementIt).first;
			replacements += first.replace(0, 1, "_");
			replacements += " = ";
			replacements += (*replacementIt).second->name;
			replacements += "\n";
			addTag((*replacementIt).second);
		}
	}
}

/**
 * Tuto funckiu vola SymbolAdapt.
 */
void Code::setSymbolSelf(SymbolAdapt* self) {
	thisSymbolAdapt = self;
}

void Code::setWindowSelf(WindowAdapt* self) {
	thisWindowAdapt = self;
}

void Code::setHmiSelf(HmiAdapt* self) {
	thisHmiAdapt = self;
}

/**
 * Vrati popis chyby vratane tracebacku.
 */
std::string Code::getErrorDesc() {
	std::string errorDesc;
	//TODO(vlado): invalid read of size 1, strlen()
	//errorDesc.append(code);
	PyObject *ptype;
	PyObject *pvalue;
	PyObject *ptraceback;
	PyObject *pName, *pModule, *pDict, *pFunc, *pArgs, *pValue, *temp;
	PyErr_Fetch(&ptype, &pvalue, &ptraceback);
	errorDesc.append("DebugInfo: " + getPathString() + "\n");
	errorDesc.append("Type: ");
	errorDesc.append(PyString_AsString(PyObject_Str(ptype)));
	char* value = PyString_AsString(pvalue);
	if (value) {
		errorDesc.append("\nValue: ");
		errorDesc.append(value);
	}

	pName = PyString_FromString("traceback");
	pModule = PyImport_Import(pName);
	Py_DECREF(pName)
		;

	temp = PyObject_Str(ptype);
	if (temp != NULL) {
		errorDesc += PyString_AsString(temp);
		errorDesc += "\n";
	}
	temp = PyObject_Str(pvalue);
	if (temp != NULL) {
		errorDesc += PyString_AsString(temp);
	}
	Py_DECREF(temp)
		;
	errorDesc += "\n";

	if (ptraceback != NULL && pModule != NULL) {
		pDict = PyModule_GetDict(pModule);
		pFunc = PyDict_GetItemString(pDict, "format_tb");
		if (pFunc && PyCallable_Check(pFunc)) {
			pArgs = PyTuple_New(1);
			pArgs = PyTuple_New(1);
			Py_INCREF(ptraceback);
			PyTuple_SetItem(pArgs, 0, ptraceback); // This function “steals” a reference.
			pValue = PyObject_CallObject(pFunc, pArgs);
			if (pValue != NULL) {
				int len = PyList_Size(pValue);
				if (len > 0) {
					PyObject *t, *tt;
					int i;
					char *buffer;
					for (i = 0; i < len; i++) {
						tt = PyList_GetItem(pValue, i);
						t = Py_BuildValue("(O)", tt);
						if (!PyArg_ParseTuple(t, "s", &buffer)) {
							return "";
						}
						errorDesc += buffer;
						errorDesc += "\n";
					}
				}
			}
			Py_DECREF(pValue)
				;
			Py_DECREF(pArgs)
				;
		}
	}
	Py_DECREF(pModule)
		;

	PyErr_Restore(ptype, pvalue, ptraceback);
	PyErr_Print();
	return errorDesc;
}

void Code::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	Traceable::setDebugInfo(debugInfo, parentId);
}
