/*
 * pens_area.cpp
 *
 *  Created on: Aug 17, 2011
 *      Author: vlado
 */

#include "suhmicpp/graph/pens_area.h"
#include "suhmicpp/util/util.h"

#define thickWidth 2

PensArea::PensArea(const QXmlAttributes &attributes, QGraphicsItem *parent) :
	QGraphicsItem(parent), subGrids(1) {
	std::string gridColorStr = attributes.value("graphFgColor").toStdString();
	gridColor.setNamedColor(Util::colorNameToCode(gridColorStr).c_str());

	std::string bgColorStr = attributes.value("graphBgColor").toStdString();
	bgColor.setNamedColor(Util::colorNameToCode(bgColorStr).c_str());
	this->horizontalLineCount = horizontalLineCount;
	this->verticalLineCount = verticalLineCount;
	graphBgStyle = Util::stringToBgStyle(attributes.value("graphBgStyle").toStdString());

	brush.setColor(bgColor);
	brush.setStyle(graphBgStyle);
}

PensArea::PensArea(const PensArea &pa) :
	size(pa.size), position(pa.position), gridColor(pa.gridColor), bgColor(pa.bgColor), subGrids(pa.subGrids) {

}

QRectF PensArea::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void PensArea::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
	QPen normal;
	normal.setColor(gridColor);
	QPen thick;
	thick.setWidth(thickWidth);
	thick.setColor(gridColor);

	painter->setPen(gridColor);
	painter->setBrush(brush);
	painter->drawRect(boundingRect());

	float YLineOffset = (float)size.height() / (subGrids * horizontalLineCount); //horizontal grid
	// kresli sa z hora na dol, 0-ta ciara je vrchna
	for (uint32_t i = 1; i < subGrids * horizontalLineCount; i++) { //1 lebo vrchna ciara nema byt hruba
		if (i % horizontalLineCount == 0) {
			painter->setPen(thick);
			painter->drawLine(0, i * YLineOffset, size.width(), i * YLineOffset);
			painter->setPen(normal);
		} else {
			painter->drawLine(0, i * YLineOffset, size.width(), i * YLineOffset);
		}
	}

	float XLineOffset = (float)size.width() / verticalLineCount; //vertical grid
	for (uint32_t i = 0; i < verticalLineCount; i++) {
		painter->drawLine(i * XLineOffset, 0, i * XLineOffset, size.height());
	}

	painter->setPen(thick);
	//spodna hruba ciara
	painter->drawLine(0, size.height(), size.width() - thick.width()/2, size.height());

	//lava hruba ciara
	painter->drawLine(0, thick.width()/2, 0, size.height());
}

void PensArea::setSize(int width, int height) {
	size.setWidth(width);
	size.setHeight(height);
}

void PensArea::setSubGridsNumber(uint32_t subGrids) {
	this->subGrids = subGrids;
}

void PensArea::setHorSize(long width) {
	size.setWidth(width);
	prepareGeometryChange();
}

void PensArea::setVertSize(long height) {
	size.setHeight(height);
	prepareGeometryChange();
}

uint32_t PensArea::getVerticalLineCount() const {
	return verticalLineCount;
}

void PensArea::setHorizontalLineCount(uint32_t horizontalLineCount) {
	this->horizontalLineCount = horizontalLineCount;
}

void PensArea::setVerticalLineCount(uint32_t verticalLineCount) {
	this->verticalLineCount = verticalLineCount;
}

