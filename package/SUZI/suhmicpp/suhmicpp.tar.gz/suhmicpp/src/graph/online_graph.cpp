/*
 * online_graph.cpp
 *
 *  Created on: Jun 7, 2011
 *      Author: vlado
 */

#include <iostream>
#include "suhmicpp/graph/online_graph.h"
#include <algorithm>
#include <QFontMetrics>
#include <QFont>
#include <QDateTime>
#include <limits>
#include "suhmicpp/util/util.h"

#define	axisYOffsetL 5
#define	axisYOffsetR 30
#define refreshTime 1000 //ms
#define YLabelFormat "%#.4g"
#define dateTimeFormat "d/M/yy\nhh:mm:ss A"
#define minGraphWidth 300
#define minGraphHeight 300
#define commonTagNameOffset 20

//                    --------------- penarea
// | timeAxisOversize |              | timeAxisOversize |
// ------------------------------------------------------  timeAxis
#define timeAxisOversize 100

OnlineGraph::OnlineGraph(const QXmlAttributes &attributes, const ArcherConfiguration &archerConfiguration) :
	SimpleVisualSymbol(attributes), tagNameWidth(0), maxPenNameWidth(10), maxPenRangeWidth(10), normal("Sans Serif", 10), pensArea(attributes, this), labelHeight(0),
			archerConfiguration(archerConfiguration) {
	setFlags(flags() | QGraphicsItem::ItemClipsToShape | QGraphicsItem::ItemClipsChildrenToShape);
	title = attributes.value("title");

	std::string titleColorStr = attributes.value("titleColor").toStdString();
	titleColor.setNamedColor(Util::colorNameToCode(titleColorStr).c_str());

	pen.setWidth(lineWidth);
	refreshTimer.setInterval(refreshTime);
	refreshTimer.start();
	connect(&refreshTimer, SIGNAL(timeout()), this, SLOT(onRefreshTimer()));

	horizontalLineCount = attributes.value("horizontalLineCount").toInt() + 1;
	verticalLineCount = attributes.value("verticalLineCount").toInt() + 1;
	pensArea.setHorizontalLineCount(horizontalLineCount);
	pensArea.setVerticalLineCount(verticalLineCount);
	timeAxis.setVerticalLineCount(verticalLineCount);

	std::string axisLabelsColorStr = attributes.value("axisLabelsColor").toStdString();
	axisLabelsColor.setNamedColor(Util::colorNameToCode(axisLabelsColorStr).c_str());
	timeAxis.setLabelsColor(axisLabelsColorStr);
}

OnlineGraph::OnlineGraph(const OnlineGraph &graph) :
	SimpleVisualSymbol(graph), title(graph.title), timeAxis(graph.timeAxis), valueAxis(graph.valueAxis), pens(graph.pens), tagNameWidth(graph.tagNameWidth), pensArea(graph.pensArea),
			archerConfiguration(graph.archerConfiguration) {
	setFlags(flags() | QGraphicsItem::ItemClipsToShape | QGraphicsItem::ItemClipsChildrenToShape);
}

QRectF OnlineGraph::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

OnlineGraph::~OnlineGraph() {
	for(PenVector::iterator pen = pens.begin(); pen != pens.end(); ++pen){
		delete *pen;
	}
}

void OnlineGraph::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
	painter->save();

	QPainterPath outline;
	outline.addRect(0, 0, size.width(), size.height());

	QPainterPath pensAreaPath;
	pensAreaPath.addRect(pensArea.pos().x(), pensArea.pos().y(), pensArea.size.width(), pensArea.size.height());
	painter->setClipPath(outline - pensAreaPath);

	//Pozadie grafu
	if (bgBlinkState == true) {
		brush.setColor(bgColor);
	} else {
		brush.setColor(linkList.bgBlinkLink.blinkColor);
	}
	painter->setBrush(brush);

	if (fgBlinkState == true) {
		pen.setColor(fgColor);
	} else {
		pen.setColor(linkList.fgBlinkLink.blinkColor);
	}
	painter->setPen(pen);
	painter->drawRect(lineWidth / 2, lineWidth / 2, size.width() - lineWidth, size.height() - lineWidth);

	//Titulok
	painter->setPen(titleColor);
	painter->setFont(titleFont.getQFont());
	painter->drawText(QRectF(0, lineWidth, size.width(), size.height()), Qt::AlignHCenter, title);

	painter->setFont(labelFont.getQFont());
	painter->setPen(QPen());
	// COMMON
	if (valueAxis.rangeMode == OnlineGraphValueAxis::common) {
		uint32_t penAreaHeight = getPenAreaSize(timeLabelSize.height()).height();
		uint32_t penAreaY = getPenAreaPos().y();

		int i = 0;
		int min = 0;
		int max = 100;
		for (PenVector::iterator pen = pens.begin(); pen != pens.end(); ++pen) {
			//mena tagov
			painter->setPen((*pen)->getColor().c_str());
			painter->drawText(QRectF(lineWidth + axisYOffsetL, i * labelHeight + penAreaY + commonTagNameOffset, maxPenNameWidth, labelHeight), QString((*pen)->tag->name.c_str()));
			i++;
		}
		// hodnoty

		painter->setPen(axisLabelsColor);
		float label = 0;
		float actualHeight = 0.0;
		QFontMetrics fm(labelFont.getQFont());
		int textHeight = fm.height();

		for (int j = 0; j <= horizontalLineCount; j++) {
			int labelY = penAreaY + j * ((size.height() - 2 * lineWidth - titleHight - timeLabelSize.height()) / (float)horizontalLineCount);
			char buff[21];
			sprintf(buff, "%.2f", (float) max - (j * ((max - min) / (float) horizontalLineCount)));
			int textWidth = fm.width(QString(buff));
			if (j == 0) { // 100 %
				painter->drawText(lineWidth + maxPenNameWidth + 2 * axisYOffsetL, labelY, textWidth, textHeight, Qt::AlignRight, QString(buff));
				actualHeight = labelY + textHeight;
			} else if (j == horizontalLineCount) { // 0 %
				painter->drawText(lineWidth + maxPenNameWidth + 2 * axisYOffsetL, labelY - textHeight, textWidth, textHeight, Qt::AlignRight, QString(buff));
			} else if(labelY - labelHeight / 2.0 > actualHeight && labelY + labelHeight / 2.0 < penAreaY + penAreaHeight - textHeight) {
				painter->drawText(lineWidth + maxPenNameWidth + 2 * axisYOffsetL, labelY - textHeight / 2.0, textWidth, textHeight, Qt::AlignRight, QString(buff));
				actualHeight = labelY + textHeight / 2.0;
			}
		}
	}
	//STACKED
	else {
		uint32_t penAreaHeight;
		if (pens.size() == 0) {
			penAreaHeight = size.height() - 2 * lineWidth - titleHight - timeLabelSize.height();
		} else {
			pensArea.setSubGridsNumber(pens.size());
			penAreaHeight = (size.height() - 2 * lineWidth - titleHight - timeLabelSize.height()) / pens.size();
		}
		uint16_t penAreaY = getPenAreaPos().y();
		uint16_t penAreax = getPenAreaPos().x();

		float actualHeight = 0.0;
		int i = 0;
		for (PenVector::iterator pen = pens.begin(); pen != pens.end(); ++pen) {
			painter->setPen(QPen(QColor((*pen)->getColor().c_str())));

			double min = (*pen)->absMin;
			double max = (*pen)->absMax;
			QFontMetrics fm(labelFont.getQFont());
			for (int j = 0; j <= horizontalLineCount; j++) {
				int labelY = penAreaY + (i * penAreaHeight) + j * (penAreaHeight / (double) horizontalLineCount);
				char buff[21];
				sprintf(buff, YLabelFormat, max - (j * ((max - min) / (double) horizontalLineCount)));
				int textWidth = fm.width(QString(buff));
				int textHeight = fm.height();

				if (j == 0) { //vrchny label
					painter->drawText(lineWidth + maxPenNameWidth + 2 * axisYOffsetL, labelY, maxPenRangeWidth, textHeight, Qt::AlignRight, QString(buff));
					actualHeight = labelY + textHeight;
				} else if (j == horizontalLineCount) { //spodny label
					painter->drawText(lineWidth + maxPenNameWidth + 2 * axisYOffsetL, labelY - textHeight, maxPenRangeWidth, textHeight, Qt::AlignRight, QString(buff));
				} else if (labelY - labelHeight / 2.0 > actualHeight && labelY + labelHeight / 2.0 < lineWidth + titleHight + (i + 1) * penAreaHeight - textHeight) { // && moja spodna hranica je vyssie ako vrch najspodnejsieho labelu
					painter->drawText(lineWidth + maxPenNameWidth + 2 * axisYOffsetL, labelY - textHeight / 2.0, maxPenRangeWidth, textHeight, Qt::AlignRight, QString(buff));
					actualHeight = labelY + textHeight / 2.0;
				}
			}

			//mena tagov
			painter->setPen((*pen)->getColor().c_str());
			painter->drawText(QRectF(lineWidth + axisYOffsetL, i * penAreaHeight + (lineWidth + titleHight) + penAreaHeight / 2, fm.width((*pen)->tag->name.c_str()), fm.height()), QString((*pen)->tag->name.c_str()));
			i++;
		}
	}
	painter->restore();
}

Symbol* OnlineGraph::clone() {
	OnlineGraph *graph = new OnlineGraph(*this);
	return static_cast<VisualSymbol*> (graph);
}

void OnlineGraph::fini() {
	SimpleVisualSymbol::fini();
	QFontMetrics fm(labelFont.getQFont());
	if (pens.size() > 0) {

		PenVector::iterator pen = std::max_element(pens.begin(), pens.end(), compPenByNameLenght());
		maxPenNameWidth = fm.width((*pen)->tag->name.c_str());

		if (valueAxis.rangeMode == OnlineGraphValueAxis::common) {
			maxPenRangeWidth = fm.width("100 %") + 5;
		} else {
			char buff[20];
			float widest = std::numeric_limits<int>::max();
			//sprintf(buff, YLabelFormat, );
			sprintf(buff, YLabelFormat, widest);
			maxPenRangeWidth = fm.width(QString(buff));
		}
	}
	/*
	 * else - pouzije sa defaulna hodnota maxPenNameWidth
	 */

	timeLabelSize.setHeight(2 * fm.height());
	timeLabelSize.setWidth(fm.width(QString("00/00/00\n00:00:00 AM")));
	QPoint penAreaPos = getPenAreaPos();
	QSize penAreaSize = getPenAreaSize(timeLabelSize.height());

	timeAxis.setParentItem(this);
	pensArea.setPos(penAreaPos.x(), penAreaPos.y());

	updateGeometry();

	if (valueAxis.rangeMode == OnlineGraphValueAxis::common) {
		for (PenVector::iterator it = pens.begin(); it != pens.end(); ++it) {
			(*it)->setRangeTypeIsCommon(true);
			(*it)->setSize(penAreaSize.width(), penAreaSize.height());
			(*it)->setPos(penAreaPos.x(), penAreaPos.y());
			(*it)->setParentItem(this);
		}
	} else { //stacked
		int i = 0;
		for (PenVector::iterator it = pens.begin(); it != pens.end(); ++it) {
			(*it)->setRangeTypeIsCommon(false);
			(*it)->setSize(penAreaSize.width(), penAreaSize.height() / pens.size());
			(*it)->setPos(penAreaPos.x(), penAreaPos.y() + ((penAreaSize.height() / pens.size()) * i));
			(*it)->setParentItem(this);
			i++;
		}
	}
	/*for (PenVector::iterator it = pens.begin(); it != pens.end(); ++it) {
		graphLoader.getData(timeAxis.getTStart() / 1000, QString((*it)->tag->name.c_str()));
		OnlineGraphPen::ValuesMap values;
		graphLoader.getData(values, timeAxis.getTStart() / 1000, QString((*it)->tag->name.c_str()));
		(*it)->addValues(values);
	}*/

}

/**
 * Po vyprsani timera, nastavi casovej osi nove hranice.
 */
void OnlineGraph::onRefreshTimer() {
	uint64_t now = QDateTime::currentMSecsSinceEpoch();
	uint64_t startTime = now - timeAxis.getTStart();
	uint64_t endTime = now - timeAxis.getTEnd();
	timeAxis.setTimeRange(startTime, endTime);
	for (PenVector::iterator it = pens.begin(); it != pens.end(); ++it) {
		(*it)->setTimeRange(startTime, endTime);
	}
}

/**
 * Nastavi atributy fontu titulku.
 */
void OnlineGraph::setFontAttributes(const QXmlAttributes &attributes) {
	titleFont.size = attributes.value("size").toInt();
	titleFont.setName(attributes.value("name").toStdString());
	titleFont.setStyle(attributes.value("style").toStdString());
	QFontMetrics fm(titleFont.getQFont());
	titleHight = fm.height();
}

/**
 * Nastavi atributy fontu oznaceni.
 */
void OnlineGraph::setLabelFontAttributes(const QXmlAttributes &attributes) {
	labelFont.size = attributes.value("size").toInt();
	labelFont.setName(attributes.value("name").toStdString());
	labelFont.setStyle(attributes.value("style").toStdString());
	timeAxis.setFont(&labelFont);
	QFontMetrics fm(labelFont.getQFont());
	labelHeight = fm.height();
}

/**
 * Nastavi sirku grafu, najmenej minGraphWidth.
 */
void OnlineGraph::setHorSize(long value) {
	if (value < minGraphWidth)
		value = minGraphWidth;
	VisualSymbol::setHorSize(value);
	setSize(value, size.height());
}

/**
 * Nastavi vysku grafu, najmenej minGraphHeight.
 */
void OnlineGraph::setVertSize(long value) {
	if (value < minGraphHeight)
		value = minGraphHeight;
	VisualSymbol::setVertSize(value);
	setSize(size.width(), value);
}

void OnlineGraph::setSize(int width, int height) {
	if (height < minGraphHeight)
		height = minGraphHeight;
	if (width < minGraphWidth)
		width = minGraphWidth;

	size.setWidth(width);
	size.setHeight(height);
	updateGeometry();
}

/**
 * Prepocita pozicie a sirky potomkov.
 */
void OnlineGraph::updateGeometry() {

	QPoint penAreaPos = getPenAreaPos();
	QSize penAreaSize = getPenAreaSize(timeLabelSize.height());

	pensArea.setSize(penAreaSize.width(), penAreaSize.height());

	timeAxis.setTimeAxisOversize(timeAxisOversize);
	timeAxis.setPos(penAreaPos.x() - timeAxisOversize, size.height() - lineWidth - timeLabelSize.height());
	timeAxis.setWidth(penAreaSize.width() + 2 * timeAxisOversize);
	timeAxis.setHeight(size.height() - penAreaSize.height() - titleFont.size - lineWidth);

	int i = 0;
	for (PenVector::iterator it = pens.begin(); it != pens.end(); ++it) {
		if (valueAxis.rangeMode == OnlineGraphValueAxis::common) {
			(*it)->setSize(penAreaSize.width(), penAreaSize.height());
			(*it)->setPos(penAreaPos.x(), penAreaPos.y());
		} else {
			(*it)->setSize(penAreaSize.width(), penAreaSize.height() / pens.size());
			(*it)->setPos(penAreaPos.x(), penAreaPos.y() + ((penAreaSize.height() / pens.size()) * i));
		}
		i++;
	}
}

/**
 * Vrati poziciu oblasti, do ktorej sa vykresluju pera.
 */
QPoint OnlineGraph::getPenAreaPos() {
	int penAreaPosX = lineWidth + axisYOffsetL + maxPenNameWidth + axisYOffsetL + maxPenRangeWidth + axisYOffsetL;
	int penAreaPosY = lineWidth + titleHight;

	return QPoint(penAreaPosX, penAreaPosY);
}

/**
 * Vrati velkost oblasti, do ktorej sa vykresluju pera.
 */
QSize OnlineGraph::getPenAreaSize(int timeLabelHeight) {
	int penAreaWidth = size.width() - lineWidth - axisYOffsetL - maxPenNameWidth - axisYOffsetL - maxPenRangeWidth - axisYOffsetR - lineWidth;
	int penAreaHeight = size.height() - titleHight - timeLabelHeight - 2 * lineWidth;
	return QSize(penAreaWidth, penAreaHeight);
}

uint32_t OnlineGraph::getHorizontalLineCount() {
	return horizontalLineCount;
}
uint32_t OnlineGraph::getVerticalLineCount() {
	return verticalLineCount;
}
