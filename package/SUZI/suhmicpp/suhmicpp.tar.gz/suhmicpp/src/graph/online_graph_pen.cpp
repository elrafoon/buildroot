/*
 * online_graph_pen.cpp
 *
 *  Created on: Jun 13, 2011
 *      Author: vlado
 */

#include <iostream>
#include <QPainter>
#include "suhmicpp/graph/online_graph_pen.h"
#include "suhmicpp/util/util.h"
#include "suhmicpp/util/profile_timer.h"
#include <algorithm>

void DataType::setType(const std::string &type) {
	if (type == "I")
		this->type = INTEGER;
	else if (type == "D")
		this->type = DISCRETE;
	else
		this->type = ANALOG;
}

OnlineGraphPenRangeManual::OnlineGraphPenRangeManual(const QXmlAttributes &attributes) {
	minimum = attributes.value("minimum").toFloat();
	maximum = attributes.value("maximum").toFloat();
}

OnlineGraphPenRangeAuto::OnlineGraphPenRangeAuto(const QXmlAttributes &attributes) {
	reserve = attributes.value("reserve").toFloat();
}

OnlineGraphPenRangeTight::OnlineGraphPenRangeTight(const QXmlAttributes &attributes) {
	minRange = attributes.value(QString("minRange")).toFloat();
}

OnlineGraphPen::OnlineGraphPen(const QXmlAttributes &attributes, SuhubConnectorLight::StatefulTag *tag, uint64_t tStart, const ArcherConfiguration &archerConfiguration) :
		tag(tag), rangeType(manual), range(NULL), color("#000000"), width(0), style(Qt::SolidLine), isCommon(false), SuhubConnectorLight::UpdateListener(), startTime(0), endTime(0), minEU(0), maxEU(0), absMin(0), absMax(0), archerConnector(archerConfiguration), graphLoader(&archerConnector) {
	color = attributes.value(QString("color")).toStdString();
	width = attributes.value(QString("width")).toInt();
	style = Util::stringToFgStyle(attributes.value(QString("style")).toStdString());
	minEU = attributes.value("minEU").toDouble();
	maxEU = attributes.value("maxEU").toDouble();
	dataType.setType(attributes.value("datatype").toStdString());

	qRegisterMetaType<GraphLoader::ValueMap>("ValueMap&");
	QObject::connect(&graphLoader, SIGNAL(sigDataAcquired(ValueMap&)), (QObject*) this, SLOT(dataAcquired(ValueMap&)), Qt::QueuedConnection);

	graphLoader.getData(tStart / 1000, QString(tag->name.c_str()));
}

OnlineGraphPen::OnlineGraphPen(const OnlineGraphPen &onlinePen) :
		isCommon(false), archerConnector(onlinePen.archerConnector), graphLoader(&archerConnector) {
}

void OnlineGraphPen::loadDataFromArchive() {

}

OnlineGraphPen::~OnlineGraphPen() {
	delete range;
}

/**
 * Copies tag values from updateList to values map and updates self.
 */
void OnlineGraphPen::onUpdate(const SuhubConnectorLight::UpdateList &updateList) {
	for (SuhubConnectorLight::UpdateList::const_iterator it = updateList.begin(); it != updateList.end(); ++it) {
		values[(*it).vtq.t] = (*it).vtq.v;
	}
	update();
	parentItem()->update();
}

QRectF OnlineGraphPen::boundingRect() const {
	return QRectF(0, 0, size.width(), size.height());
}

void OnlineGraphPen::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
	painter->save();
	//painter->setClipRect(boundingRect(), Qt::ReplaceClip);

	QColor penColor;
	penColor.setNamedColor(color.c_str());
	QPen pathPen(penColor, width, style);
	painter->setPen(pathPen);
	painter->drawPath(path);
	painter->restore();

}

void OnlineGraphPen::setSize(int width, int height) {
	size.setWidth(width);
	size.setHeight(height);
}

void OnlineGraphPen::setRangeTypeIsCommon(bool isCommon) {
	this->isCommon = isCommon;
}

void OnlineGraphPen::setTimeRange(uint64_t startTime, uint64_t endTime) {
#ifdef PROFILE_TIMER
	std::string timerName("setTimeRange");
	ProfileTimer t(timerName);
#endif

	this->startTime = startTime;
	this->endTime = endTime;

	const QPainterPath emptyPath;
	path = emptyPath;

	ValuesMap::iterator lastTimeIt = values.upper_bound(endTime / 1000.0);
	ValuesMap::iterator firstTimeIt = values.lower_bound(startTime / 1000.0);

	if (firstTimeIt != values.begin()) {
		values.erase(values.begin(), --firstTimeIt);
	}
	if (isCommon) {
		absMin = minEU;
		absMax = maxEU;
	} else {
		// MANUAL
		if (rangeType == OnlineGraphPen::manual) {
			absMin = static_cast<OnlineGraphPenRangeManual *>(range)->minimum;
			absMax = static_cast<OnlineGraphPenRangeManual *>(range)->maximum;
		}
		// TIGHT
		else if (rangeType == OnlineGraphPen::tight) {
			ValuesMap::iterator it = std::min_element(values.begin(), lastTimeIt, CompareValuesByValue());
			double min = (*it).second;

			it = std::max_element(values.begin(), lastTimeIt, CompareValuesByValue());
			double max = (*it).second;

			float minRange = static_cast<OnlineGraphPenRangeTight *>(range)->minRange;
			if ((max - min) <= minRange) {
				float rangePadding = minRange - (max - min);
				min = min - rangePadding / 2.0;
				max = max + rangePadding / 2.0;
			}
			absMin = min;
			absMax = max;
		}
		// AUTO
		else {
			float reserve = static_cast<OnlineGraphPenRangeAuto *>(range)->reserve;

			absMin = minEU - reserve;
			absMax = maxEU + reserve;
		}
	}

	if (dataType.type == DataType::ANALOG) {
		int y = 0;
		for (ValuesMap::iterator it = values.begin(); it != lastTimeIt; ++it) {
			int x = (((*it).first * 1000 - startTime) / (endTime - startTime)) * size.width();
			if((*it).second != (*it).second)
				y = size.height() - (((50 - absMin) / (absMax - absMin)) * size.height());
			else
				y = size.height() - ((((*it).second - absMin) / (absMax - absMin)) * size.height());
			if (it == values.begin())
				path.moveTo(x, y);
			else {
				path.lineTo(x, y);
			}
		}
		path.lineTo(size.width(), y);
	} else { // if (dataType.type == DataType::INTEGER || dataType.type == DataType::DISCRETE)
		int y = 0;
		for (ValuesMap::iterator it = values.begin(); it != lastTimeIt; ++it) {
			int prevY = y;
			int x = (((*it).first * 1000 - startTime) / (endTime - startTime)) * size.width();
			y = size.height() - ((((*it).second - absMin) / (absMax - absMin)) * size.height());
			if (it == values.begin())
				path.moveTo(x, y);
			else {
				path.lineTo(x, prevY);
				path.lineTo(x, y);
			}
		}
		path.lineTo(size.width(), y);
	}
	update();
}

const std::string & OnlineGraphPen::getColor() {
	return color;
}

double OnlineGraphPen::getMinEU() {
	return minEU;
}

double OnlineGraphPen::getMaxEU() {
	return maxEU;
}

void OnlineGraphPen::addValues(ValuesMap &values) {
	ValuesMap valuesSeconds;
	/*for (ValuesMap::iterator it = values.begin(); it != values.end(); ++it) {
		valuesSeconds[(*it).first / 1000] = (*it).second;
	}*/
	//this->values.insert(valuesSeconds.begin(), valuesSeconds.end());
}

double OnlineGraphPen::msToSec(double msec) {
	return msec / 1000.0;
}

void OnlineGraphPen::dataAcquired(ValueMap &resultContainer) {
	addValues(resultContainer);
}
