/*
 * online_graph_value_axis.cpp
 *
 *  Created on: Jun 13, 2011
 *      Author: vlado
 */

#include "suhmicpp/graph/online_graph_value_axis.h"
#include "suhmicpp/graph/online_graph.h"

OnlineGraphValueAxis::OnlineGraphValueAxis() {
}

OnlineGraphValueAxis::OnlineGraphValueAxis(const OnlineGraphValueAxis &ogva) {
}

void OnlineGraphValueAxis::setValues(const QXmlAttributes &attributes) {
	if (attributes.value("rangeMode") == QString("stacked")) {
		rangeMode = stacked;
	} else {
		rangeMode = common;
	}
}
