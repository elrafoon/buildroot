/*
 * online_graph_time_axis.cpp
 *
 *  Created on: Jun 13, 2011
 *      Author: vlado
 */

#include <QtGlobal>
#include "suhmicpp/graph/online_graph_time_axis.h"
#include "suhmicpp/util/util.h"

#define dateTimeFormat "yyyy/MM/dd\nhh:mm:ss"

OnlineGraphTimeAxis::OnlineGraphTimeAxis() :
		normal("arial", 10), tStart(0), tEnd(0), startTime(0), endTime(0), width(0), height(0), font(NULL) {
}

OnlineGraphTimeAxis::OnlineGraphTimeAxis(const OnlineGraphTimeAxis &ogta) :
		normal(ogta.normal), tStart(ogta.tStart), tEnd(ogta.tEnd), startTime(ogta.startTime), endTime(ogta.endTime), width(ogta.width), height(ogta.height), font(ogta.font) {

}

void OnlineGraphTimeAxis::setValues(const QXmlAttributes &attributes) {
	tStart = attributes.value(QString("tStart")).toULong();
	tEnd = attributes.value(QString("tEnd")).toULong();
}

QRectF OnlineGraphTimeAxis::boundingRect() const {
	return QRectF(0, 0, width, height);
}

void OnlineGraphTimeAxis::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
	//painter->drawRect(boundingRect());
	QFontMetrics fm(font->getQFont());
	QPen thick;
	thick.setWidth(2);
	painter->setFont(normal);
	QDateTime start;
	start.setMSecsSinceEpoch(startTime);
	uint64_t timeSegment = (endTime - startTime) / verticalLineCount;

	painter->setFont(font->getQFont());
	painter->setPen(axisLabelsColor);
	QString label = start.toString(dateTimeFormat);

	float actualWidth = 0.0;
	int penAreaWidth = width - 2 * timeAxisOversize;
	for (int i = 0; i <= verticalLineCount; ++i) {
		if (i == 0) {
			painter->drawText(QRectF(i * ((penAreaWidth) / verticalLineCount) + timeAxisOversize, 0, labelSize.width(), labelSize.height()), Qt::AlignHCenter, label);
			actualWidth = labelSize.width();
		} else if (i == verticalLineCount) {
			painter->drawText(QRectF(penAreaWidth + timeAxisOversize - labelSize.width(), 0, labelSize.width(), labelSize.height()), Qt::AlignHCenter, label);
		} else {
			int x = i * ((penAreaWidth) / verticalLineCount) + timeAxisOversize;
			if (actualWidth + timeAxisOversize < x - labelSize.width() / 2 && x + labelSize.width() / 2 < (penAreaWidth + timeAxisOversize - labelSize.width())) {
				painter->drawText(QRectF(i * ((penAreaWidth) / verticalLineCount) + timeAxisOversize - labelSize.width() / 2, 0, labelSize.width(), labelSize.height()), Qt::AlignHCenter, label);
				actualWidth = x - labelSize.width() / 2;
			}
		}
		start = start.addMSecs(timeSegment);
		label = start.toString(dateTimeFormat);
	}
}

void OnlineGraphTimeAxis::setWidth(int width) {
	this->width = width;
}

int OnlineGraphTimeAxis::getHeight() const {
	return height;
}

int OnlineGraphTimeAxis::getWidth() const {
	return width;
}

void OnlineGraphTimeAxis::setHeight(int height) {
	this->height = height;
}

void OnlineGraphTimeAxis::setTimeRange(uint64_t startTime, uint64_t endTime) {
	this->startTime = startTime;
	this->endTime = endTime;
	update();
}

uint64_t OnlineGraphTimeAxis::getTStart() const {
	return tStart;
}
uint64_t OnlineGraphTimeAxis::getTEnd() const {
	return tEnd;
}

void OnlineGraphTimeAxis::setLabelsColor(std::string& color) {
	axisLabelsColor.setNamedColor(Util::colorNameToCode(color).c_str());
}

/**
 * Nastavi font a na zaklade tohto fontu, vypocita velkost jedneho labelu.
 */
void OnlineGraphTimeAxis::setFont(Font *font) {
	this->font = font;
	QFontMetrics fm(font->getQFont());
	labelSize.setHeight(2 * fm.height());
	labelSize.setWidth(fm.width(QString("0000/00/00")));
}

void OnlineGraphTimeAxis::setVerticalLineCount(uint32_t verticalLineCount) {
	this->verticalLineCount = verticalLineCount;
}

void OnlineGraphTimeAxis::setTimeAxisOversize(uint32_t timeAxisOversize) {
	this->timeAxisOversize = timeAxisOversize;
}

