/*
 * line_edit.cpp
 *
 *  Created on: Jul 12, 2011
 *      Author: vlado
 */

#include "suhmicpp/line_edit.h"

/**
 * Stlacenie klavesu Enter alebo Return vyvola editingFinished tzn. zmeny sa zapisu. Escape vyvola cancelEditing tzn. zmeny budu zrusene.
 */
void LineEdit::keyPressEvent(QKeyEvent *e) {
	if (e->key() == Qt::Key_Enter || e->key() == Qt::Key_Return) {
		emit editingFinished();
	}
	else if(e->key() == Qt::Key_Escape){
		emit cancelEditing();
	}
	QLineEdit::keyPressEvent(e);
}
