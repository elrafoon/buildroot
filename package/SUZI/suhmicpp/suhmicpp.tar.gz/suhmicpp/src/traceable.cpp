/*
 * traceable.cpp
 *
 *  Created on: Sep 7, 2011
 *      Author: vlado
 */

#include <iostream>
#include "suhmicpp/traceable.h"


Traceable::Traceable() :
	identification("") {
}
Traceable::Traceable(std::string &identification) {
	this->identification = identification;
}

Traceable::Traceable(const Traceable & traceable): debugInfo(traceable.debugInfo), identification(traceable.identification){

}

Traceable::~Traceable() {
}

void Traceable::setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId) {
	this->debugInfo = debugInfo;
	if (parentId.length() > 0) //skryjem niektore urovne napr. LinkList, GenericScriptList a pod.
		this->debugInfo.push_back(parentId);
}
std::string Traceable::getPathString() {
	std::string joined;
	for (VectorOfStrings::const_iterator it = debugInfo.begin(); it != debugInfo.end(); ++it) {
		joined += *it;
		joined += ":";
	}
	return joined;
}
