/*
 * config.cpp
 *
 *  Created on: Nov 24, 2010
 *      Author: vlado
 */

#include <libconfig.h++>
#include <iostream>
#include "suhmicpp/util/config.h"

Configuration *config;

Configuration::Configuration(char *fname) {
	libconfig::Config conf;

	try {
		conf.readFile(fname);
	}
	catch(libconfig::FileIOException &e) {
		std::cerr <<  "Can't open config file " << fname << ((std::exception &)e).what() << '\n';
		ACE_ERROR((LM_ERROR,"Can't open config file '%s': %s\n",fname,((std::exception &)e).what()));
		throw;
	}
	catch(libconfig::ParseException &e) {
		std::cerr << "Can't parse config file" << fname <<  ", line " << e.getLine() << ", error " << e.getError() << "\n";
		ACE_ERROR((LM_ERROR,"Can't parse config file '%s', line %d, error %s\n",fname,e.getLine(),e.getError()));
		throw;
	}

	try {
		basePythonDir = (const char *)conf.lookup("base_python_dir");
		ACE_ERROR((LM_INFO,"* Using basePythonDir: %s\n", basePythonDir.c_str()));
	}
	catch(libconfig::SettingNotFoundException &e) {
		std::cerr << "Configuration setting " << e.getPath() << "not found!" <<  "\n";
		ACE_ERROR((LM_ERROR,"Configuration setting '%s' not found!\n", e.getPath()));
		throw;
	}
}
