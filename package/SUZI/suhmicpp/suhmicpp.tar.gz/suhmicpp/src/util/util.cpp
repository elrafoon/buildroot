/*
 * util.cpp
 *
 *  Created on: Jul 13, 2011
 *      Author: vlado
 */

#include <algorithm>
#include <ctype.h>
#include "suhmicpp/util/util.h"

/**
 * Kontroluje ci zadany kod farby je korektny.
 * \retval true ak kod zacina znakom #, ma dlzku 7 alebo 4 a obsahuje znaky 0-f (okrem prveho)
 * \retval false ak je kod farby neplatny
 *
 */
bool Util::isColorCode(std::string &colorCode) {
	if (colorCode.at(0) == '#' && (colorCode.length() == 7 || colorCode.length() == 4)) {
		for (std::string::iterator ch = colorCode.begin() + 1; ch != colorCode.end(); ++ch) {
			if (*ch < '0' || *ch > 'f')
				return false;
		}
	} else {
		return false;
	}
	return true;
}

/**
 * K zadanemu nazvu farby vrati jej kod. Ak je nazov farby priamo kod, vrati ho.
 * V pripade neznameho mena farby vrati ciernu.Porovnanie je case insensitive, navratova hodnota je lower case.
 */
std::string Util::colorNameToCode(std::string &colorName) {
	std::transform(colorName.begin(), colorName.end(), colorName.begin(), ::tolower); //case insensitive
	if (isColorCode(colorName)) {
		return colorName;
	} else {
		if (colorName == "white")
			return "#ffffff";
		else if (colorName == "red")
			return "#ff0000";
		else if (colorName == "darkRed")
			return "#80000";
		else if (colorName == "green")
			return "#00ff00";
		else if (colorName == "darkGreen")
			return "#0080000";
		else if (colorName == "blue")
			return "#0000ff";
		else if (colorName == "darkBlue")
			return "#000080";
		else if (colorName == "cyan")
			return "#00ffff";
		else if (colorName == "darkCyan")
			return "#008080";
		else if (colorName == "magenta")
			return "#ff00ff";
		else if (colorName == "darkMagenta")
			return "#800080";
		else if (colorName == "yellow")
			return "#ffff00";
		else if (colorName == "darkYellow")
			return "#808000";
		else if (colorName == "grey")
			return "#008080";
		else if (colorName == "darkGrey")
			return "#808080";
		else if (colorName == "lightGrey")
			return "#c0c0c0";
	}
	return "#000000";
}

/**
 * Prevedie nazov stylu na Qt::PenStyle. Defaulna hodnota je SolidLine.
 */
Qt::PenStyle Util::stringToFgStyle(const std::string &fgStyle) {
	if (fgStyle == "solid")
		return Qt::SolidLine;
	else if (fgStyle == "dash")
		return Qt::DashLine;
	else if (fgStyle == "dot")
		return Qt::DotLine;
	else if (fgStyle == "dashdot")
		return Qt::DashDotLine;
	else
		return Qt::SolidLine;
}

Qt::BrushStyle Util::stringToBgStyle(const std::string &bgStyle){
	if (bgStyle == "solid")
		return Qt::SolidPattern;
	else if (bgStyle == "transparent")
		return Qt::NoBrush;
	else
		return Qt::SolidPattern;
}
