/*
 * timer.cpp
 *
 *  Created on: Jul 8, 2011
 *      Author: vlado
 */

#include "suhmicpp/util/profile_timer.h"

ProfileTimer::ProfileTimer(std::string &name) : PrefixedLogger("ProfileTimer"), name(name){
	t.start();
}

ProfileTimer::~ProfileTimer(){
	us = t.elapsed();
	log(LM_DEBUG,"%s: %d us", name.c_str(), us);
}
