/*
 * prefixed_logger.cpp
 *
 *  Created on: Sep 28, 2011
 *      Author: stano
 */

#include "suhmicpp/util/prefixed_logger.h"
#include "suhmicpp/error_indication/error_button.h"

extern ErrorButton *errorButton;

PrefixedLogger::PrefixedLogger(const std::string &prefix) :
		prefix(prefix) {

}

void PrefixedLogger::setPrefix(const std::string &prefix) {
	this->prefix = prefix;
}

void PrefixedLogger::log(ACE_Log_Priority p, const ACE_TCHAR *format, ...) {
	va_list args;
	va_start(args, format);

	std::string newFormat = std::string("%M ") + prefix + std::string(format) + "\n";

	ACE_ERROR((newFormat.c_str(), p, args));
	va_end(args);
	errorButton->setActive(p);
}

