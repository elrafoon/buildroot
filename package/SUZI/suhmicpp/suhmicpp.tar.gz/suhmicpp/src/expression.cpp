/*
 * expression.cpp
 *
 *  Created on: Sep 30, 2010
 *      Author: vlado
 */

#include <QChar>
#include "suhmicpp/expression.h"
#include "suhmicpp/bound_expression.h"
#include "suhmicpp/object_base.h"
#include "suhmicpp/adapters/symbol_adapt.h"
#include "suhmicpp/links/link.h"
#include "suhmicpp/util/profile_timer.h"

#define MAX_RESULT_LENGTH 21

extern HmiAdapt *hmiAdapt;
extern HmiAdapt *currentHmi;
extern SymbolAdapt *currentSymbol;
extern WindowAdapt *currentWindow;

Expression::Expression(ObjectBase *ob, BoundExpression *boundExpression) :
		Code(ob), boundExpression(boundExpression), logger("Expression: ") {

	PyObject *pResult = PyInt_FromLong(0);
	if (PyDict_SetItemString(globals, "result", pResult) == -1) {
		logger.log(LM_WARNING, "Couldnt insert result to globals");
	}
	Py_DECREF(pResult);
}

Expression::Expression(const Expression &e, ObjectBase *ob) :
		Code(e, ob), boundExpression(e.boundExpression), logger("Expression: ") {
	PyObject *pResult = PyInt_FromLong(0);
	if (PyDict_SetItemString(globals, "result", pResult) == -1) {
		logger.log(LM_WARNING, "Couldnt insert result to globals");
	}
	Py_DECREF(pResult);
}

/**
 * Vykona expression s pouzitim sensitivityList a inputList a vysledok ulozi do result.
 */
int Expression::exec(const SuhubConnectorLight::UpdateList &updateList, double &result) {
	int rv = -1;
	logger.log(LM_DEBUG, "Executing code %s", code.c_str());
	if (ob->obType & SYMBOL) {
		currentSymbol = thisSymbolAdapt;
	}

	if (suhmiCppModule == NULL) {
		logger.log(LM_WARNING, "suhmicpp module was not imported");
		return -1;
	}

	for (SuhubConnectorLight::UpdateList::const_iterator update = updateList.begin(); update != updateList.end(); ++update) {
		updateTags(*update);
	}

	if (codeObject == NULL) {
		logger.log(LM_WARNING, "Code was not compiled");
		return -1;
	}

	/*PyObject *key, *value;
	 Py_ssize_t pos = 0;
	 while (PyDict_Next(globals, &pos, &key, &value)) {
	 std::cout << PyString_AsString(key) << std::endl;
	 }*/

	PyObject *eval = PyEval_EvalCode((PyCodeObject *) codeObject, globals, globals);
	if (PyErr_Occurred()) {
		logger.log(LM_ERROR, code.c_str());
		logger.log(LM_ERROR, "%s", getErrorDesc().c_str());
	} else {
		PyObject *resultObj = PyDict_GetItemString(globals, "result"); //PyDict_GetItemString borrowed
		if (PyFloat_Check(resultObj) || PyLong_Check(resultObj) || PyInt_Check(resultObj)) {
			if (resultObj == Py_True || resultObj == Py_False) { //bool dedi z integer preto PyInt_Check vrati true aj pre bool
				rv = 2;
			} else {
				result = PyFloat_AsDouble(resultObj);
				if (result == -1 && PyErr_Occurred()) {
					logger.log(LM_ERROR, "Error occured in code: ");
					logger.log(LM_ERROR, code.c_str());
					logger.log(LM_ERROR, getErrorDesc().c_str());
					result = 0;
					rv = -1;
				} else {
					rv = 0;
				}
			}
		} else if (resultObj == Py_None) {
			rv = 1;
		} else {
			rv = 2;
		}
		Py_DECREF(eval);
	}
	return rv;
}

int Expression::exec(const SuhubConnectorLight::UpdateList &updateList, bool &result) {
	int rv = -1;
	logger.log(LM_DEBUG, "Executing code: %s", code.c_str());
	if (ob->obType & SYMBOL) {
		currentSymbol = thisSymbolAdapt;
	}

	for (SuhubConnectorLight::UpdateList::const_iterator update = updateList.begin(); update != updateList.end(); ++update) {
		updateTags(*update);
	}

	if (suhmiCppModule == NULL) {
		logger.log(LM_WARNING, "suhmicpp module was not imported");
		return -1;
	}
	if (codeObject == NULL) {
		logger.log(LM_WARNING, "Code was not compiled");
		return -1;
	}

	PyObject *eval = PyEval_EvalCode((PyCodeObject *) codeObject, globals, globals);
	if (PyErr_Occurred()) {
		logger.log(LM_ERROR, "Error occured in code: ");
		logger.log(LM_ERROR, code.c_str());
		logger.log(LM_ERROR, getErrorDesc().c_str());
		rv = -1;
	} else {
		PyObject *resultObj = PyDict_GetItemString(globals, "result"); //PyDict_GetItemString borrowed

		if (PyBool_Check(resultObj)) {
			if (resultObj == Py_False)
				result = false;
			else
				result = true;
			rv = 0;
		} else if (PyInt_Check(resultObj) || PyLong_Check(resultObj)) {
			result = (bool) PyInt_AsLong(resultObj);
			rv = 0;
		} else if (resultObj == Py_None) {
			rv = 1;
		} else {
			rv = 2;
		}
		Py_DECREF(eval);
	}
	return rv;
}

/**
 * Vykona expression s pouzitim sensitivityList a inputList a vysledok ulozi do result.
 * \retval -1 - expression sa nepodarilo vykonat
 * \retval 0 - expression sa vykonal ok, v resulte je spravny typ
 * \retval 1 - expression sa vykonal ok, v resulte je None
 * \retval 2 - expression sa vykonal ok, v resulte je iny typ
 */
int Expression::exec(const SuhubConnectorLight::UpdateList &updateList, std::string &result) {
	int rv = -1;
	logger.log(LM_DEBUG, "Executing code: %s", code.c_str());
	//SConnector::DataWriter dw(*con, SConnector::DataWriter::APP);
	if (suhmiCppModule == NULL) {
		logger.log(LM_ERROR, "suhmiCppModule == NULL");
		return -1;
	}
	if (ob->obType & SYMBOL) {
		currentSymbol = thisSymbolAdapt;
	}

	for (SuhubConnectorLight::UpdateList::const_iterator update = updateList.begin(); update != updateList.end(); ++update) {
		updateTags(*update);
	}

	//PyObject *pResult = PyUnicode_DecodeUTF8(result.c_str(), result.size(), NULL);
	PyObject *pResult = PyString_FromString(result.c_str());
	if (PyDict_SetItemString(globals, "result", pResult) == -1) {
		logger.log(LM_WARNING, "Couldnt insert result to globals");
	}

	//PyRun_String("print globals()", Py_single_input, globals, globals);
	PyObject *eval = PyEval_EvalCode((PyCodeObject *) codeObject, globals, globals);
	if (eval == NULL) {
		logger.log(LM_ERROR, "evaluating code");
		logger.log(LM_ERROR, code.c_str());
		logger.log(LM_ERROR, getErrorDesc().c_str());
		return -1;
	}
	Py_DECREF(eval);

	PyObject *resultObj = PyDict_GetItemString(globals, "result");
	if (PyString_Check(resultObj)) {
		char *buff = PyString_AsString(resultObj);
		result.append(buff);
		rv = 0;
	} else if (PyUnicode_Check(resultObj)) {
		PyObject *resultObjUtf8 = PyUnicode_AsUTF8String(resultObj);
		char *c = PyString_AsString(resultObjUtf8);
		result.append(c);
		rv = 0;
	} else if (resultObj == Py_None) {
		rv = 1;
	} else {
		result = "unknown type";
		rv = 2;
	}
	Py_DECREF(pResult);
	return rv;

	/*
	 //Int
	 else if (PyInt_Check(resultObj)) {
	 char buff[MAX_RESULT_LENGTH];
	 sprintf(buff, "%d", PyInt_AsLong(resultObj));
	 //result = buff;
	 } else if (PyFloat_Check(resultObj)) {
	 char buff[MAX_RESULT_LENGTH];
	 sprintf(buff, "%f", PyFloat_AsDouble(resultObj));
	 result = buff;
	 }*/
}
