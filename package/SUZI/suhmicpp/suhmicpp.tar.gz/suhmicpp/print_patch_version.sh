#!/bin/bash

set -e

pushd $1 >/dev/null
git rev-parse --short HEAD
popd >/dev/null

#svn info $1 | grep Revision | cut -c 11-

