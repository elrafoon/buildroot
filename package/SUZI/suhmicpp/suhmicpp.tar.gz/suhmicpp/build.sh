cd /home/vlado/suzi/suhmi-cpp

/opt/qtsdk-2010.05/qt/bin/qmake suhmi-cpp.pro CONFIG+=RELEASE
make clean
make -j8 all

/opt/qtsdk-2010.05/qt/bin/qmake suhmi-cpp.pro CONFIG+=DEBUG
make clean
make -j8 all

/opt/qtsdk-2010.05/qt/bin/qmake suhmi-cpp.pro CONFIG+=DEBUG CONFIG+=MEM
make clean
make -j8 all
