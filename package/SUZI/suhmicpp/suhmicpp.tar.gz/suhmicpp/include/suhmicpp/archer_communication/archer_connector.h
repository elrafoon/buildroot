/*
 * archer_connector.h
 *
 *  Created on: Sep 7, 2011
 *      Author: matus
 */

#ifndef ARCHER_CONNECTOR_H_
#define ARCHER_CONNECTOR_H_
#define DATABASE_CONNECTION_NAME "archer_connection"
#define DATABASE_DRIVER "QODBC"

#include <stdint.h>
#include <map>
#include <string>
#include <QString>
#include <QVariant>
#include <QDebug>
#include <sstream>
#include "suhmicpp/configurations/archer_configuration.h"

class ArcherConnector {
public:
		ArcherConnector(const ArcherConfiguration & configuration);
		bool callQuery(std::string preparedQueryString, std::map<double,double>  & resultContainer) const;
		virtual ~ArcherConnector();
private:

		std::string host;
		uint32_t port;
		uint32_t timeout;
		std::string driverName;
};

#endif /* ARCHER_CONNECTOR_H_ */
