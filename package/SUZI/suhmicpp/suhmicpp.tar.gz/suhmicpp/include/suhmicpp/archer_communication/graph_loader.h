/*
 * graph_loader.h
 *
 *  Created on: Sep 7, 2011
 *      Author: matus
 */


#ifndef GRAPH_LOADER_H_
#define GRAPH_LOADER_H_

#include <stdint.h>
#include <QString>
#include <map>
#include <QDebug>
#include <QStringList>
#include <QThread>
#include "archer_connector.h"
#include "../configurations/archer_configuration.h"

class GraphLoader : public QThread {
	Q_OBJECT
public:
	typedef std::map<double, double> ValueMap;
	GraphLoader(ArcherConnector const * const archCon);
	virtual ~GraphLoader();
	//bool getData(std::map<double, double> & resultContainer, uint64_t seconds, QString tagName) const;
public slots:
	void getData(uint64_t seconds, QString tagName);
signals:
	void sigDataAcquired(ValueMap &resultContainer);
protected:
	void run();
private:
	ArcherConnector const * archerCon;
	ValueMap resultContainer;
	uint64_t seconds;
	QString tagName;
};

#endif /* GRAPH_LOADER_H_ */
