/*
 * swindow.h
 *
 *  Created on: Jun 28, 2010
 *      Author: vlado
 */

#ifndef SWINDOW_H_
#define SWINDOW_H_

#include <QObject>
#include <QGraphicsItem>
#include <QGridLayout>
#include <QMainWindow>
#include <QXmlSimpleReader>
#include <QXmlSchema>
#include <QXmlSchemaValidator>
#include <QAbstractMessageHandler>
#include <QTimer>
#include "suhmicpp/scene.h"
#include "suhmicpp/view.h"
#include "suhmicpp/hmi.h"
#include "suhmicpp/xml/xml_reader.h"
#include "scl/hlapi/connector.h"

class SWindow : public QMainWindow{
	Q_OBJECT
public:
	SWindow(QString &fileName);
	~SWindow();
	void setHmi(Hmi &hmi);
	void resizeEvent(QResizeEvent *event);
	void getFileName(QFile &file);
	Scene* getScene();
public slots:
	void update();
#ifdef GPROF_HEAP
	void heapDump();
#endif
#ifdef GPROF_CPU
	void cpuDump();
#endif

private:
	void init(QString &fileName);
	std::string& getFile();
	Handler handler;
	View *view;
	Scene *scene;
	Hmi *hmi;
	QTimer reactorTimer;
	PrefixedLogger logger;
#ifdef GPROF_HEAP
	QTimer heapTimer;
#endif
#ifdef GPROF_CPU
	QTimer cpuTimer;
#endif
};

#endif /* SWINDOW_H_ */
