
/*
 * script.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef SCRIPT_H_
#define SCRIPT_H_

#include <QObject>
#include <QString>
#include "suhmicpp/lists/tag_list.h"
#include "suhmicpp/code.h"
#include "scl/hlapi/update_listener.h"
#include "suhmicpp/util/prefixed_logger.h"

class Script : public QObject, public SuhubConnectorLight::UpdateListener{
public:
	Script(ObjectBase *ob);
	Script(const Script &s, ObjectBase *ob);
	void onUpdate(const SuhubConnectorLight::UpdateList &updateList);
	void fini();
	void replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable);
	TagList sensitivityList;
	TagList inputList;
	TagList outputList;
	Code code; //ma exec
	ObjectBase *ob;
private:
	PrefixedLogger logger;

};

#endif /* SCRIPT_H_ */
