/*
 * object_base.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#ifndef OBJECT_BASE_H_
#define OBJECT_BASE_H_

#include "suhmicpp/util/types.h"
#include "suhmicpp/events/oncreate.h"
#include "suhmicpp/events/ondestroy.h"
#include "suhmicpp/lists/generic_script_list.h"

class ObjectBase{
public:
	ObjectBase();
	ObjectBase(const ObjectBase &ob);
	virtual ~ObjectBase();
	virtual void create();
	virtual void destroy();
	virtual void fini() = 0;

	uint32_t obType;
	GenericScriptList genericScriptList;
	OnCreate oncreate;
	OnDestroy ondestroy;
};

#endif /* OBJECT_BASE_H_ */
