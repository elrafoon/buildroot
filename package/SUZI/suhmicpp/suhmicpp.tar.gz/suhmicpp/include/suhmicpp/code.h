
/*
 * code.h
 *
 *  Created on: Sep 29, 2010
 *      Author: vlado
 */

#ifndef CODE_H_
#define CODE_H_

#include <Python.h>
#include <QString>
#include <string>
#include <map>
#include "suhmicpp/lists/tag_list.h"
#include "scl/hlapi/stateful_ifc.h"
#include "traceable.h"
#include "suhmicpp/util/prefixed_logger.h"


class ObjectBase;
class HmiAdapt;
class SymbolAdapt;
class WindowAdapt;

class Code : public Traceable, protected PrefixedLogger{
public:
	Code(ObjectBase *ob);
	Code(const Code &c, ObjectBase *ob);
	int init();
	virtual ~Code();
	void setCode(const std::string &str);
	void compileCode();
	std::string& getCode();
	int exec(TagList const &inputList, TagList const &outputList);
	int exec(const SuhubConnectorLight::UpdateList &updateList, TagList const &outputList);
	int exec(TagList const &inputList, TagList const &outputList, std::string &newText);
	void replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable, TagList::StatefulTagVector* inputList, TagList::StatefulTagVector* sensitivityList, TagList::StatefulTagVector* outputList = NULL);
	void addReplacement(std::string &replacements, std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable, TagList::StatefulTagVector* tagList);
	void setSymbolSelf(SymbolAdapt* self);
	void setWindowSelf(WindowAdapt* self);
	void setHmiSelf(HmiAdapt* self);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);

	void addTag(SuhubConnectorLight::StatefulTag *tag);
	void updateTags(const SuhubConnectorLight::Update &update);
	void updateTags(SuhubConnectorLight::StatefulTag *tag);
protected:
	std::string getErrorDesc();
	std::string code;
	ObjectBase *ob;
	PyObject *codeObject;
	PyObject *globals, *suhmiCppModule, *createTag;
	SymbolAdapt* thisSymbolAdapt;
	WindowAdapt* thisWindowAdapt;
	HmiAdapt* thisHmiAdapt;
	std::string debugInfo;
};


#endif /* CODE_H_ */


