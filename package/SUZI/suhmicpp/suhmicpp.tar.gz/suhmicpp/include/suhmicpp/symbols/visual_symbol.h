/*
 * visual_symbol.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

/**
 *  Base class for visual symbols.
 */

#ifndef VISUAL_SYMBOL_H_
#define VISUAL_SYMBOL_H_

#include <QObject>
#include <QXmlAttributes>
#include <QPoint>
#include <QSize>
#include <QGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <string>
#include "suhmicpp/symbols/symbol.h"
#include "suhmicpp/events/onshow.h"
#include "suhmicpp/events/onhide.h"
#include "suhmicpp/events/onclick.h"
#include "suhmicpp/links/link_list.h"

class VisualSymbol:
		public QObject,
		public QGraphicsItem,
		public Symbol {
Q_OBJECT
public:
	VisualSymbol();
	VisualSymbol(const QXmlAttributes &attributes);
	VisualSymbol(const VisualSymbol &visualSymbol);

	//void setPosition(QPoint position);
	void setPosition(const QXmlAttributes &attributes);
	void setPosition(int x, int y);
	virtual std::pair<int, int> getSize();
	void setSize(const QXmlAttributes &attributes);
	virtual void setSize(float width, float height);
	void setRotation(const QXmlAttributes &attributes);
	virtual void setScale(const QXmlAttributes &attributes);
	virtual std::pair<float, float> getScale();
	virtual void setScale(float width, float height);
	void setRotCenter(int x, int y);
	void setRotCenter(const QXmlAttributes &attributes);
	void setZOrder(int zOrder);
	void mousePressEvent(QGraphicsSceneMouseEvent * event);

	virtual void show();
	virtual void hide();
	virtual void fini();

	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);

	float rotation;
	QPoint position;
	QSizeF size;
	QSize originalSize;
	int zOrder;
	QPoint rotCenter;
	LinkList linkList;
	OnShow onshow;
	OnHide onhide;
	OnClick onclick;
	bool bgBlinkState;
	bool fgBlinkState;

public slots:
	virtual void setBgColor(std::string color) = 0;
	virtual void setFgColor(std::string color) = 0;
	void setVertPosition(long vPos);
	void setHorPosition(long vPos);
	void setHorFill(long value);
	void setVertFill(long value);
	virtual void setHorSize(long value);
	virtual void setVertSize(long value);
	void setVisibility(bool visible);
	void setRotation(long newValue);
	void setRotation(float newValue);
	void changeBgBlinkState();
	void changeFgBlinkState();

protected:
	int horizontalFill;
	int verticalFill;
};

#endif /* VISUAL_SYMBOL_H_ */
