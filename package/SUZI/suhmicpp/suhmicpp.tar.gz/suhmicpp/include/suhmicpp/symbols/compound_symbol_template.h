/*
 * compound_symbol.h
 *
 *  Created on: Jul 14, 2010
 *      Author: vlado
 */

#ifndef COMPOUND_SYMBOL_TEMPLATE_H_
#define COMPOUND_SYMBOL_TEMPLATE_H_

#include <QXmlAttributes>
#include <QString>
#include <vector>
#include "suhmicpp/symbols/visual_symbol.h"

class CompoundSymbolTemplate {
public:
	typedef std::vector<Symbol*> SymbolVector;
	CompoundSymbolTemplate();
	~CompoundSymbolTemplate();
	CompoundSymbolTemplate(QString className);
	CompoundSymbolTemplate(const QXmlAttributes & attributes);
	CompoundSymbolTemplate(CompoundSymbolTemplate &compoundSymbolTemplate);
	QString className;
	SymbolVector symbol;
};

#endif /* COMPOUND_SYMBOL_TEMPLATE_H_ */
