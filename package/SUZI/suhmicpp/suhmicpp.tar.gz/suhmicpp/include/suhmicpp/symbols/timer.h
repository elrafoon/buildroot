/*
 * timer.h
 *
 *  Created on: Sep 9, 2011
 *      Author: vlado
 */

#ifndef TIMER_H_
#define TIMER_H_

#include <stdint.h>
#include <QObject>
#include <QTimer>
#include <QXmlAttributes>
#include "suhmicpp/symbols/symbol.h"
#include "../events/ontick.h"

class Timer:
		public QObject,
		public Symbol {
	Q_OBJECT

public:
	Timer(const QXmlAttributes &attributes);
	Timer(const Timer &timer);
	void fini();
	virtual Symbol* clone();
	void setEnabled(bool enabled);
	void compileCodes();
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);

	OnTick onTick;
public slots:
	void onTimeout();

private:
	QTimer qTimer;
	uint32_t period;
	bool enabled;
};

#endif /* TIMER_H_ */
