/*
 * value_display.h
 *
 *  Created on: Oct 22, 2010
 *      Author: vlado
 */

#ifndef VALUE_DISPLAY_H_
#define VALUE_DISPLAY_H_

#include <QtGui>
#include <QLineEdit>
#include <QKeyEvent>
#include <QXmlAttributes>
#include <QPainter>
#include <QGraphicsItem>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <QFont>
#include <QString>
#include "WidgetKeyboard.h"
#include "suhmicpp/symbols/base_label.h"
#include "suhmicpp/links/value_link.h"
#include "suhmicpp/line_edit.h"

class ValueDisplay: public BaseLabel{
	Q_OBJECT
public:
	ValueDisplay(const QXmlAttributes &attributes);
	ValueDisplay(const ValueDisplay &vd);
	virtual Symbol* clone();
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);
	std::string getTagName();
	void setTag(SuhubConnectorLight::StatefulTag *tag);
	void formatValue(char * const buff) const;

	QString tagName;
	bool writeEnabled;
	ValueLink valueLink;

public slots:
	void setValue(double value);
	void editingFinished();
	void onCancelEditing();
private:
	char buff[21];
	double value;
	LineEdit lineEdit;
	SuhubConnectorLight::StatefulTag *tag;
	uint32_t precision;
	bool scientific;
	PrefixedLogger logger;
};

#endif /* VALUE_DISPLAY_H_ */
