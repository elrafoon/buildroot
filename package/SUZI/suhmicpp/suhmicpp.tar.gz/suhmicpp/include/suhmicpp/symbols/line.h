/*
 * line.h
 *
 *  Created on: Jul 9, 2010
 *      Author: vlado
 */

#ifndef LINE_H_
#define LINE_H_

#include <QXmlAttributes>
#include <QPainter>
#include <QGraphicsItem>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <vector>
#include "suhmicpp/symbols/simple_visual_symbol.h"


class Line : public SimpleVisualSymbol{
	Q_OBJECT
private:
	QObject *parent;
	QPainterPath shape() const;
	QPainterPath linePath;

public:
	Line(const QXmlAttributes &attributes);
	Line(const Line &line);
	virtual Symbol* clone();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option,
			QWidget *widget);
	std::vector<QPoint> vertexes;
	std::vector<QPoint> originalVertexes;
	void addVertex(const QXmlAttributes &attributes);
	void setStart(int x, int y);
	void getStart(int &x, int &y);
	void setEnd(int x, int y);
	void getEnd(int &x, int &y);
	virtual void setSize(int width, int height);
	void fini();
	virtual void setLineWidth(int lineWidth);
public slots:
	void setHorSize(long value);
	void setVertSize(long value);
};


#endif /* LINE_H_ */
