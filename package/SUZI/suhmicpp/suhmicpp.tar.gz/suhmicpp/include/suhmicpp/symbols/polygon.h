/*
 * polygon.h
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#ifndef POLYGON_H_
#define POLYGON_H_

#include <QXmlAttributes>
#include <QPainter>
#include <QGraphicsItem>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <vector>
#include <algorithm>
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/util/prefixed_logger.h"

class Polygon : public SimpleVisualSymbol
{
private:
	QPainterPath shape() const;
	QObject *parent;
	QPainterPath path;
	QPainterPath innerPath;
	PrefixedLogger logger;
public:
	Polygon();
	Polygon(const QXmlAttributes &attributes);
	virtual Symbol* clone();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void addVertex(const QXmlAttributes &attributes);
	void fini();
	std::pair<QPointF, QPointF> getInnerLine(QPointF &p1, QPointF &p2);
	int intersection(QPointF &intersect, int x1,int y1,int x2,int y2,int x3, int y3, int x4,int y4);
	void setSize(int width, int height);
	void setHorSize(long value);
	void setVertSize(long value);
	std::vector<QPointF> vertexes;
	std::vector<QPointF> originalVertexes;
	std::vector<int> xs;
	std::vector<int> ys;
	QRect innerRectangle; //vnutorny bounding rectangle
};

#endif /* POLYGON_H_ */
