/*
 * image.h
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#ifndef IMAGE_H_
#define IMAGE_H_

#include <QXmlAttributes>
#include <QWidget>
#include <QPainter>
#include <QString>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <string>
#include "suhmicpp/symbols/visual_symbol.h"

enum Ext {JPG,BMP,PNG,SVG,GIF};

class Image: public VisualSymbol
{
	Q_OBJECT
private:
	QPainterPath shape() const;
	QImage image;
	static const QSize maxSize;
public:
	Image(const QXmlAttributes &attributes);
	Image(const Image &image);
	virtual Symbol* clone();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void setData(std::string data);
	virtual std::pair<int, int> getSize();
	QSize getMaxSize();
	Ext extension;
	std::string data;
public slots:
	void setBgColor(std::string color){}
	void setFgColor(std::string color){}
};

#endif /* IMAGE_H_ */
