/*
 * label.h
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#ifndef STATIC_LABEL_H_
#define STATIC_LABEL_H_

#include <QtGui>
#include <QXmlAttributes>
#include <QPainter>
#include <QGraphicsItem>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <QFont>
#include <QString>
#include "base_label.h"

class StaticLabel: public BaseLabel{
public:
	StaticLabel(const QXmlAttributes &attributes);
	virtual Symbol* clone();
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	std::string getText();
	void setText(std::string text);

	std::string text;
};

#endif /* STATIC_LABEL_H_ */
