/*
 * ellipse.h
 *
 *  Created on: Jul 9, 2010
 *      Author: vlado
 */

#ifndef ELLIPSE_H_
#define ELLIPSE_H_

#include <QPainter>
#include <QXmlAttributes>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include "suhmicpp/symbols/simple_visual_symbol.h"

class Ellipse: public SimpleVisualSymbol
{
private:
	QPainterPath shape() const;
public:
	Ellipse(const QXmlAttributes &attributes);
	virtual Symbol* clone();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif /* ELLIPSE_H_ */
