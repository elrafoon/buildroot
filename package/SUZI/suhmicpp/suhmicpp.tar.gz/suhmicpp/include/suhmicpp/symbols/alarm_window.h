/*
 * alarm_window.h
 *
 *  Created on: Aug 24, 2011
 *      Author: vlado
 */

#ifndef ALARM_WINDOW_H_
#define ALARM_WINDOW_H_

#include <stdint.h>
#include <string>
#include <ace/Reactor.h>
#include <ace/INET_Addr.h>
#include <QXmlAttributes>
#include <QHeaderView>
#include "suhmicpp/events/onshow.h"
#include "../events/onhide.h"
#include "suhmicpp/symbols/symbol.h"
#include "suhmicpp/util/prefixed_logger.h"
//#include "../AlarmWindow/alarmcontroller.h"

class AlarmController;

class AlarmWindowSource {
public:
	enum ESource {
		SYSTEM, GROUP, ALARM
	};
	ESource source;
};

class AWSSystem:
		public AlarmWindowSource {
public:
	AWSSystem();
};

class AWSGroup:
		public AlarmWindowSource {
public:
	AWSGroup(const QXmlAttributes &attributes);
	uint32_t groupId;
	bool withSubGroups;
};

class AWSAlarm:
		public AlarmWindowSource {
public:
	AWSAlarm(const QXmlAttributes &attributes);
	uint32_t alarmId;
};

class AlarmColumn {
public:
	enum EType {
		alarmLatestUpdateTime = 0, alarmName = 1, groupName = 2, alarmPriority = 3, alarmEffectivePriority = 4, groupEffectivePriority = 5, alarmState = 6, groupState = 7, alarmConditions = 8
	};
	AlarmColumn(EType type,	uint32_t section = 0, uint32_t width = 0);
	void setWidth(uint32_t width);
	EType type;
	uint32_t section;
	uint32_t width;
};

class AlarmWindow:
		public Symbol {
public:
	typedef std::vector<AlarmColumn *> ColumnVector;
	enum EButtonSet {
		ackSelected = 0, ackGroup = 1, ackGroupRecursive = 2, ackAll = 3, ackInactive = 4
	};
	enum EFilter {
		NACT_NACK = 0x01, NACT_ACK = 0x02, ACT_NACK = 0x04, ACT_ACK = 0x08
	};
	struct ColumnSort {
		bool operator()(AlarmColumn const * const col1, AlarmColumn const * const col2) const {
			return col1->section < col2->section;
		}
	} columnSort;

	AlarmWindow(const QXmlAttributes &attributes, int port, std::string host);
	virtual ~AlarmWindow();
	void fini();
	virtual Symbol* clone();
	void setPosition(const QXmlAttributes &attributes);
	void setSize(const QXmlAttributes &attributes);

	//void setColumnSet(const QXmlAttributes &attributes);
	void addColumn(const QXmlAttributes &attributes);
	//void setColumnWidths(const QXmlAttributes &attributes);
	void setButtonSet(const QXmlAttributes &attributes);
	void setFilter(const QXmlAttributes &attributes);
	/**
	 * Zisti hodnotu atributu \a name a ak tato hodnota nie je -1 (co znamena ze column alebo button je skryty) vlozi do \a map \a item.
	 */
	template<class Enum> void insertIfNotHidden(std::map<int, EButtonSet> &map, const QXmlAttributes &attributes, const char *name, Enum item) {
		int value = attributes.value(name).toInt();
		if (value != -1) {
			map[value] = item;
		}
	}

	void show();
	void hide();
	AlarmController const * const getAlarmWindowWidget();

	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);

	uint32_t refreshPeriod;
	std::string defaultSortColumn;
	bool userSortEnabled;

	QPoint position;
	QSize size;

	OnShow onshow;
	OnHide onhide;
	AlarmWindowSource *source;

	uint8_t filter;
	std::vector<EButtonSet> buttonVector;
	ColumnVector columnVector;
	std::map<AlarmColumn::EType, AlarmColumn* > columns;
	int port;
	std::string host;
protected:
	PrefixedLogger logger;
private:
	AlarmController *alarmController;
};

#endif /* ALARM_WINDOW_H_ */

