/*
 * base_label.h
 *
 *  Created on: Oct 26, 2010
 *      Author: vlado
 */

#ifndef BASE_LABEL_H_
#define BASE_LABEL_H_

#include <QPainter>
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/font.h"
#include "suhmicpp/util/prefixed_logger.h"

class BaseLabel:
		public SimpleVisualSymbol {
Q_OBJECT
public:
	BaseLabel(const QXmlAttributes &attributes);
	explicit BaseLabel(const BaseLabel &bl);
	void setFontAttributes(const QXmlAttributes &attributes);
	Font& getFont();
	void updateQFont();
	void setSize(int width, int height);
	void setHorSize(long value);
	void setVertSize(long value);
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

protected:
	Font sFont;
private:
	QPainterPath shape() const;
};

#endif /* BASE_LABEL_H_ */
