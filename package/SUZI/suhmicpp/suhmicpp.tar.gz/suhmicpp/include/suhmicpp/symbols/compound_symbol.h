/*
 * compound_symbol_ref.h
 *
 *  Created on: Jul 14, 2010
 *      Author: vlado
 */

#ifndef COMPOUND_SYMBOL_H_
#define COMPOUND_SYMBOL_H_

#include <QXmlAttributes>
#include <QString>
#include <QPainter>
#include <QWidget>
#include <QStyleOptionGraphicsItem>
#include <QPainterPath>
#include <stdint.h>
#include <map>
#include <vector>
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/links/value_link.h"
#include "compound_symbol_template.h"
#include "suhmicpp/util/prefixed_logger.h"

class Handler;

class CompoundSymbol:
		public VisualSymbol,
		protected PrefixedLogger {
Q_OBJECT
public:
	typedef std::list<BoundExpression *> BoundExpressionsPtrs;
	typedef std::list<Script *> ScriptPtrs;
	typedef std::list<ValueLink *> ValueLinkPtrs;
	//TODO(vlado): cele zle, prerobit
	typedef std::set<BlinkLink *> BlinkLinksSet; //hmi.h
	typedef std::vector<Symbol*> SybolVector;

	CompoundSymbol(const QXmlAttributes &attributes, CompoundSymbolTemplate *compoundSymbolTemplate, BoundExpressionsPtrs &boundExpressionsPtrs, ScriptPtrs &scriptPtrs, ValueLinkPtrs &valueLinkPtrs, BlinkLinksSet &blinkLinks);
	void init(CompoundSymbolTemplate *compoundSymbolTemplate, BoundExpressionsPtrs &boundExpressionsPtrs, ScriptPtrs &scriptPtrs, ValueLinkPtrs &valueLinkPtrs, BlinkLinksSet &blinkLinks);
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void setReplacementTable(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable);
	virtual Symbol* clone();
	std::pair<float, float> getScale();
	void setScale(const QXmlAttributes &attributes);
	void setScale(float width, float height);
	std::pair<int, int> getSize();
	void setSize(int width, int height);
	void fini();
	void create();
	QString className;
	CompoundSymbolTemplate *compoundSymbolTemplate;
	std::map<std::string, SuhubConnectorLight::StatefulTag *> replacementTable;
	SybolVector symbols;
public slots:
	void setBgColor(std::string color);
	void setFgColor(std::string color);
	void setHorSize(long width);
	void setVertSize(long height);

private:
	uint64_t us;
	char buff[21];
	QPainterPath shape() const;
};

#endif /* COMPOUND_SYMBOL_H_ */
