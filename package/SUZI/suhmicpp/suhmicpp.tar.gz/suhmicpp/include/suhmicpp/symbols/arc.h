/*
 * arc.h
 *
 *  Created on: Jul 9, 2010
 *      Author: vlado
 */

#ifndef ARC_H_
#define ARC_H_

#include <QXmlAttributes>
#include <QWidget>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <math.h>

#include "suhmicpp/symbols/simple_visual_symbol.h"

#define PI 3.14159265

class Arc:
		public SimpleVisualSymbol {
private:
	QPainterPath shape() const;
	QPainterPath arcPath;
	QPainterPath innerArcPath;
	QPainterPath cutoutPath;
	std::pair<std::pair<QPoint, QPoint>, std::pair<QPoint, QPoint> > lines;
public:
	Arc();
	Arc(const QXmlAttributes &attributes);
	virtual Symbol* clone();
	void fini();
	std::pair<QPoint, QPoint> getInnerLine(QPoint &p1, QPoint &p2, bool start);
	std::pair<QPoint, QPoint> getInnerLine(QPoint &p1, QPoint &p2, bool start, int distance);
	int intersection(QPoint &intersect, int x1,int y1,int x2,int y2,int x3, int y3, int x4,int y4);
	QPoint ellipseIntersection(int angle);
	enum ArcType {chord,open,pie};
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option,
			QWidget *widget);
	void setSize(float width, float height);
	void setHorSize(long value);
	void setVertSize(long value);
	void setArctype(int arctype);

	int angleStart;
	int angleSize;
	int radius;
	ArcType arctype;

	void setAngleStart(int angleStart);
	int getAngleStart();

	void setAngleSize(int angleSize);
	int getAngleSize();
};

#endif /* ARC_H_ */
