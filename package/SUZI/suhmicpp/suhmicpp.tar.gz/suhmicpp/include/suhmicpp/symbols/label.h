/*
 * label.h
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#ifndef LABEL_H_
#define LABEL_H_

#include <QXmlAttributes>
#include <QPainter>
#include <QGraphicsItem>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include "base_label.h"
#include "suhmicpp/bound_expression.h"
#include "suhmicpp/events/onchange.h"
#include "suhmicpp/result_listener.h"
#include "suhmicpp/line_edit.h"
#include "WidgetKeyboard.h"

class Label:
		public BaseLabel,
		public ResultListener {
Q_OBJECT
public:
	Label();
	explicit Label(const Label &label);
	explicit Label(const QXmlAttributes &attributes);
	virtual Symbol* clone();
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);
	void setFontAttributes(const QXmlAttributes &attributes);
	void handleResult(std::string result);
	std::string getText();
	void setText(std::string text);
	void compileCodes();
	bool writeEnabled;
	QString expression;
	int fontSize;
	BoundExpression boundExpression;
	OnChange onchange;
public slots:
	void editingFinished();
	void onCancelEditing();
private:
	QPainterPath shape() const;
	LineEdit lineEdit;
	std::string text;

};

#endif /* LABEL_H_ */
