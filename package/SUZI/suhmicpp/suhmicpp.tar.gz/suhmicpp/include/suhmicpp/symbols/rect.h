/*
 * rect.h
 *
 *  Created on: Jun 25, 2010
 *      Author: vlado
 */

#ifndef RECT_H_
#define RECT_H_

#include <stdint.h>
#include <QPainter>
#include <QXmlAttributes>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include "suhmicpp/symbols/simple_visual_symbol.h"

class Rect : public SimpleVisualSymbol
{
public:
	Rect(const QXmlAttributes &attributes);
	Rect(const Rect &rect);
	virtual Symbol* clone();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
	uint64_t us;
	QPainterPath shape() const;
};

#endif /* RECT_H_ */
