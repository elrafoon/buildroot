/*
 * polyline.h
 *
 *  Created on: Jul 12, 2010
 *      Author: vlado
 */

#ifndef POLYLINE_H_
#define POLYLINE_H_

#include <QXmlAttributes>
#include <QPainter>
#include <QGraphicsItem>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsSceneMouseEvent>
#include <vector>
#include "suhmicpp/symbols/simple_visual_symbol.h"

class Polyline : public SimpleVisualSymbol
{
public:
	Polyline();
	Polyline(const QXmlAttributes &attributes);
	virtual Symbol* clone();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void addVertex(const QXmlAttributes &attributes);
	void setSize(int width, int height);
	void fini();
	std::vector<QPoint> vertexes;
	std::vector<QPoint> originalVertexes;
public slots:
	void setHorSize(long value);
	void setVertSize(long value);

private:
	QObject *parent;
	QPainterPath shape() const;
	QPainterPath polyline;
};


#endif /* POLYLINE_H_ */
