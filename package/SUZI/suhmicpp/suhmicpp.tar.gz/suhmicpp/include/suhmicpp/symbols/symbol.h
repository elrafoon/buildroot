/*
 * symbol.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#ifndef SYMBOL_H_
#define SYMBOL_H_

#include <string>
#include <QXmlAttributes>
#include <QString>
#include <QGraphicsSceneMouseEvent>
#include "suhmicpp/object_base.h"
#include "suhmicpp/traceable.h"

class Symbol: public ObjectBase, public Traceable{
public:
	Symbol();
	Symbol(QString &name);
	Symbol(const QXmlAttributes &attributes);
	Symbol(const Symbol &symbol);
	/**
	 * pouziva sa pri klonovani visualSymbolov z CompoundSymbolTemplate do CompoundSymbol
	 */
	virtual Symbol* clone() = 0;
	virtual void fini();
	virtual void create();
	virtual void destroy();
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
	std::string name;
};

#endif /* SYMBOL_H_ */
