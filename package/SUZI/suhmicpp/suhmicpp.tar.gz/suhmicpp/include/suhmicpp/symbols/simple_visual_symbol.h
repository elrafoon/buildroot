/*
 * simple_visual_symbol.h
 *
 *  Created on: Jul 8, 2010
 *      Author: vlado
 */

#ifndef SIMPLE_VISUAL_SYMBOL_H_
#define SIMPLE_VISUAL_SYMBOL_H_

#include <QXmlAttributes>
#include <QString>
#include <QColor>
#include <QPen>
#include "suhmicpp/symbols/visual_symbol.h"

class SimpleVisualSymbol: public VisualSymbol{
	Q_OBJECT
public:
	SimpleVisualSymbol(const QXmlAttributes &attributes);
	SimpleVisualSymbol(const SimpleVisualSymbol &svs);
	QRectF boundingRect() const;
	virtual Symbol* clone() = 0;
	virtual void setLineWidth(int lineWidth);
	void setFgColor(int r, int g, int b, int a = 255);
	int getFgStyle() const;
	void setFgStyle(int style);
	void setBgColor(int r, int g, int b, int a = 255);
	int getBgStyle() const;
	void setBgStyle(int style);
	virtual void setSize(int width, int height);

	int lineWidth;
	QColor fgColor;
	Qt::PenStyle fgStyle;
	QColor bgColor;
	Qt::BrushStyle bgStyle;
protected:
	QPen pen;
	QBrush brush;
public slots:
	virtual void setBgColor(std::string color);
	virtual void setFgColor(std::string color);
};

#endif /* SIMPLE_VISUAL_SYMBOL_H_ */
