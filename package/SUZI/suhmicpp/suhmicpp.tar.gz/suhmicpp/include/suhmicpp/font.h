/*
 * font.h
 *
 *  Created on: Jan 18, 2011
 *      Author: vlado
 */

#ifndef FONT_H_
#define FONT_H_

#include <QFont>
#include <string>

class BaseLabel;

class Font {
public:
	enum Align {
		LEFT = 0, CENTER = 1, RIGHT = 2
	};
	enum Name {
		SERIF = 0, SANSSERIF = 1, MONOSPACED = 2
	};
	enum Style {
		PLAIN = 0, BOLD = 1, ITALIC = 2
	};

	Font();
	void setAlign(const std::string &align);
	void setAlign(Align align);
	void setAlign(int align);

	void setName(const std::string &name);
	void setName(const Name name);
	void setName(int name);

	void setStyle(const std::string &style);
	void setStyle(Style style);
	void setStyle(int style);

	void setSize(int size);

	Align getAlign() const;
	Name getName() const;
	int getSize() const;
	Style getStyle() const;
	QFont const& getQFont();

	int size; //fontSize
	int flags;

private:

	void updateQFont();

	Align align;
	Name name;
	Style style;
	QFont font;

	BaseLabel *bl;
};

#endif /* FONT_H_ */
