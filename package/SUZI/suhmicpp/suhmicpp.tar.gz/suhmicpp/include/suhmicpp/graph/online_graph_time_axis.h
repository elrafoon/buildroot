/*
 * online_graph_time_axis.h
 *
 *  Created on: Jun 7, 2011
 *      Author: vlado
 */

#ifndef ONLINE_GRAPH_TIME_AXIS_H_
#define ONLINE_GRAPH_TIME_AXIS_H_

#include <stdint.h>
#include <time.h>
#include <string>
#include <QXmlAttributes>
#include <QGraphicsItem>
#include <QPainter>
#include <QDateTime>
#include <QFont>

#include "suhmicpp/font.h"

/**
 * Casova os grafu. Vykresluje casove popisky od startTime do endTime.
 */
class OnlineGraphTimeAxis : public QGraphicsItem {
public:
	OnlineGraphTimeAxis();
	OnlineGraphTimeAxis(const OnlineGraphTimeAxis &ogta);
	void setValues(const QXmlAttributes &attributes);
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void setWidth(int width);
    int getWidth() const;
    void setHeight(int height);
    int getHeight() const;
    void setTimeRange(uint64_t startTime, uint64_t endTime);
    uint64_t getTStart() const;
    uint64_t getTEnd() const;
    void setLabelsColor(std::string& color);
    void setFont(Font *font);
    void setVerticalLineCount(uint32_t verticalLineCount);
    void setTimeAxisOversize(uint32_t timeAxisOversize);
private:
    QFont normal;
    uint64_t tStart;
    uint64_t tEnd;
    uint64_t startTime;
    uint64_t endTime;
    int width;
    int height;
    //QColor labelsColor;
    QColor axisLabelsColor;
    Font *font;
    QSize labelSize;
	uint32_t verticalLineCount;
	uint32_t timeAxisOversize;
};

#endif /* ONLINE_GRAPH_TIME_AXIS_H_ */
