/*
R * online_graph.h
 *
 *  Created on: Jun 7, 2011
 *      Author: vlado
 */

#ifndef ONLINE_GRAPH_H_
#define ONLINE_GRAPH_H_

#include <stdint.h>
#include <QtGui>
#include <QXmlAttributes>
#include <QTimer>
#include <QFont>
#include <QPoint>
#include <QSize>
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "online_graph_time_axis.h"
#include "online_graph_value_axis.h"
#include "online_graph_pen.h"
#include "pens_area.h"
#include "suhmicpp/font.h"
#include "../archer_communication/archer_connector.h"

class OnlineGraph:
		public SimpleVisualSymbol {
	Q_OBJECT
public:
	typedef std::vector<OnlineGraphPen *> PenVector;
	OnlineGraph(const QXmlAttributes &attributes, const ArcherConfiguration &archerConfiguration);
	OnlineGraph(const OnlineGraph &graph);
	virtual ~OnlineGraph();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	virtual Symbol* clone();
	void fini();
	void setFontAttributes(const QXmlAttributes &attributes);
	void setLabelFontAttributes(const QXmlAttributes &attributes);
	QPoint getPenAreaPos();
	QSize getPenAreaSize(int timeLabelHeight);
	void updateGeometry();
	uint32_t getHorizontalLineCount();
	uint32_t getVerticalLineCount();

	QString title; //kodovanie UTF-8
	QColor titleColor;
	uint32_t titleHight;
	OnlineGraphTimeAxis timeAxis;
	OnlineGraphValueAxis valueAxis;
	PenVector pens;
	QTimer refreshTimer;
	unsigned int tagNameWidth;

	struct compPenByNameLenght {
		bool operator()(const OnlineGraphPen *a, const OnlineGraphPen *b) const {
			return a->tag->name.length() < b->tag->name.length();
		}
	};
public slots:
	void onRefreshTimer();
	void setHorSize(long value);
	void setVertSize(long value);
	void setSize(int width, int height);

private:
	QFont normal;
	Font titleFont;
	Font labelFont;
	uint32_t maxPenNameWidth;
	uint32_t maxPenRangeWidth;
	QSize timeLabelSize;
	PensArea pensArea;

	uint32_t horizontalLineCount;
	uint32_t verticalLineCount;
	uint32_t labelHeight;

	ArcherConfiguration archerConfiguration;
	QColor axisLabelsColor;
};

#endif /* ONLINE_GRAPH_H_ */
