/*
 * online_graph_value_axis.h
 *
 *  Created on: Jun 7, 2011
 *      Author: vlado
 */

#ifndef ONLINE_GRAPH_VALUE_AXIS_H_
#define ONLINE_GRAPH_VALUE_AXIS_H_

#include <QGraphicsItem>
#include <QXmlAttributes>
#include <QPainter>

class OnlineGraph;

class OnlineGraphValueAxis{
public:
	enum RangeModeType {
		common, stacked
	};

	OnlineGraphValueAxis();
	OnlineGraphValueAxis(const OnlineGraphValueAxis &ogva);
	void setValues(const QXmlAttributes &attributes);
	RangeModeType rangeMode;
};

#endif /* ONLINE_GRAPH_VALUE_AXIS_H_ */
