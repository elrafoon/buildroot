/*
 * online_graph_pen.h
 *
 *  Created on: Jun 7, 2011
 *      Author: vlado
 */

#ifndef ONLINE_GRAPH_PEN_H_
#define ONLINE_GRAPH_PEN_H_

#include <stdint.h>
#include <string>
#include <map>
#include <QXmlAttributes>
#include <QGraphicsItem>
#include <QPainterPath>
#include <QPen>
#include "scl/hlapi/update_listener.h"
#include "../configurations/archer_configuration.h"
#include "../archer_communication/graph_loader.h"

class DataType {
public:
	enum Type {
		ANALOG, INTEGER, DISCRETE
	};
	Type type;
	void setType(const std::string &type);
};

class OnlineGraphPenRange {
};

class OnlineGraphPenRangeManual:
		public OnlineGraphPenRange {
public:
	OnlineGraphPenRangeManual(const QXmlAttributes &attributes);
	double minimum;
	double maximum;

};

class OnlineGraphPenRangeAuto:
		public OnlineGraphPenRange {
public:
	OnlineGraphPenRangeAuto(const QXmlAttributes &attributes);
	float reserve;
};

class OnlineGraphPenRangeTight:
		public OnlineGraphPenRange {
public:
	OnlineGraphPenRangeTight(const QXmlAttributes &attributes);
	float minRange;
};

/** OnlineGraphPen definuje ako sa vykresli priebeh tagu do grafu.
 * Definuje farbu, sirku, styl pera.
 * Rozsah moze byt: manual - pouziju sa uvedene hranice\n
 * automatic - \n
 * tight - \n
 */
class OnlineGraphPen:
		public QObject,
		public QGraphicsItem,
		public SuhubConnectorLight::UpdateListener {
	Q_OBJECT
public:
	typedef std::map<double, double> ValuesMap;
	typedef GraphLoader::ValueMap ValueMap;

	enum RangeType {
		manual, automatic, tight
	};
	enum FgStyle {
		solid, dash, dot, dashdot
	};
	struct CompareValuesByValue {
		bool operator()(const std::pair<const double, double>& a, const std::pair<const double, double>& b) const {
			return a.second < b.second;
		}
	};
	OnlineGraphPen(const QXmlAttributes &attributes, SuhubConnectorLight::StatefulTag *tag, uint64_t tStart, const ArcherConfiguration &archerConfiguration);
	OnlineGraphPen(const OnlineGraphPen &onlinePen);
	~OnlineGraphPen();
	void onUpdate(const SuhubConnectorLight::UpdateList &updateList);
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void setSize(int width, int height);
	void setRangeTypeIsCommon(bool isCommon);
	void setTimeRange(uint64_t startTime, uint64_t endTime);
	const std::string & getColor();
	double getMinEU();
	double getMaxEU();
	void addValues(ValuesMap &values);
	double msToSec(double msec);
	SuhubConnectorLight::StatefulTag *tag;
	RangeType rangeType;
	OnlineGraphPenRange *range;
	double absMin;
	double absMax;
public slots:
	void dataAcquired(ValueMap & resultContainer);
private:
	void loadDataFromArchive();
	std::string color;
	unsigned int width;
	Qt::PenStyle style;
	QSize size;
	QPainterPath path;

	ValuesMap values;
	bool isCommon;

	uint64_t startTime;
	uint64_t endTime;

	double minEU;
	double maxEU;
	DataType dataType;
	ArcherConnector archerConnector;
	GraphLoader graphLoader;
};

#endif /* ONLINE_GRAPH_PEN_H_ */
