/*
 * pens_area.h
 *
 *  Created on: Aug 17, 2011
 *      Author: vlado
 */

#ifndef PENS_AREA_H_
#define PENS_AREA_H_

#include <stdint.h>
#include <QXmlAttributes>
#include <QGraphicsItem>
#include <QPainter>
#include <QPoint>
#include <QSize>


class PensArea : public QGraphicsItem {
public:
	PensArea(const QXmlAttributes &attributes, QGraphicsItem *parent);
	PensArea(const PensArea &pa);
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

	void setSize(int width, int height);
	void setHorSize(long width);
	void setVertSize(long height);

	void setSubGridsNumber(uint32_t subGrids);
    uint32_t getVerticalLineCount() const;
    void setHorizontalLineCount(uint32_t horizontalLineCount);
    void setVerticalLineCount(uint32_t verticalLineCount);

	QPoint position;
	QSize size;
private:
	QColor gridColor;
	QColor bgColor;
	uint32_t subGrids;
	uint32_t horizontalLineCount;
	uint32_t verticalLineCount;
	QBrush brush;
	Qt::BrushStyle graphBgStyle;

};

#endif /* PENS_AREA_H_ */
