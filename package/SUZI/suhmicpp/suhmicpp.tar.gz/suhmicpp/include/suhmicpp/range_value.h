/*
 * range_value.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef RANGE_VALUE_H_
#define RANGE_VALUE_H_

#include <QString>
#include <QXmlAttributes>

class RangeValue {
public:
	RangeValue(const QXmlAttributes &attributes);
	float rangeLow;
	float rangeHigh;
	QString value;
private:
};

#endif /* RANGE_VALUE_H_ */
