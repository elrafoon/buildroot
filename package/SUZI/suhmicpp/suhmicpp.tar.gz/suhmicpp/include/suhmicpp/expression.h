/*
 * expression.h
 *
 *  Created on: Sep 30, 2010
 *      Author: vlado
 */

#ifndef EXPRESSION_H_
#define EXPRESSION_H_

#include "code.h"
#include "suhmicpp/util/prefixed_logger.h"

class BoundExpression;

class Expression : public Code{
public:
	Expression(ObjectBase *ob, BoundExpression *boundExpression);
	Expression(const Expression &e, ObjectBase *ob);
	int exec(const SuhubConnectorLight::UpdateList &updateList, double &result);
	int exec(const SuhubConnectorLight::UpdateList &updateList, bool &result);
	int exec(const SuhubConnectorLight::UpdateList &updateList, std::string &result);

private:
	BoundExpression *boundExpression;
	PrefixedLogger logger;

};

#endif /* EXPRESSION_H_ */
