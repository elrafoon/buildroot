/*
 * sconnector.h
 *
 *  Created on: Sep 10, 2010
 *      Author: vlado
 */

#ifndef SCONNECTOR_H_
#define SCONNECTOR_H_

#include <list>
#include <string>
#include "connector/connector.h"

using namespace SuhubConnector;

typedef GenericTag<GenericTagValue> Tag;
typedef Connector<Tag,GenericTagValue> GenericConnector;

class SConnector : public GenericConnector {
public:
	SConnector(TagNameSet &staticNotifyList, TagNameSet &staticInputList, TagNameSet &dynamicNotifyList, TagNameSet &dynamicInputList);
	virtual ~SConnector(){};
};


#endif /* SCONNECTOR_H_ */
