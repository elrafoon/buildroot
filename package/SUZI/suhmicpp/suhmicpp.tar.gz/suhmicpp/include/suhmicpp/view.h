/*
 * suzi_view.h
 *
 *  Created on: Jul 5, 2010
 *      Author: vlado
 */

#ifndef VIEW_H_
#define VIEW_H_

#include <QtGui>
#include <QGraphicsView>

class View : public QGraphicsView
{
	Q_OBJECT
private:
	//void mousePressEvent(QMouseEvent * event );
	void resizeEvent ( QResizeEvent * event );
	char buff[21];
public:
	View(QGraphicsScene *scene, QWidget * parent);
	//void resizeEvent(QResizeEvent *event);
};

#endif /* VIEW_H_ */
