/*
 * alarm_configuration.h
 *
 *  Created on: Sep 6, 2011
 *      Author: vlado
 */

#ifndef ALARM_CONFIGURATION_H_
#define ALARM_CONFIGURATION_H_

#include <string>
#include <stdint.h>
#include <QXmlAttributes>

class AlarmConfiguration {
public:
	AlarmConfiguration();
	void setAttributes(const QXmlAttributes &attributes);
	std::string host;
	uint32_t port;
};


#endif /* ALARM_CONFIGURATION_H_ */
