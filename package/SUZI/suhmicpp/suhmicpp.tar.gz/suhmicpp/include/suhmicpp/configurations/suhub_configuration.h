/*
 * suhub_configuration.h
 *
 *  Created on: Aug 22, 2011
 *      Author: vlado
 */

#ifndef SUHUB_CONFIGURATION_H_
#define SUHUB_CONFIGURATION_H_

#include <string>
#include <stdint.h>
#include <QXmlAttributes>

class SuhubConfiguration{
public:
	SuhubConfiguration(){};
	void setAttributes(const QXmlAttributes &attributes);
	std::string host;
	uint32_t notifyPort;
	uint32_t inputPort;
	uint32_t timeout;
};

#endif /* SUHUB_CONFIGURATION_H_ */
