/*
 * archer_configuration.h
 *
 *  Created on: Aug 22, 2011
 *      Author: vlado
 */

#ifndef ARCHER_CONFIGURATION_H_
#define ARCHER_CONFIGURATION_H_


#include <stdint.h>
#include <string>
#include <QXmlAttributes>

class ArcherConfiguration {
public:
	ArcherConfiguration(){};
	void setAttributes(const QXmlAttributes &attributes);
	std::string host;
	uint32_t port;
	uint32_t timeout;
	std::string driverName;
};

#endif /* ARCHER_CONFIGURATION_H_ */
