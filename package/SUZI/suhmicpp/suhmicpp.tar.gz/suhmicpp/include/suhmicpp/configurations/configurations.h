/*
 * configurations.h
 *
 *  Created on: Aug 22, 2011
 *      Author: vlado
 */

#ifndef CONFIGURATIONS_H_
#define CONFIGURATIONS_H_

#include <QXmlAttributes>
#include "suhub_configuration.h"
#include "archer_configuration.h"
#include "alarm_configuration.h"

class Configurations {
public:
	Configurations(){};
	Configurations(const QXmlAttributes &attributes);
	void setSuhubConfiguration(const QXmlAttributes &attributes);
	void setArcherConfiguration(const QXmlAttributes &attributes);
	void setAlarmConfiguration(const QXmlAttributes &attributes);
	SuhubConfiguration suhubConfiguration;
	ArcherConfiguration archerConfiguration;
	AlarmConfiguration alarmConfiguration;
};

#endif /* CONFIGURATIONS_H_ */
