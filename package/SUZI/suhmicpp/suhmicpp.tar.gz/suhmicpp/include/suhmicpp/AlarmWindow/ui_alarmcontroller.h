/********************************************************************************
** Form generated from reading ui file 'alarmcontroller.ui'
**
** Created: Mon Oct 3 15:55:43 2011
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_ALARMCONTROLLER_H
#define UI_ALARMCONTROLLER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QTableView>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AlarmController
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QTableView *tableView;
    QHBoxLayout *buttonLayout;

    void setupUi(QWidget *AlarmController)
    {
    if (AlarmController->objectName().isEmpty())
        AlarmController->setObjectName(QString::fromUtf8("AlarmController"));
    AlarmController->resize(1065, 535);
    verticalLayout_2 = new QVBoxLayout(AlarmController);
    verticalLayout_2->setSpacing(6);
    verticalLayout_2->setMargin(11);
    verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
    verticalLayout = new QVBoxLayout();
    verticalLayout->setSpacing(6);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    tableView = new QTableView(AlarmController);
    tableView->setObjectName(QString::fromUtf8("tableView"));
    tableView->setSelectionMode(QAbstractItemView::ExtendedSelection);
    tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

    verticalLayout->addWidget(tableView);

    buttonLayout = new QHBoxLayout();
    buttonLayout->setSpacing(6);
    buttonLayout->setObjectName(QString::fromUtf8("buttonLayout"));

    verticalLayout->addLayout(buttonLayout);


    verticalLayout_2->addLayout(verticalLayout);


    retranslateUi(AlarmController);

    QMetaObject::connectSlotsByName(AlarmController);
    } // setupUi

    void retranslateUi(QWidget *AlarmController)
    {
    AlarmController->setWindowTitle(QApplication::translate("AlarmController", "AlarmController", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(AlarmController);
    } // retranslateUi

};

namespace Ui {
    class AlarmController: public Ui_AlarmController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALARMCONTROLLER_H
