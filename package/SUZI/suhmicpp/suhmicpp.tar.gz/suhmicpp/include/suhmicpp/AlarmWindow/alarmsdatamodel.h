#ifndef ALARMSDATAMODEL_H
#define ALARMSDATAMODEL_H

#include <QAbstractTableModel>
#include <QVariant>
#include <QList>
#include <QStringList>

#include "../symbols/alarm_window.h"
#include "alarm.h"

class AlarmGroup;

class AlarmsDataModel : public QAbstractTableModel
{
    Q_OBJECT

public:
    typedef AlarmColumn::EType AlarmColumnType;
    explicit AlarmsDataModel(AlarmWindow::ColumnVector headerSet, QList<Alarm*> * alarmList, QObject *parent = 0);
    ~AlarmsDataModel();
    virtual int rowCount(const QModelIndex &parent) const;
    virtual int columnCount(const QModelIndex &parent) const;
    QVariant data(const QModelIndex &index, int role) const;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    void refresh();
    void sort(int column, Qt::SortOrder order);
    static AlarmColumnType getSortParam();
    QList<Alarm *> * getAlarmList();
    void callBeginInsertRows(int first, int last);
    void callEndInsertRows();
    void callBeginRemoveRows(int first, int last);
    void callEndRemoveRows();
    void callBeginResetModel();
    void callEndResetModel();


signals:

public slots:

 //   void setContainers(QList<Alarm*> alarms, QMap<int,AlarmGroup*> alarmGroups);
 //   void setActiveAlarms(QList<Alarm*> alarms);

private:
        void setHeaders(AlarmWindow::ColumnVector & headers);
        AlarmGroup * rootGroup;
        int activeColumns;
        QList<Alarm *> * alarms;
        void clearData();
        QStringList columnNames;
        QVariant getValueFromAlarmByName(Alarm *, AlarmColumn*) const;
        static AlarmColumnType sortParam;
        AlarmWindow::ColumnVector headers;
};

#endif // ALARMSDATAMODEL_H
