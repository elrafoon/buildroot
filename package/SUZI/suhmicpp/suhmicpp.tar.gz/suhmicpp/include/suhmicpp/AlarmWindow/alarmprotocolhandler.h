#ifndef CONNECTORHANDLER_H
#define CONNECTORHANDLER_H

#include <scl/reconnecting_handler.h>
#include <scl/prefixed_logger.h>
#include <boost/scoped_array.hpp>
#include <ace/Notification_Strategy.h>
#include <ace/Reactor_Notification_Strategy.h>
#include <ace/Message_Queue_T.h>
#include <auto_ptr.h>
#include "suhmicpp/util/prefixed_logger.h"

class AlarmController;

class Message{
public:
        std::string mess;
};

class AlarmProtocolHandler : public SuhubConnectorLight::ReconnectingHandler, protected PrefixedLogger
{

public:
        AlarmProtocolHandler(AlarmController * parent,ACE_Reactor * reactor, ACE_INET_Addr add, std::string reconnectCommand, std::string refreshCommand);
        virtual ~AlarmProtocolHandler();
        struct MyTimerType{
            enum TimerType{PERIOD, SINGLESHOT};
            TimerType type;
        };
        static MyTimerType singleShot;
        static MyTimerType period;
        void insertNewMessageToQue(std::string message);
        void setNewCommands(std::string describe, std::string refresh);

protected:
        int handle_input_connected(ACE_HANDLE);
        int handle_output_connected(ACE_HANDLE);
        int open(void *);
        int handle_timeout(const ACE_Time_Value & currentTime, const void * act);
        int handle_close(ACE_HANDLE fd, ACE_Reactor_Mask mask);
        void restartTimer();
        void cleanQueue();
        void clearMsqQueue();

private:
        AlarmController * parent;
        std::string currentCommand;
        std::string reconnectCommand;
        std::string refreshCommand;
        size_t curSendPos;
        size_t curGetPos;
        size_t curMessSize;
        size_t headerRead;
        size_t messageRead;
        ACE_Time_Value timeout;
        boost::scoped_array<uint8_t> message;
        long periodicalMessageTimerId;
        long acceptResultTimerId;
        ACE_Reactor * reactor;
        enum ESTate {S_SENDING_COMMAND,S_SEND_COMMAND, S_GET_COM_RESULT_SIZE, S_GET_COM_RESULT, S_GET_ERROR_SIZE,S_GET_ERROR, S_GET_ERROR_OR_COM_RESULT, S_WRITE_MESSAGE, S_GET_ACK} state;
        ACE_Message_Queue<ACE_NULL_SYNCH> messageQue;
        ACE_Notification_Strategy * notifStrategy;
};

#endif // CONNECTORHANDLER_H
