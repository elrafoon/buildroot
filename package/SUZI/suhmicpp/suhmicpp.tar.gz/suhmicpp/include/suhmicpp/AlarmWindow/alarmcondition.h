#ifndef ALARMCONDITION_H
#define ALARMCONDITION_H

#include <QObject>
#include <QTime>
#include <QDate>
#include <QMap>

class Alarm;

class AlarmCondition : public QObject
{
    Q_OBJECT
public:
    explicit AlarmCondition(QObject *parent = 0);
    AlarmCondition(QString condArg, QString desc, int hyster, bool hystRel, int id, QString condOp, bool overQual, int parentAlarmId, QString tagName, int value, Alarm *parentAlarm);
    void setActiveParam(bool fullfilled, int hystLastvalue, QTime updTime, QDate updDate);
    bool getHysteresisIsRelative();
    bool getOverideQuality();
    bool getFullfilled();
    int  getHysteresis();
    int  getId();
    int  getValue();
    int  getParentAlarmId();
    QString getConditionArgument();
    QString getDescription();
    QString getCondOperator();
    QString getTagName();
    QTime getTLatestUpdatetime();
    QDate getTLatestUpdateDate();
    Alarm * getParentAlarm();
    QString getConditionFormatted();

signals:

public slots:

private:
        QString conditionArgument;
        QString descrition;
        int hysteresis;
        bool hysteresisIsRelative;
        int id;
        QString condOperator;
        bool overideQuality;
        int parentAlarmId;
        QString tagName;
        int value;
        bool fullfilled;
        int hystLastvalue;
        QTime tLatestUpdateTime;
        QDate tLatestUpdateDate;
        Alarm * parentAlarm;

};

#endif // ALARMCONDITION_H
