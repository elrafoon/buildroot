#ifndef ALARM_H
#define ALARM_H

#include <QObject>
#include <QTime>
#include <QDate>
#include <QMap>
#include <QDebug>

class AlarmCondition;
class AlarmGroup;

class Alarm : public QObject
{
    Q_OBJECT
public:
    explicit Alarm(QObject *parent = 0);

    Alarm(bool autoAck, QString joinOp, QString desc, int id, QString name, int parentGroupId, int priority, AlarmGroup * parentGroup);
    void setActiveParam(int effectivePriority,QString state, QTime updTime, QDate updDate);

    ~Alarm();

    bool getAutoAck();
    int  getId();
    int  getParenGroupId();
    int  getPriority();
    int  geteffectivePriority();
    int  getAlarmStatusId();
    QString getConditionJoinOp();
    QString getDescription();
    QString getName();
    QString * getState();
    QTime getTLatestUpdateTime();
    QDate getTLatestUpdateDate();
    AlarmGroup * getParentGroup();
    void insertChildAlarmCond(int,AlarmCondition *);
    QString getConditionString();

signals:

public slots:

private:
        bool autoAck;
        QString conditionJoinOp;
        QString description;
        int id;
        QString name;
        int parentGroupId;
        int priority;
        int effectivePriority;
        QString * state;
        QTime tLatestUpdateTime;
        QDate tLatestUpdateDate;
        AlarmGroup * parentGroup;
        QMap<int,AlarmCondition *> childConditions;

};

#endif // ALARM_H
