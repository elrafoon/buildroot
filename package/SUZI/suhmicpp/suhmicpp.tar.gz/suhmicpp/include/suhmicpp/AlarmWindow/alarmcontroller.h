#ifndef ALARMCONTROLLER_H
#define ALARMCONTROLLER_H

#include <QWidget>
#include <ace/INET_Addr.h>
#include <ace/Reactor.h>
#include <QTimer>
#include <QStringList>
#include <QPushButton>
#include <QSet>
#include "ui_alarmcontroller.h"
#include "suhmicpp/symbols/alarm_window.h"
#include "suhmicpp/util/prefixed_logger.h"

class AlarmXMLParser;
class AlarmGroup;
class AlarmsDataModel;
class AlarmProtocolHandler;

namespace Ui {
class AlarmController;
}

class AlarmController:
		public QWidget {
Q_OBJECT

public:
	AlarmController(AlarmWindow::ColumnVector headers, std::vector<AlarmWindow::EButtonSet> buttons, ACE_INET_Addr add, AlarmWindowSource * source, uint8_t eFilter, int width, QWidget *parent = 0);
	~AlarmController();
	void rawDataPrepared(std::string s);

public slots:
	void dataParsed();
	void runReact();
	void refreshView();
private:
	void prepareButton(AlarmWindow::EButtonSet type);
	void prepareCommands(AlarmWindowSource* source);
	QString prepareFilters(uint8_t efilter);

	Ui::AlarmController *ui;
	AlarmXMLParser * parser;
	AlarmsDataModel * model;
	AlarmProtocolHandler * protHand;
	ACE_Reactor * reactor;
	QTimer timer;
	QTimer refreshTimer;
	QPushButton * ackAll;
	QPushButton * ackGroup;
	QPushButton * ackSelected;
	QPushButton * ackInactive;
	QString describeCommand;
	QString refreshCommand;
	QString filter;
	int id;
	AlarmWindowSource::ESource type;
	PrefixedLogger logger;

private slots:
	void ackAllClicked();
	void ackInactiveClicked();
	void ackGroupClicked();
	void ackSelectedClicked();
	void repairCommands(int rootId);
};

#endif // ALARMCONTROLLER_H
