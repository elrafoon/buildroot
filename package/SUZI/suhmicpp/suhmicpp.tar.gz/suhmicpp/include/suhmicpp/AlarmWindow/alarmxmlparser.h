#ifndef ALARMXMLPARSER_H
#define ALARMXMLPARSER_H

#include <QObject>
#include <QMap>
#include <QXmlStreamReader>
#include <QStringRef>
#include <QStringList>
#include <QTime>
#include <QDate>
#include "suhmicpp/util/prefixed_logger.h"

class AlarmGroup;
class Alarm;
class AlarmCondition;
class AlarmsDataModel;

class AlarmXMLParser : public QObject
{
    Q_OBJECT
public:
    explicit AlarmXMLParser(QObject *parent = 0);
    void parse(QString file);
    AlarmGroup * getRootGroup();
    void setAlarmFilter(int filter);
    QList<Alarm*> * getAlarmContainer();
    void setModel(AlarmsDataModel * model);
    ~AlarmXMLParser();

signals:
        void dataChanged();
        void alarmGroupNotPrepared(int groupId);

public slots:
private:
        QXmlStreamReader * reader;
        QMap<int,Alarm *> createdAlarmSructures;
        QMap<int,AlarmGroup *> createdAlarmGroupStructures;
        QMap<int,AlarmCondition *> createdConditionStructures;
        QList<Alarm * > nextAlarms;
        QList<Alarm * > activeAlarms;

        AlarmGroup * currentGroup;
        Alarm * currentAlarm;
        AlarmCondition * currentCond;

        enum READINGState { READ_STRUCTURE, READ_DATA};
        READINGState state;
        enum LASTRead{GROUP,ALARM,COND,GROUP_STATUS,ALARM_STATUS,COND_STATUS};
        LASTRead lastReadState;
        void readGroup();
        int readAlarm();
        void readCondition();
        void readGroupStatus();
        void readAlarmStatus();
        void readConditionStatus();
        void goUp();
        AlarmGroup * root;
        int rootGroupId;
        int alarmFilter;
        AlarmsDataModel * model;
        void clearData();
        void removeLostAlarms();
        void insertNewAlarms();
        PrefixedLogger logger;
};

#endif // ALARMXMLPARSER_H
