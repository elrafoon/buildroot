#ifndef ALARMGROUP_H
#define ALARMGROUP_H

#include <QObject>
#include <QMap>

class Alarm;

class AlarmGroup : public QObject
{
    Q_OBJECT

public:

    explicit AlarmGroup(QObject *parent = 0);
    AlarmGroup(bool autoAck, QString desc, int id, QString name, int parentId, AlarmGroup * parentGroup);
    void setActiveParam(QString worstAlarmEfPrio = "", QString worstAlarmId = "", QString worstAlarmState = "");
    int getAlarmsCount() const;
    QMap<int,Alarm *> * getAlarms();
    QMap<int,AlarmGroup *> * getChildGroups();
    bool getAutoAck();
    int  getParentGroupId();
    int  getPriority();
    QString  getWorstAlarmEffectivePriority();
    QString  getworstAlarmId();
    int  getId();
    QString getDescription();
    QString getName();
    QString getWorstAlarmState();
    AlarmGroup * getParentGroup();
    void insertChildGroup(int, AlarmGroup*);
    void insertChildAlarm(int, Alarm *);

signals:

public slots:

private:
        bool autoAck;
        QString description;
        int id;
        QString name;
        int parentGroupId;
        QString worstAlarmEfectivePriority;
        QString worstAlarmId;
        QString worstAlarmState;
        AlarmGroup * parentGroup;
        QMap<int, Alarm *> childAlarms;
        QMap<int, AlarmGroup *> childGroups;

};

#endif // ALARMGROUP_H
