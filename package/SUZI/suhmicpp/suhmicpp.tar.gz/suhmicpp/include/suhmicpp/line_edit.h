/*
 * line_edit.h
 *
 *  Created on: Jul 12, 2011
 *      Author: vlado
 */

/**
 * Widget pre zadavanie vstupu do ValueDisplay a Label.
 * QLineEdit, z ktoreho LineEdit dedi, umoznuje viacriadkovy vstup, kdezto vstup do ValueDisplay a Label je potvrdzovany
 * enterom. Tato trieda ma reimplementovanu funkciu keyPressEvent, ktora pri stlaceni Return alebo Enter emituje signal editingFinished.
 */
#ifndef LINE_EDIT_H_
#define LINE_EDIT_H_

#include <QLineEdit>
#include <QKeyEvent>

class LineEdit : public QLineEdit{
	Q_OBJECT
public:
	LineEdit(){};
	LineEdit(const LineEdit &lineEdit){}; // QLineEdit ma privatny copy constructor
	void keyPressEvent(QKeyEvent *e);
signals:
	void editingFinished();
	void cancelEditing();

};

#endif /* LINE_EDIT_H_ */
