/*
 * suzi_scene.h
 *
 *  Created on: Jun 28, 2010
 *      Author: vlado
 */

#ifndef SCENE_H_
#define SCENE_H_

#include <QObject>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <vector>
#include "suhmicpp/hmi.h"

class Scene : public QGraphicsScene
{
    Q_OBJECT
public:
    Scene(QObject *parent);
    void setHmi(Hmi &hmi);
    void setBgColor(QColor & bgColor);
private:
    std::vector<int> visualSymbols;
    void printTagList(TagList &taglist);
    void keyPressEvent(QKeyEvent * keyEvent);
    int okno;
    Hmi *hmi;
    //TagCache tagCache;
};

#endif /* SCENE_H_ */
