/*
 * object_base_adapt.h
 *
 *  Created on: Dec 15, 2010
 *      Author: vlado
 */

#ifndef OBJECT_BASE_ADAPT_H_
#define OBJECT_BASE_ADAPT_H_

#include <Python.h>
#include <iostream>
#include <map>
#include "suhmicpp/object_base.h"

class ObjectBaseAdapt{
public:
	ObjectBaseAdapt* getParent();
};
#endif /* OBJECT_BASE_ADAPT_H_ */
