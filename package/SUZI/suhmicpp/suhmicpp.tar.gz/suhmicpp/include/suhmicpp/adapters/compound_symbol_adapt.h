/*
 * compound_symbol_adapt.h
 *
 *  Created on: Oct 14, 2011
 *      Author: vlado
 */

#ifndef COMPOUND_SYMBOL_ADAPT_H_
#define COMPOUND_SYMBOL_ADAPT_H_

#include <string>
#include "suhmicpp/symbols/compound_symbol.h"
#include "symbol_adapt.h"

class CompoundSymbolAdapt : public SymbolAdapt{
public:
	typedef std::map<std::string, SymbolAdapt *> SymbolAdaptMap;
	CompoundSymbolAdapt(CompoundSymbol * cs);
	SymbolAdapt* getSymbol(std::string name);
	SymbolAdaptMap symbolAdapts;
};


#endif /* COMPOUND_SYMBOL_ADAPT_H_ */
