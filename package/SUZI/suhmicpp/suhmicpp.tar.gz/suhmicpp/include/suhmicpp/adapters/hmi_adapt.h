/*
 * hmi_adapt.h
 *
 *  Created on: Dec 7, 2010
 *      Author: vlado
 */

#ifndef HMI_ADAPT_H_
#define HMI_ADAPT_H_

#include <string>
#include <map>
#include "object_base_adapt.h"
#include "window_adapt.h"

class Hmi;

class HmiAdapt:
		public ObjectBaseAdapt {
private:
	Hmi *hmi;
	std::string color;
public:
	HmiAdapt();
	HmiAdapt* getParent();
	void setAdaptee(Hmi *hmi);
	std::string getRuntimePlatform();
	void setColor(std::string color);
	std::string getColor();
	WindowAdapt* getWindow(std::string name);
	WindowAdapt* getDefaultWindow();
	std::string getAppName();
	std::string getAppVersion();
	std::string getMadeFor();
	std::string getAuthor();
	std::string getCompany();
	std::string getDate();
	void exit();
	typedef std::map<std::string, WindowAdapt *> WindowMap;
	WindowMap windows;
};

#endif /* HMI_ADAPT_H_ */
