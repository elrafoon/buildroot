/*
 * symbol_adapt.h
 *
 *  Created on: Dec 13, 2010
 *      Author: vlado
 */

/** Adapter pre triedy Symbol a potomkov. Obsahuje implementacie API.
 */

#ifndef SYMBOL_ADAPT_H_
#define SYMBOL_ADAPT_H_

#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>

#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/symbols/static_label.h"
#include "suhmicpp/symbols/simple_visual_symbol.h"
#include "suhmicpp/symbols/arc.h"
#include "suhmicpp/symbols/label.h"
#include "suhmicpp/symbols/value_display.h"
#include "suhmicpp/symbols/line.h"
#include "suhmicpp/symbols/polygon.h"
#include "suhmicpp/symbols/polyline.h"
#include "suhmicpp/symbols/image.h"
#include "suhmicpp/symbols/timer.h"
#include "suhmicpp/font.h"
#include "object_base_adapt.h"

class CompoundSymbolAdapt;

class SymbolAdapt:
		public ObjectBaseAdapt {
public:
	explicit SymbolAdapt(Symbol * const symbol);

	void setWinParent(WindowAdapt *parent);
	void setCSParent(CompoundSymbolAdapt *parent);
	void getParent();
	WindowAdapt* getWinParent();
	CompoundSymbolAdapt* getCSParent();
	std::string getName();
	unsigned int getType();

	//Timer
	void setEnabled(bool enabled);

	// VisualSymbol
	float getRotation();
	void setRotation(float rotation);

	int getZOrder();
	void setZOrder(int zOrder);

	std::pair<int, int> getPosition();
	void setPosition(int x, int y);

	std::pair<int, int> getRotCenter();
	void setRotCenter(int x, int y);

	std::pair<int, int> getSize();
	void setSize(int width, int height);

	std::pair<float, float> getScale();
	void setScale(float x, float y);
	void setScale(float scale);

	void setVisibility(bool value);
	bool getVisibility();

	// SimpleVisualSymbol
	int getLineWidth();
	void setLineWidth(int lineWidth);

	void setFgColor(std::string color);
	std::string getFgColor();

	void setFgStyle(int style);
	int getFgStyle();

	void setBgColor(std::string color);
	std::string getBgColor();

	void setBgStyle(int style);
	int getBgStyle();

	//Arc
	void setAngleStart(int angleStart);
	int getAngleStart();

	void setAngleSize(int angleSize);
	int getAngleSize();

	bool setArcType(int arcType);
	int getArcType();

	//Line
	void setStart(int x, int y);
	void setEnd(int x, int y);

	//BaseLabel
	int getFontSize();
	void setFontSize(int size);

	int getFontName();
	bool setFontName(int fontName);

	int getFontStyle();
	bool setFontStyle(int fontStyle);

	int getAlignment();
	bool setAlignment(int alignment);

	//Label & ValueDisplay
	bool getWriteEnabled();
	void setWriteEnabled(bool enabled);

	std::string getText();
	void setText(std::string text);

	//Image
	int getExtension();

	SymbolAdapt* getSymbol(std::string name);
	bool isInCS();
private:
	Symbol *symbol;
	WindowAdapt *parent;
	CompoundSymbolAdapt *CSParent;
};

#endif /* SYMBOL_ADAPT_H_ */
