/*
 * window_adapt.h
 *
 *  Created on: Dec 9, 2010
 *      Author: vlado
 */

#ifndef WINDOW_ADAPT_H_
#define WINDOW_ADAPT_H_

#include <map>
#include <string>
#include "../window/window.h"
#include "symbol_adapt.h"
#include "compound_symbol_adapt.h"
#include "object_base_adapt.h"

/*class Print {
public:
	enum Size {
		A0 = 0, A1 = 1, A2 = 2, A3 = 3, A4 = 4, A5 = 5
	};
	enum Orientation {
		PORTRAIT = 0, LANDSCAPE = 1
	};
};
*/
class WindowAdapt:
		public ObjectBaseAdapt {
public:
	typedef std::map<std::string, SymbolAdapt *> SymbolMap;
	WindowAdapt();
	void setAdaptee(Window *window);
	void setName(std::string name);

	void setParent(HmiAdapt *parent);
	HmiAdapt* getParent();
	SymbolAdapt* getSymbol(std::string name);
	std::string getName();
	int getType();

	std::string getBgColor();
	void setBgColor(std::string color);

	std::pair<int, int> getSize();
	void setSize(int width, int height);

	std::pair<int, int> getPosition();
	void setPosition(int x, int y);

	void setVisibility(bool value);
	bool getVisibility();

	void printScreen(std::string fullFfileName);
	void hardCopy(std::string printerName, int size = 4, int orientation = 1, bool fitToPage = true);
	SymbolMap symbols;
private:
	Window *window;
	HmiAdapt *parent;
};

#endif /* WINDOW_ADAPT_H_ */
