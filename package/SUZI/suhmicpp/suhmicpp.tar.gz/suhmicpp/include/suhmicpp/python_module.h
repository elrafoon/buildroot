/*
 * python_module.h
 *
 *  Created on: Aug 24, 2011
 *      Author: vlado
 */

#ifndef PYTHON_MODULE_H_
#define PYTHON_MODULE_H_

#include <string>
#include <QXmlAttributes>
#include <QString>
#include <QByteArray>
#include "suhmicpp/util/prefixed_logger.h"

class PythonModule : protected PrefixedLogger{
public:
	PythonModule(const QXmlAttributes &attributes);
	int setBytes(std::string &bytes);
	std::string path;
};

#endif /* PYTHON_MODULE_H_ */
