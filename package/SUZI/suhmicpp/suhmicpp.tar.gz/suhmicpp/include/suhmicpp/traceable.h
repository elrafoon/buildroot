/*
 * traceable.h
 *
 *  Created on: Sep 7, 2011
 *      Author: vlado
 */

#ifndef TRACEABLE_H_
#define TRACEABLE_H_

#include <string>
#include <vector>

class Traceable {
public:
	typedef std::vector<std::string> VectorOfStrings;
	Traceable();
	Traceable(std::string &identification);
	Traceable(const Traceable & traceable);
	virtual ~Traceable();
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
	std::string getPathString();
	VectorOfStrings debugInfo; // nadradene prvky
	std::string identification; // vlastna identifikacia
};

#endif /* TRACEABLE_H_ */
