#include <QString>
#include "link.h"

#ifndef SIZELINK_H_
#define SIZELINK_H_

class VisualSymbol;

class VerticalSizeLink : public Link{
	Q_OBJECT
public:
	VerticalSizeLink(VisualSymbol *vs);
	VerticalSizeLink(const VerticalSizeLink &vsl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void vertSizeChanged(long newValue);

};

class HorizontalSizeLink : public Link{
	Q_OBJECT
public:
	HorizontalSizeLink(VisualSymbol *vs);
	HorizontalSizeLink(const HorizontalSizeLink &hsl, VisualSymbol *vs);
	void handleResult(double result);
signals:
		void horSizeChanged(long newValue);
};

#endif /* SIZELINK_H_ */
