
#ifndef BLINKLINK_H_
#define BLINKLINK_H_


#include <QObject>
#include <QColor>
#include <QXmlAttributes>
#include "link.h"
#include "../code.h"

class BlinkLink : public Link{
	Q_OBJECT
public:
	explicit BlinkLink(VisualSymbol *vs);
	BlinkLink(const BlinkLink &bl, VisualSymbol *vs);
	virtual ~BlinkLink(){}
	void setAttributes(const QXmlAttributes &attributes);
	void handleResult(bool result);
	virtual void handleTimeout() = 0;
	float period;
	QColor blinkColor;
protected:
	int ticks;
	bool blink;
signals:
	void blinkChanged();
};

class BgBlinkLink : public BlinkLink{
	Q_OBJECT
public:
	explicit BgBlinkLink(VisualSymbol *vs);
	~BgBlinkLink();
	BgBlinkLink(const BgBlinkLink &bbl, VisualSymbol *vs);
	void handleTimeout();
};

class FgBlinkLink : public BlinkLink{
	Q_OBJECT
public:
	explicit FgBlinkLink(VisualSymbol *vs);
	FgBlinkLink(const FgBlinkLink &fbl, VisualSymbol *vs);
	~FgBlinkLink();
	void handleTimeout();
};

#endif /* BLINKLINK_H_ */
