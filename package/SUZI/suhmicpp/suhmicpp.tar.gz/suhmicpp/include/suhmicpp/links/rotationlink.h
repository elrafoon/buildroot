#ifndef ROTATIONLINK_H_
#define ROTATIONLINK_H_

#include <QString>
#include <QXmlAttributes>
#include "link.h"

class VisualSymbol;

class RotationLink : public Link{
	Q_OBJECT
public:
	RotationLink(VisualSymbol *vs);
	RotationLink(const RotationLink &rl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void rotationChanged(long newValue);

};

#endif /* ROTATIONLINK_H_ */
