#ifndef VISIBILITYLINK_H_
#define VISIBILITYLINK_H_

#include "link.h"

class VisualSymbol;

class VisibilityLink : public Link{
	Q_OBJECT
public:
	VisibilityLink(VisualSymbol *vs);
	VisibilityLink(const VisibilityLink &vl, VisualSymbol *vs);
	void handleResult(bool result);
signals:
	void visibilityChanged(bool visible);

};

#endif /* VISIBILITYLINK_H_ */
