/*
 * filllink.h
 *
 *  Created on: Oct 1, 2010
 *      Author: vlado
 */

#ifndef FILLLINK_H_
#define FILLLINK_H_

#include <QString>
#include "link.h"

class VisualSymbol;

class HorizontalFillLink : public Link{
	Q_OBJECT
public:
	HorizontalFillLink(VisualSymbol *vs);
	HorizontalFillLink(const HorizontalFillLink &hfl, VisualSymbol *vs = NULL);
	void handleResult(double result);

signals:
	void horFillChanged(long newValue);
};

class VerticalFillLink : public Link{
	Q_OBJECT
public:
	VerticalFillLink(VisualSymbol *vs);
	VerticalFillLink(const VerticalFillLink &vfl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void vertFillChanged(long newValue);

};


#endif /* FILLLINK_H_ */
