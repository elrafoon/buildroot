/*
 * link.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef LINK_H_
#define LINK_H_

#include <QXmlAttributes>
#include "../bound_expression.h"
#include "../result_listener.h"
#include "../traceable.h"

class VisualSymbol;

class Link:
		public QObject,
		public ResultListener,
		public Traceable {
	Q_OBJECT
public:
	Link(VisualSymbol *vs);
	Link(const Link &l);
	Link(const Link &l, VisualSymbol *vs);
	virtual ~Link() {
	}

	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
	BoundExpression boundExpression;
	std::string identification;
protected:
	VisualSymbol *vs;
};

#endif /* LINK_H_ */
