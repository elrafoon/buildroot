/*
 * colorlink.h
 *
 *  Created on: Sep 28, 2010
 *      Author: vlado
 */

#ifndef COLORLINK_H_
#define COLORLINK_H_

#include <string>
#include "link.h"
#include "suhmicpp/lists/range_value_list.h"

class VisualSymbol;

class ColorLink : public Link{
	Q_OBJECT
public:
	ColorLink(VisualSymbol *vs);
	ColorLink(const ColorLink &cl, VisualSymbol *vs);
	virtual void handleResult(double result) = 0;
	RangeValueList colorTable;
};

class FgColorLink : public ColorLink{
	Q_OBJECT
public:
	FgColorLink(VisualSymbol *vs);
	FgColorLink(const FgColorLink &fcl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void fgColorChanged(std::string newValue);
};

class BgColorLink : public ColorLink{
	Q_OBJECT
public:
	BgColorLink(VisualSymbol *vs);
	BgColorLink(const BgColorLink &bcl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void bgColorChanged(std::string newValue);
};


#endif /* COLORLINK_H_ */
