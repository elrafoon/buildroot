/*
 * positionlink.h
 *
 *  Created on: Sep 30, 2010
 *      Author: vlado
 */

#ifndef POSITIONLINK_H_
#define POSITIONLINK_H_

#include <QString>
#include "link.h"

class VisualSymbol;

class HorizontalPositionLink : public Link{
	Q_OBJECT
public:
	HorizontalPositionLink(VisualSymbol *vs);
	HorizontalPositionLink(const  HorizontalPositionLink &hpl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void horPositionChanged(long newValue);
};

class VerticalPositionLink : public Link{
	Q_OBJECT
public:
	VerticalPositionLink(VisualSymbol *vs);
	VerticalPositionLink(const VerticalPositionLink &vpl, VisualSymbol *vs);
	void handleResult(double result);
signals:
	void vertPositionChanged(long newValue);
};


#endif /* POSITIONLINK_H_ */
