/*
 * value_link.h
 *
 *  Created on: Oct 25, 2010
 *      Author: vlado
 */

#ifndef VALUE_LINK_H_
#define VALUE_LINK_H_

#include <QObject>
#include <QString>
#include "scl/hlapi/update_listener.h"
#include "suhmicpp/symbols/visual_symbol.h"

class ValueLink:
		public QObject,
		public SuhubConnectorLight::UpdateListener {
	Q_OBJECT
public:
	ValueLink(VisualSymbol *vs);
	ValueLink(const ValueLink &vl, VisualSymbol *vs);
	void setTag(SuhubConnectorLight::StatefulTag *tag);
	void onUpdate(const SuhubConnectorLight::UpdateList &updateList);
	SuhubConnectorLight::StatefulTag *tag;
private:
	VisualSymbol *vs;
signals:
	void valueChanged(double value);

};

#endif /* VALUE_LINK_H_ */
