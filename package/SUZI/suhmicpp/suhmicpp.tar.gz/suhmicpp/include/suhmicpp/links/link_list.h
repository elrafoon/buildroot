/*
 * link_list.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef LINK_LIST_H_
#define LINK_LIST_H_

#include <map>
#include "blinklink.h"
#include "colorlink.h"
#include "filllink.h"
#include "positionlink.h"
#include "rotationlink.h"
#include "sizelink.h"
#include "visibilitylink.h"
#include "../traceable.h"

class VisualSymbol;

class LinkList : public Traceable{
public:
	LinkList(VisualSymbol *vs);
	LinkList(const LinkList &ll, VisualSymbol* vs);
	void replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable);
	void compileCodes();
	void setSymbolSelf(SymbolAdapt* self);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
	BgBlinkLink bgBlinkLink;
	FgBlinkLink fgBlinkLink;
	BgColorLink bgColorLink;
	FgColorLink fgColorLink;
	HorizontalFillLink horizontalFillLink;
	HorizontalPositionLink horizontalPositionLink;
	HorizontalSizeLink horizontalSizeLink;
	RotationLink rotationLink;
	VerticalFillLink verticalFillLink;
	VerticalSizeLink verticalSizeLink;
	VerticalPositionLink verticalPositionLink;
	VisibilityLink visibilityLink;
};

#endif /* LINK_LIST_H_ */
