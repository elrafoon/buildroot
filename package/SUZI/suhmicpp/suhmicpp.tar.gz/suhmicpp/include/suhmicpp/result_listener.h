/*
 * result_listener.h
 *
 *  Created on: Oct 22, 2010
 *      Author: vlado
 */

#ifndef RESULT_LISTENER_H_
#define RESULT_LISTENER_H_

class ResultListener {
public:
	ResultListener() {
	}
	virtual ~ResultListener() {
	}

	explicit ResultListener(const ResultListener &rl) :
		resultType(rl.resultType) {
	}
	virtual void handleResult(double result) {
	}
	virtual void handleResult(bool result) {
	}
	virtual void handleResult(std::string result) {
	}
	enum ResultType {
		BOOL_INT, INT_DOUBLE, PERC, STRING
	};
	ResultType resultType;
};

#endif /* RESULT_LISTENER_H_ */
