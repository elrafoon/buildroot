/*
 * suzi_xml_handler.h
 *
 *  Created on: Jul 6, 2010
 *      Author: vlado
 */

#ifndef XML_READER_H_
#define XML_READER_H_

#include <QXmlDefaultHandler>
#include <QString>
#include <QColor>
#include <utility>
#include <assert.h>
#include <stack>
#include "suhmicpp/hmi.h"
#include "suhmicpp/util/prefixed_logger.h"
#include "suhmicpp/events/event.h"
#include "suhmicpp/lists/tag_list.h"
#include "suhmicpp/lists/generic_script_list.h"
#include "suhmicpp/generic_script.h"
#include "suhmicpp/script.h"
#include "suhmicpp/symbols/compound_symbol.h"
#include "suhmicpp/lists/compound_symbol_list.h"
#include "suhmicpp/symbols/compound_symbol_template.h"
#include "suhmicpp/lists/symbol_list.h"
#include "suhmicpp/symbols/visual_symbol.h"
#include "suhmicpp/code.h"
#include "suhmicpp/bound_expression.h"
#include "suhmicpp/lists/range_value_list.h"
#include "suhmicpp/range_value.h"
#include "suhmicpp/graph/online_graph.h"
#include "suhmicpp/graph/online_graph_pen.h"
#include "suhmicpp/configurations/configurations.h"
#include "suhmicpp/configurations/suhub_configuration.h"
#include "suhmicpp/python_module.h"
#include "suhmicpp/symbols/alarm_window.h"
#include "suhmicpp/symbols/timer.h"

class Handler:
		public QXmlDefaultHandler, public PrefixedLogger {
public:
	// TODO(vlado): v tomto liste by mali byt vsetky objekty typu UpdateListener, lenze na tychto objektoch sa vola registerListener
	//		 co ma vyznam signalu aby sa oni zaregistrovali ako UpdateListener, treba to premenovat aby to davalo zmysel
	typedef std::list<BoundExpression *> BoundExpressionsPtrs;
	typedef std::list<Script *> ScriptPtrs;
	typedef std::list<OnlineGraphPen *> PenPtrs;
	typedef std::list<ValueLink *> ValueLinkPtrs;

	BoundExpressionsPtrs boundExpressionsPtrs;
	ScriptPtrs scriptPtrs;
	PenPtrs penPtrs;
	ValueLinkPtrs valueLinkPtrs;

	Handler();
	~Handler();
	bool startElement(const QString &namespaceURI, const QString &localName, const QString &qName, const QXmlAttributes &attributes);
	bool endElement(const QString &namespaceURI, const QString &localName, const QString &qName);
	bool characters(const QString &str);
	bool fatalError(const QXmlParseException &exception);
	bool error(const QXmlParseException & exception);
	QString errorString() const;
	Hmi *getHmi();
	void initRect(const QXmlAttributes & attributes);
private:
	template<typename TSymbol>
	TSymbol *createVisualSymbol(const QXmlAttributes &attributes) {
		TSymbol *symbol = new TSymbol(attributes);
		Symbol *s = static_cast<Symbol*> (symbol);
		currentCompoundSymbolTemplate->symbol.push_back(s);
		currentSymbol = s;
		currentSymbol->obType |= SYMBOL;
		return symbol;
	};

	typedef std::map<std::string, SuhubConnectorLight::StatefulTag *> ReplacementTable;
	typedef std::pair<std::string, SuhubConnectorLight::StatefulTag *> ReplacementTablePair;
	typedef std::vector<SuhubConnectorLight::StatefulTag *> StatefulTagVector;
	int i;
	char buff[21];

	/*currentTagList(NULL),
	 currentGenericScriptList(NULL),
	 currentGenericScript(NULL),
	 currentScript(NULL),
	 currentCompoundSymbolTemplate(NULL),
	 currentCompoundSymbol(NULL),
	 currentCompoundSymbolList(NULL),
	 currentSymbolList(NULL),
	 currentPair(NULL),
	 currentReplacementTable(NULL),
	 currentLink(NULL),
	 currentLinkList(NULL),
	 currentBoundExpression(NULL),
	 currentBgBlinkLink(NULL),
	 currentFgBlinkLink(NULL),
	 currentBgColorLink(NULL),
	 currentFgColorLink(NULL),
	 currentHorizontalFillLink(NULL),
	 currentVerticalFillLink(NULL),
	 currentHorizontalPositionLink(NULL),
	 currentVerticalPositionLink(NULL),
	 currentHorizontalSizeLink(NULL),
	 currentVerticalSizeLink(NULL),
	 currentRotationLink(NULL),
	 currentVisibilityLink(NULL),
	 currentHandlerCode(NULL),
	 currentRangeValueList(NULL) {
	 */

	struct find_by_name:
			public std::binary_function<const SuhubConnectorLight::StatefulTag *, const std::string&, bool> {
		double operator()(const SuhubConnectorLight::StatefulTag * tag, const std::string &name) const {
			return tag->name.compare(name) == 0;
		}
	};

	void setSubstitutionTag(std::string & oldName, std::string & newName);
	Hmi hmi;
	WindowList *currentWindowList;
	Window *currentWindow;
	Symbol *currentSymbol;
	Event *currentEvent;
	Link *currentLink;
	LinkList *currentLinkList;
	RangeValueList *currentRangeValueList;

	BoundExpression *currentBoundExpression;
	BlinkLink *currentBgBlinkLink;
	BlinkLink *currentFgBlinkLink;
	BgColorLink *currentBgColorLink;
	FgColorLink *currentFgColorLink;
	HorizontalFillLink *currentHorizontalFillLink;
	VerticalFillLink *currentVerticalFillLink;
	HorizontalPositionLink *currentHorizontalPositionLink;
	VerticalPositionLink *currentVerticalPositionLink;
	RotationLink *currentRotationLink;
	HorizontalSizeLink *currentHorizontalSizeLink;
	VerticalSizeLink *currentVerticalSizeLink;
	VisibilityLink *currentVisibilityLink;

	TagList *currentTagList;
	GenericScriptList *currentGenericScriptList;
	GenericScript *currentGenericScript;
	Script *currentScript;
	CompoundSymbolTemplate *currentCompoundSymbolTemplate;
	CompoundSymbol * currentCompoundSymbol;
	CompoundSymbolList *currentCompoundSymbolList;
	SymbolList *currentSymbolList;
	Code *currentHandlerCode;
	OnlineGraph *currentOnlineGraph;
	OnlineGraphPen *currentOnlineGraphPen;
	Configurations *currentConfigurations;
	PythonModule *currentPythonModule;
	AlarmWindow *currentAlarmWindow;
	Timer *currentTimer;
	enum TagListType {
		in, out, sensitivity
	};
	TagListType tagListType;

	ReplacementTablePair *currentPair;
	ReplacementTable *currentReplacementTable;
	enum ReplacementState {
		OUT, KEY, VALUE
	} replacementState;
	bool isKey;
	//map<QString, VisualSymbol *> compoundTemplates;
};

#endif /* XML_READER_H_ */
