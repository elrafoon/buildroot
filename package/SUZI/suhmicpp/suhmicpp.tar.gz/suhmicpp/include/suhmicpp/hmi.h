/*
 * hmi.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#ifndef HMI_H_
#define HMI_H_

#include <QObject>
#include <QTimer>
#include <QColor>
#include <set>
#include "object_base.h"
#include "suhmicpp/window/window_list.h"
#include "suhmicpp/lists/compound_symbol_list.h"
#include "suhmicpp/links/blinklink.h"
#include "suhmicpp/adapters/hmi_adapt.h"
#include "scl/hlapi/stateful_ifc.h"
#include "suhmicpp/configurations/configurations.h"

class Scene;

class Hmi: public QObject, public ObjectBase {
	Q_OBJECT;
public:
	typedef std::set<BlinkLink *> BlinkLinksSet;
	Hmi();
	void setAttributes(const QXmlAttributes &attr);
	void setConfigurations(const QXmlAttributes &attributes);
	void create();
	void destroy();
	void fini();
	void exitApp();
	//int h;
	QColor bgColor;
	WindowList windowList;
	CompoundSymbolList compoundSymbolList;
	TagList tagList;
	TagList rTagList;
	TagList wTagList;
	BlinkLinksSet blinkLinks;
	Scene *scene;

	Configurations configurations;
	std::string appName;
	std::string appVersion;
	std::string madeFor;
	std::string author;
	std::string company;
	std::string date;

public slots:
	void hadleTimeout();
protected:
	QTimer blinkTimer;
};

#endif /* HMI_H_ */
