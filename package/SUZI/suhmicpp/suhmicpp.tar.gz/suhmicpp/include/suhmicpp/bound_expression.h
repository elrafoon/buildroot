/*
 * bound_expression.h
 *
 *  Created on: Sep 30, 2010
 *      Author: vlado
 */

#ifndef BOUND_EXPRESSION_H_
#define BOUND_EXPRESSION_H_

#include <QObject>
#include <QXmlAttributes>
#include "suhmicpp/lists/tag_list.h"
#include "expression.h"
#include "scl/hlapi/update_listener.h"
#include "suhmicpp/util/prefixed_logger.h"

class ResultListener;

class BoundExpression : public QObject, public SuhubConnectorLight::UpdateListener, protected PrefixedLogger{
public:
	BoundExpression(ObjectBase *ob, ResultListener *resultListener);
	explicit BoundExpression(const BoundExpression &be);
	BoundExpression(const BoundExpression &be,ObjectBase *ob, ResultListener *resultListener);
	void onUpdate(const SuhubConnectorLight::UpdateList &updateList);
	void setAttributes(const QXmlAttributes &attributes);
	void replaceTags(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable);
	void fini();
	TagList inputList;
	TagList sensitivityList;
	Expression expression;
private:
	ResultListener *resultListener;
};

#endif /* BOUND_EXPRESSION_H_ */
