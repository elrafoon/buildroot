/*
 * window_list.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#ifndef WINDOW_LIST_H_
#define WINDOW_LIST_H_

#include <vector>
#include <QString>
#include "window.h"

class WindowList {
public:
	typedef std::vector<Window *> WindowVector;
	WindowList();
	~WindowList();
	void create();
	void destroy();
	void fini();
	void setAttributes(const QXmlAttributes &attributes);
	unsigned int windowIndex;
	WindowVector windows;
	std::string defaultWindow;
};

#endif /* WINDOW_LIST_H_ */
