/*
 * window.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#ifndef WINDOW_H_
#define WINDOW_H_

#include <QString>
#include <QXmlAttributes>
#include <QSize>
#include <QGraphicsItem>
#include <QGraphicsScene>
#include "suhmicpp/lists/symbol_list.h"
#include "suhmicpp/object_base.h"
#include "suhmicpp/events/onshow.h"
#include "suhmicpp/events/onhide.h"
#include "suhmicpp/symbols/alarm_window.h"
#include "suhmicpp/traceable.h"
#include "suhmicpp/util/prefixed_logger.h"

class Window:
		public ObjectBase,
		public Traceable,
		public QGraphicsItem {
public:
	enum Size {
		A0 = 0, A1 = 1, A2 = 2, A3 = 3, A4 = 4, A5 = 5
	};
	enum Orientation {
		PORTRAIT = 0, LANDSCAPE = 1
	};

	typedef std::vector<AlarmWindow *> AlarmWindowVector;
	Window(const QXmlAttributes &attributes);
	~Window();
	void setSize(const QXmlAttributes &attributes);
	void setSize(const int widht, const int height);
	void create();
	void destroy();
	void show();
	void hide();
	QRectF boundingRect() const;
	void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
	void setVisibility(bool value);
	bool getVisibility();
	void fini();
	void printScreen(std::string fullFfileName);
	void hardCopy(std::string printerName, int size, int orientation, bool fitToPage);
	SymbolList symbolList;
	OnShow onshow;
	OnHide onhide;
	QSize size;
	QColor bgColor;
	std::string name;
	AlarmWindowVector alarmWindows;
private:
	PrefixedLogger logger;
};

#endif /* WINDOW_H_ */
