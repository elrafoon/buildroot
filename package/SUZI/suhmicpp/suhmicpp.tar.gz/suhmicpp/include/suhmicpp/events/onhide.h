/*
 * onhide.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef ONHIDE_H_
#define ONHIDE_H_

#include "event.h"

class OnHide : public Event {
public:
	OnHide(ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};

#endif /* ONHIDE_H_ */
