/*
 * onshow.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef ONSHOW_H_
#define ONSHOW_H_

#include "event.h"

class OnShow : public Event {
public:
	OnShow(ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};

#endif /* ONSHOW_H_ */
