/*
 * ondestroy.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef ONDESTROY_H_
#define ONDESTROY_H_

#include "event.h"

class OnDestroy : public Event {
public:
	OnDestroy(ObjectBase *ob);
	OnDestroy(const OnDestroy &od, ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};

#endif /* ONDESTROY_H_ */
