/*
 * onclick.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef ONCLICK_H_
#define ONCLICK_H_

#include "event.h"

class OnClick : public Event {
public:
	OnClick(ObjectBase *ob);
	OnClick(const OnClick &oc, ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};

#endif /* ONCLICK_H_ */
