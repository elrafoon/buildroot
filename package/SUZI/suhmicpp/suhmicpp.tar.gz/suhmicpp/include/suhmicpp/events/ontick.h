/*
 * ontick.h
 *
 *  Created on: Sep 10, 2011
 *      Author: vlado
 */

#ifndef ONTICK_H_
#define ONTICK_H_

#include "event.h"

class OnTick : public Event {
public:
	typedef std::vector<std::string> VectorOfStrings;
	OnTick(ObjectBase *ob);
	OnTick(const OnTick &ot, ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};


#endif /* ONTICK_H_ */
