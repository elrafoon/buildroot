/*
 * onchange.h
 *
 *  Created on: Jan 18, 2011
 *      Author: vlado
 */

#ifndef ONCHANGE_H_
#define ONCHANGE_H_

#include <string>
#include "event.h"

class OnChange : public Event {
public:
	OnChange(ObjectBase *ob);
	void exec(std::string &newText);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};

#endif /* ONCHANGE_H_ */
