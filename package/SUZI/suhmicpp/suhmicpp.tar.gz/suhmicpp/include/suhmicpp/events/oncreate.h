/*
 * oncreate.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef ONCREATE_H_
#define ONCREATE_H_

#include "event.h"

class OnCreate : public Event{
public:
	OnCreate(ObjectBase *ob);
	OnCreate(const OnCreate &oc, ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
};

#endif /* ONCREATE_H_ */
