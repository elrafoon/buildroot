/*
 * event.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef EVENT_H_
#define EVENT_H_

#include <QString>
#include <string>
#include "suhmicpp/lists/tag_list.h"
#include "../code.h"
#include "../traceable.h"

class Event : public Traceable{
public:
	explicit Event(ObjectBase *ob);
	Event(const Event &e, ObjectBase *ob);
	void setReplacementTable(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable);
	int exec();
	void fini();
	TagList inputList;
	TagList outputList;
	Code handlerCode;
};

#endif /* EVENT_H_ */
