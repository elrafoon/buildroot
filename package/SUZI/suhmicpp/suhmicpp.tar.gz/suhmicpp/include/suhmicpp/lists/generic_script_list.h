/*
 * generic_script_list.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef GENERIC_SCRIPT_LIST_H_
#define GENERIC_SCRIPT_LIST_H_

#include <vector>
#include <string>
#include "suhmicpp/generic_script.h"
#include "suhmicpp/traceable.h"

class ObjectBase;

class GenericScriptList : public Traceable{
public:
	typedef std::vector<GenericScript *> GenericScriptVector;
	GenericScriptList(ObjectBase *ob);
	GenericScriptList(const GenericScriptList &gsl, ObjectBase *ob);
	void setReplacementTable(std::map<std::string, SuhubConnectorLight::StatefulTag *> &replacementTable);
	void compileCodes();
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
	std::vector<GenericScript *> genericScript;
	ObjectBase *ob;
};

#endif /* GENERIC_SCRIPT_LIST_H_ */
