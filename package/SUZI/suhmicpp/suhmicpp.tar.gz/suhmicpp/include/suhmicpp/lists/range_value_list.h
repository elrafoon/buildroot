/*
 * range_value_list.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef RANGE_VALUE_LIST_H_
#define RANGE_VALUE_LIST_H_

#include <vector>
#include "suhmicpp/range_value.h"

class RangeValueList {
public:
	RangeValueList();
	typedef std::vector<RangeValue *> RangeValueVector;
	std::vector<RangeValue *> rangeValueItem;
};

#endif /* RANGE_VALUE_LIST_H_ */
