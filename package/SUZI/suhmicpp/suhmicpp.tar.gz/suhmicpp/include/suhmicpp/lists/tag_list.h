/*
 * tag_list.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef TAG_LIST_H_
#define TAG_LIST_H_

#include <QString>
#include <vector>
#include <string>
#include <functional>
#include "scl/hlapi/stateful_ifc.h"

class TagList {
public:
	TagList() {
	}
	TagList(const TagList &tl);
	typedef std::vector<SuhubConnectorLight::StatefulTag *> StatefulTagVector;
	struct find_by_name:
			public std::binary_function<const SuhubConnectorLight::StatefulTag *, const std::string&, bool> {
		double operator()(const SuhubConnectorLight::StatefulTag * tag, const std::string &name) const {
			return tag->name.compare(name) == 0;
		}
	};
	SuhubConnectorLight::StatefulTag* findTagByName(std::string &name);
	SuhubConnectorLight::StatefulTag* uniquePush(std::string tagName, bool internal = false);
	void uniquePush(SuhubConnectorLight::StatefulTag * tag);
	void eraseTemplateTags();
	void printTags();
	struct isTemplateTag {
		bool operator()(const SuhubConnectorLight::StatefulTag* const tag) const {
			if (tag->name[0] == '?') {
				return true;
			} else
				return false;
		}
	};
	StatefulTagVector tags;
};

#endif /* TAG_LIST_H_ */
