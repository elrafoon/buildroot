#ifndef COMPOUND_SYMBOL_LIST_H_
#define COMPOUND_SYMBOL_LIST_H_

#include <vector>
#include "suhmicpp/symbols/compound_symbol_template.h"

class CompoundSymbolList {
public:
	typedef std::vector<CompoundSymbolTemplate *> CompoundSymbolTemplateVector;
	CompoundSymbolList();
	void deleteTemplates();
	CompoundSymbolTemplateVector compoundSymbol;
};

#endif /* COMPOUND_SYMBOL_LIST_H_ */
