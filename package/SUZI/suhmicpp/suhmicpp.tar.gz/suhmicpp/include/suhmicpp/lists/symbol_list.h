/*
 * symbol_list.h
 *
 *  Created on: Jul 7, 2010
 *      Author: vlado
 */

#ifndef SYMBOL_LIST_H_
#define SYMBOL_LIST_H_

#include <vector>
#include "suhmicpp/symbols/symbol.h"
#include "suhmicpp/traceable.h"

class SymbolList: public Traceable{
public:
	SymbolList();
	~SymbolList();
	void create();
	void destroy();
	void show();
	void hide();
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);

	typedef std::vector<Symbol *> SymbolVector;
	SymbolVector symbol;
};
#endif /* SYMBOL_LIST_H_ */
