/*
 * distributor.h
 *
 *  Created on: Feb 8, 2011
 *      Author: vlado
 */

#ifndef DISTRIBUTOR_H_
#define DISTRIBUTOR_H_

#include <QtGui>
#include "suhmicpp/bound_expression.h"
#include "suhmicpp/script.h"

class OnUpdateEvent : public QEvent{
public:
	OnUpdateEvent(SConnector::UpdateList *p_updateList);
	SConnector::UpdateList *p_updateList;
};

class Distributor : public QObject, public SConnector::UpdateListener{
public:
	typedef std::list<BoundExpression *> BoundExpressionsPtrs;
	typedef std::list<Script *> ScriptPtrs;

	BoundExpressionsPtrs boundExpressionsPtrs;
	ScriptPtrs scriptPtrs;

	typedef std::set<SConnector::UpdateListener *> ListenerSet;
	ListenerSet listenerSet;
	Distributor(QApplication *app);
	void addListener(UpdateListener *);
	void addBoundExpression(BoundExpression *boundExpression);
	void addScript(Script *script);
	void setBoundExpressions(BoundExpressionsPtrs &boundExpressionsPtrs);
	void setScripts(ScriptPtrs &scriptPtrs);
	bool event(QEvent *e);

	int onUpdate(SConnector::UpdateList *p_updateList);
private:
	QApplication *app;
};

#endif /* DISTRIBUTOR_H_ */
