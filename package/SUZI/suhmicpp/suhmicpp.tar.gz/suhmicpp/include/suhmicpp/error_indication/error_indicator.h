/*
 * error_indicator.h
 *
 *  Created on: Sep 26, 2011
 *      Author: vlado
 */

/** Abstraktna trieda pre indikaciu chyb v aplikacii.
 * Je urcena pre logger dediaci z ACE_Log_Msg.
 */

#ifndef ERROR_INDICATOR_H_
#define ERROR_INDICATOR_H_

#include "ace/Log_Msg.h"

class ErrorIndicator{
public:
	virtual void setActive(ACE_Log_Priority p) = 0;
};

#endif /* ERROR_INDICATOR_H_ */
