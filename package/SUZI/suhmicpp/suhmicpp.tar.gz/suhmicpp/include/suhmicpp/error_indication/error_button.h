/*
 * error_button.h
 *
 *  Created on: Sep 26, 2011
 *      Author: vlado
 */

#ifndef ERROR_BUTTON_H_
#define ERROR_BUTTON_H_

#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QSize>
#include "error_indicator.h"

class ErrorButton:
		public ErrorIndicator,
		public QGraphicsPixmapItem {
public:
	ErrorButton();
	virtual ~ErrorButton(){};
	virtual void setActive(ACE_Log_Priority p);
	void move(QSize winSize);
	void mousePressEvent(QGraphicsSceneMouseEvent * event);
private:
	QPixmap pixmap;
};

#endif /* ERROR_BUTTON_H_ */
