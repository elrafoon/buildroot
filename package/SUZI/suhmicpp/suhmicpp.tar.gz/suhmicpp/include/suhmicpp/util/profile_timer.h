/*
 * timer.h
 *
 *  Created on: Jul 8, 2011
 *      Author: vlado
 */

#ifndef PROFILE_TIMER_H_
#define PROFILE_TIMER_H_

#include <QTime>
#include <string>
#include "suhmicpp/util/prefixed_logger.h"

class ProfileTimer : protected PrefixedLogger{
public:
	ProfileTimer(std::string &name);
	~ProfileTimer();
private:
	QTime t;
	unsigned long us;
	std::string name;
};

#endif /* PROFILE_TIMER_H_ */
