/*
 * prefixed_logger.h
 *
 *  Created on: Mar 10, 2011
 *      Author: stano
 */

#ifndef SUHMI_CPP_PREFIXED_LOGGER_H_
#define SUHMI_CPP_PREFIXED_LOGGER_H_

#include <ace/Log_Msg.h>
#include <stdarg.h>
#include <string>

class PrefixedLogger {
public:
    PrefixedLogger(const std::string &prefix = "");
    void log(ACE_Log_Priority p, const ACE_TCHAR *format, ...);
protected:
    std::string prefix;
    void setPrefix(const std::string &prefix);
};

#endif // SUHMI_CPP_PREFIXED_LOGGER_H_
