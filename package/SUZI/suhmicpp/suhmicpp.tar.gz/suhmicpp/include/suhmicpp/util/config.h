/*
 * config.h
 *
 *  Created on: Nov 24, 2010
 *      Author: vlado
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#include <string>
#include "ace/Log_Msg.h"

class Configuration {
public:
	Configuration(char *fname);
	std::string basePythonDir; //zakladna cesta, kam sa budu deserializovat moduly z XML
};

extern Configuration *config;

#endif /* CONFIG_H_ */
