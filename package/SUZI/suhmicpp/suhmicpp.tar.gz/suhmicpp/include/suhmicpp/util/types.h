/*
 * types.h
 *
 *  Created on: Dec 13, 2010
 *      Author: vlado
 */

#ifndef TYPES_H_
#define TYPES_H_

#define HMI 				0x01
#define SYMBOL 				0x02
#define VISUAL_SYMBOL 		0x04
#define COMPOUND_SYMBOL 	0x08
#define IMAGE 				0x10
#define SIMPLE_VISUAL_SYMBOL 0x20
#define ARC 				0x40
#define BASE_LABEL 			0x80
#define LABEL 				0x100
#define STATIC_LABEL 		0x200
#define VALUE_DISPLAY 		0x400
#define ELLIPSE 			0x800
#define LINE 				0x1000
#define POLYGON 			0x2000
#define POLYLINE 			0x4000
#define RECT 				0x8000
#define WINDOW  			0x10000
#define ALARM_WINDOW  		0x20000
#define TIMER		  		0x40000

#endif /* TYPES_H_ */
