/*
 * util.h
 *
 *  Created on: Jul 13, 2011
 *      Author: vlado
 */

#ifndef UTIL_H_
#define UTIL_H_

#include <string>
#include <QPen>

class Util{
public:
	static std::string colorNameToCode(std::string &colorName);
	static bool isColorCode(std::string &colorCode);
	static Qt::PenStyle stringToFgStyle(const std::string &fgStyle);
	static Qt::BrushStyle stringToBgStyle(const std::string &bgStyle);
};
#endif /* UTIL_H_ */
