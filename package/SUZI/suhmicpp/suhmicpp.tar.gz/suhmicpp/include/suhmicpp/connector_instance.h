/*
 * connector_instance.h
 *
 *  Created on: Sep 10, 2010
 *      Author: vlado
 */

#ifndef CONNECTOR_INSTANCE_H_
#define CONNECTOR_INSTANCE_H_

#include "scl/hlapi/connector.h"

extern SuhubConnectorLight::Connector *con;
typedef SuhubConnectorLight::Connector Connector;

#endif /* CONNECTOR_INSTANCE_H_ */
