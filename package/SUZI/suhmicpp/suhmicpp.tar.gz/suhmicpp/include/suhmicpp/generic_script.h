/*
 * generic_script.h
 *
 *  Created on: Jul 13, 2010
 *      Author: vlado
 */

#ifndef GENERIC_SCRIPT_H_
#define GENERIC_SCRIPT_H_

#include <string>
#include <QString>
#include <QXmlAttributes>
#include "suhmicpp/script.h"
#include "suhmicpp/traceable.h"

class GenericScript : public Traceable{
public:
	//GenericScript(ObjectBase *ob);
	GenericScript(ObjectBase *ob, QString name);
	GenericScript(ObjectBase *ob, const QXmlAttributes &attributes);
	GenericScript(const GenericScript &gs, ObjectBase *ob);
	virtual void setDebugInfo(VectorOfStrings &debugInfo, std::string &parentId);
	std::string name;
	Script script;
};

#endif /* GENERIC_SCRIPT_H_ */
