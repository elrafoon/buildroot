/*
 * test_polyline.h
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#ifndef TEST_POLYLINE_H_
#define TEST_POLYLINE_H_

#include "gtest/gtest.h"
#include "suhmicpp/symbols/polyline.h"
#include <vector>

class TestPolyline : public ::testing::Test {
public:
	typedef std::vector<Polyline *> PolylineVector;
	PolylineVector polylines;
};

#endif /* TEST_POLYLINE_H_ */
