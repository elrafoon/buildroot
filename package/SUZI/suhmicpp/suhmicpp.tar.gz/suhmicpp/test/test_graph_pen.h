/*
 * test_graph_pen.h
 *
 *  Created on: Oct 19, 2011
 *      Author: vlado
 */

#ifndef TEST_GRAPH_PEN_H_
#define TEST_GRAPH_PEN_H_

#include "gtest/gtest.h"
#include "suhmicpp/graph/online_graph_pen.h"

class TestGraphPen:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	OnlineGraphPen *pen;
};

#endif /* TEST_GRAPH_PEN_H_ */
