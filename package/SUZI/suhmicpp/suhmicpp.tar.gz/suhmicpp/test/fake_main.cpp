#include "gtest/gtest.h"
#include "WidgetKeyboard.h"
#include "scl/hlapi/connector.h"
#include "suhmicpp/error_indication/error_button.h"
#include "suhmicpp/adapters/hmi_adapt.h"
#include "suhmicpp/adapters/symbol_adapt.h"
#include "suhmicpp/adapters/window_adapt.h"
#include "suhmicpp/error_indication/error_button.h"

SuhubConnectorLight::Connector *con = NULL;
HmiAdapt *hmiAdapt;
HmiAdapt *currentHmi;
SymbolAdapt *currentSymbol;
WindowAdapt *currentWindow;
WidgetKeyboard *virtualKeyBoard;
ErrorButton *errorButton;

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  con = new SuhubConnectorLight::Connector;
  QApplication app(argc, argv);
  errorButton =  new ErrorButton;
  Py_Initialize();
  int r = RUN_ALL_TESTS();
  Py_Finalize();
  return r;
}
