/*
 * test_alarm.cpp
 *
 *  Created on: Oct 18, 2011
 *      Author: vlado
 */

#include "stdint.h"
#include <QFont>
#include <QFontMetrics>
#include "test_alarm.h"
#include "suhmicpp/configurations/alarm_configuration.h"


void TestAlarm::SetUp() {
	QXmlAttributes attrs;
	attrs.append("refreshPeriod", "", "", "1");
	attrs.append("defaultSortColumn", "", "", "1");
	attrs.append("userSortEnabled", "", "", "false");

	QXmlAttributes alarmConfAttrs;
	alarmConfAttrs.append("host", "", "", "localhost");
	alarmConfAttrs.append("port", "", "", "11000");

	AlarmConfiguration alarmConf;
	alarmConf.setAttributes(alarmConfAttrs);
	a = new AlarmWindow(attrs, alarmConf.port, alarmConf.host);
	a->source = new AWSSystem();
}

void TestAlarm::TearDown() {
	a->fini();
	delete a;
}

//TEST_F(TestAlarm, setColumnSet){
//	QXmlAttributes colAttrs;
//	colAttrs.append("alarmLatestUpdateTime", "", "", "1");
//	colAttrs.append("alarmName", "", "", "2");
//	colAttrs.append("groupName", "", "", "3");
//	colAttrs.append("alarmPriority", "", "", "4");
//	colAttrs.append("alarmEffectivePriority", "", "", "5");
//	colAttrs.append("groupEffectivePriority", "", "", "6");
//	colAttrs.append("alarmState", "", "", "7");
//	colAttrs.append("groupState", "", "", "8");
//	colAttrs.append("alarmConditions", "", "", "9");
//
//	ASSERT_EQ(a->columns.size(), (unsigned long)9);
//}

TEST_F(TestAlarm, setButtonSet){
	QXmlAttributes buttonAttrs;
	buttonAttrs.append("ackSelected", "", "", "1");
	buttonAttrs.append("ackGroup", "", "", "2");
	buttonAttrs.append("ackAll", "", "", "4");
	buttonAttrs.append("ackInactive", "", "", "5");
	a->setButtonSet(buttonAttrs);
	ASSERT_EQ(a->buttonVector.size(), (unsigned long)4);
}

TEST_F(TestAlarm, getAlarmWindowWidget){
//	setColumnWidths();
//	setButtonSet();
//	setColumnWidths();
//	AlarmController const * const ac = a->getAlarmWindowWidget();
}
