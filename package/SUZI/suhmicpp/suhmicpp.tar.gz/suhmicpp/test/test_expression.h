/*
 * test_expression.h
 *
 *  Created on: Oct 3, 2011
 *      Author: vlado
 */

#ifndef TEST_EXPRESSION_H_
#define TEST_EXPRESSION_H_

#include "gtest/gtest.h"
#include "suhmicpp/expression.h"
#include "suhmicpp/window/window.h"

class TestExpression: public ::testing::Test {
public:
	TestExpression();
	virtual void SetUp();
	virtual void TearDown();
	Expression *exp;

	TagList inList;
	TagList outList;

	SuhubConnectorLight::StatefulTag in;
	SuhubConnectorLight::StatefulTag out;
};

#endif /* TEST_EXPRESSION_H_ */
