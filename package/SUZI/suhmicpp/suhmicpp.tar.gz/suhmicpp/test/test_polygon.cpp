/*
 * test_polygon.cpp
 *
 *  Created on: Oct 7, 2011
 *      Author: vlado
 */

#include "test_polygon.h"

void TestPolygon::SetUp() {
	QXmlAttributes attrs;
	//attrs.append("extension", "", "", "JPG");
	polygon = new Polygon(attrs);
}

void TestPolygon::TearDown() {
	delete polygon;
}

TEST_F(TestPolygon, finiEmpty){
	polygon->fini();
}

TEST_F(TestPolygon, fini){
	int vertexes[2][2] = { { 0, 0 }, { 1, 1 } };
	for(int i = 0; i < 2; i++){
		QXmlAttributes vertex;
		vertex.append("x", "", "", QString("%1").arg(vertexes[i][0]));
		vertex.append("y", "", "", QString("%1").arg(vertexes[i][1]));
		polygon->addVertex(vertex);
	}
	polygon->fini();
	EXPECT_EQ((int)(polygon->vertexes.size()), 2);
}
