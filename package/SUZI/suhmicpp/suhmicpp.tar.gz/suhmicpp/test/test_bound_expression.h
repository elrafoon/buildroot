/*
 * test_bound_expression.h
 *
 *  Created on: Nov 17, 2011
 *      Author: vlado
 */

#ifndef TEST_BOUND_EXPRESSION_H_
#define TEST_BOUND_EXPRESSION_H_

#include "suhmicpp/bound_expression.h"
#include "suhmicpp/links/visibilitylink.h"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include "suhmicpp/result_listener.h"

class MockResultListener:
		public ResultListener {
public:
	MOCK_METHOD1(handleResult, void(double result));
};

class TestBoundExpression:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	BoundExpression *be;
	VisibilityLink *vl;
	MockResultListener *rl;
};

#endif /* TEST_BOUND_EXPRESSION_H_ */
