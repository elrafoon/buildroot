/*
 * test_line.cpp
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#include "test_line.h"

#define startStep 2
#define sizeStep 5

void TestLine::SetUp(){
	QXmlAttributes attrs;
	attrs.append("x", "", "", QString("%1").arg(rand() % 100));
	attrs.append("y", "", "", QString("%1").arg(rand() % 100));

	l = new Line(attrs);
	l->addVertex(attrs);
	l->fini();

}

void TestLine::TearDown(){
	l->fini();
	delete l;
}

TEST_F(TestLine, clone){
	Line *lclone = static_cast<Line *>(l->clone());
	ASSERT_EQ(l->vertexes, lclone->vertexes);
}

TEST_F(TestLine, size){
	l->setSize(100,200);
	std::pair<int, int> size = l->getSize();
	ASSERT_EQ(size.first, 100);
	ASSERT_EQ(size.second, 200);
}

TEST_F(TestLine, setLineWidth){
	for(int i = -100; i <= 100; i++){
		l->setLineWidth(i);
	}
}

TEST_F(TestLine, rotation) {
	l->setRotation((float)45.0);
	ASSERT_EQ(l->rotation, (float)45.0);
	ASSERT_EQ(((QGraphicsItem*)l)->rotation(), -45.0);
}
