#include <QtCore>
#include <QXmlAttributes>
#include "suhmicpp/symbols/image.h"
#include "gtest/gtest.h"

class ImageTest : public ::testing::Test {
 protected:
  virtual void SetUp() {

	  QXmlAttributes attrs;
	  attrs.append("extension", "", "", "JPG");
	  img = new Image(attrs);
  }

  virtual void TearDown() {

  }
  Image *img;
};

TEST_F(ImageTest, setSize) {
	img->setSize(100, 200);
	std::pair<int, int> size = img->getSize();
	ASSERT_EQ(size.first, 100);
	ASSERT_EQ(size.second, 200);
}

TEST_F(ImageTest, setNegativeSize) {
	img->setSize(-100, -200);
	std::pair<int, int> size = img->getSize();
	ASSERT_EQ(size.first, 1);
	ASSERT_EQ(size.second, 1);
}

TEST_F(ImageTest, setTooBigSize) {
	QSize maxSize = img->getMaxSize();
	QSize bigSize = maxSize + QSize(10, 10);
	img->setSize(bigSize.width(), bigSize.height());
	std::pair<int, int> size = img->getSize();
	ASSERT_EQ(size.first, maxSize.width());
	ASSERT_EQ(size.second, maxSize.height());
}
