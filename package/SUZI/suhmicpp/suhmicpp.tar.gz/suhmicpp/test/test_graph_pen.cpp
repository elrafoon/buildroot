/*
 * test_graph_pen.cpp
 *
 *  Created on: Oct 19, 2011
 *      Author: vlado
 */

#include "test_graph_pen.h"
#include "scl/hlapi/stateful_ifc.h"
#include "suhmicpp/configurations/archer_configuration.h"

void TestGraphPen::SetUp(){
	QXmlAttributes attrs;
	attrs.append("color", "", "", "title");
	attrs.append("width", "", "", "#0f0f0f");
	attrs.append("style", "", "", "10");
	attrs.append("minEU", "", "", "10");
	attrs.append("maxEU", "", "", "#000");
	attrs.append("datatype", "", "", "#fff");

	QXmlAttributes rangeAttrs;
	rangeAttrs.append("minimum", "", "", "10");
	rangeAttrs.append("maximum", "", "", "100");

	ArcherConfiguration ac;
	SuhubConnectorLight::StatefulTag in("IN", false);
	pen = new OnlineGraphPen(attrs, &in, 0, ac);
	pen->range = new OnlineGraphPenRangeManual(rangeAttrs);
}

void TestGraphPen::TearDown(){
	delete pen;
}

TEST_F(TestGraphPen, setTimeRange){
	pen->setTimeRange(0,0);
	pen->setTimeRange(-10,-10);
}
