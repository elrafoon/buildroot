/*
 * test_visual_symbol.h
 *
 *  Created on: Sep 30, 2011
 *      Author: vlado
 */

#ifndef TEST_VISUAL_SYMBOL_H_
#define TEST_VISUAL_SYMBOL_H_

#include "gtest/gtest.h"
#include <QXmlAttributes>
#include <QSize>
#include "suhmicpp/symbols/rect.h"

class TestVisualSymbol:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	Rect *rect;
};

#endif /* TEST_VISUAL_SYMBOL_H_ */
