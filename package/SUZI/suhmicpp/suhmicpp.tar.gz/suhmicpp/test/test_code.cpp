/*
 * test_code.cpp
 *
 *  Created on: Sep 30, 2011
 *      Author: vlado
 */

#include <string>
#include "test_code.h"
#include "suhmicpp/lists/tag_list.h"
#include "scl/hlapi/stateful_ifc.h"

void TestCode::SetUp(){
	QXmlAttributes attrs;
	//attrs.append("extension", "", "", "JPG");
	Window win(attrs);
	code = new Code(&win);
}
void TestCode::TearDown(){
	delete code;
}

TEST_F(TestCode, replaceQuestionMark)
{
	std::string codeStr("?TAG \"?TAG\"");
	std::string postCodeStr("app = hmi.cvar.hmiAdapt\ncurrent = hmi.cvar.currentWindow\n_TAG \"?TAG\"\n");
	code->setCode(codeStr);
	ASSERT_EQ(code->getCode(), postCodeStr);
}

TEST_F(TestCode, removeTagPrefix)
{
	std::string codeStr("!TAG $TAG \"\"\"!TAG $TAG\"\"\" \"!TAG $TAG\" '!TAG $TAG'");
	std::string postCodeStr("app = hmi.cvar.hmiAdapt\ncurrent = hmi.cvar.currentWindow\nTAG TAG \"\"\"!TAG $TAG\"\"\" \"!TAG $TAG\" '!TAG $TAG'\n");
	code->setCode(codeStr);
	ASSERT_EQ(code->getCode(), postCodeStr);
}

TEST_F(TestCode, exec)
{
	std::string codeStr("!OUT.v = 5*$IN.v");
	code->setCode(codeStr);
	code->compileCode();
	TagList inList;
	TagList outList;
	SuhubConnectorLight::StatefulTag in("IN", false);
	SuhubConnectorLight::StatefulTag out("OUT", false);
	inList.uniquePush(&in);
	outList.uniquePush(&out);
	in.value.v = 5;
	code->addTag(&in);
	code->addTag(&out);
	int r = code->exec(inList, outList);
	ASSERT_EQ(r, 0); //neviem testovat out.value.v, lebo exec nezapisuje do tagu, iba vyvola zapis do suhubu
}

//const SuhubConnectorLight::UpdateList &updateList, TagList const &outputList
TEST_F(TestCode, exec2)
{
	std::string codeStr("!OUT.v = 5");
	SuhubConnectorLight::UpdateList updateList;
	code->setCode(codeStr);
	code->compileCode();
	TagList outList;
	SuhubConnectorLight::StatefulTag out("OUT", false);
	outList.uniquePush(&out);
	code->addTag(&out);
	int r = code->exec(updateList, outList);
	ASSERT_EQ(r, 0); //neviem testovat out.value.v, lebo exec nezapisuje do tagu, iba vyvola zapis do suhubu
}

//onchange
//int exec(TagList const &inputList, TagList const &outputList, std::string &newText);
TEST_F(TestCode, exec3)
{
	std::string codeStr("!OUT.v = 5*$IN.v");
	code->setCode(codeStr);
	code->compileCode();
	TagList inList;
	TagList outList;
	SuhubConnectorLight::StatefulTag in("IN", false);
	SuhubConnectorLight::StatefulTag out("OUT", false);
	inList.uniquePush(&in);
	outList.uniquePush(&out);
	in.value.v = 5;
	code->addTag(&in);
	code->addTag(&out);
	std::string str;
	int r = code->exec(inList, outList, str);
	ASSERT_EQ(r, 0); //neviem testovat out.value.v, lebo exec nezapisuje do tagu, iba vyvola zapis do suhubu
}

