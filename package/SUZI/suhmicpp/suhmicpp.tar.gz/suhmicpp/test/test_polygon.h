/*
 * test_polygon.h
 *
 *  Created on: Oct 7, 2011
 *      Author: vlado
 */

#ifndef TEST_POLYGON_H_
#define TEST_POLYGON_H_

#include "gtest/gtest.h"
#include "suhmicpp/symbols/polygon.h"

class TestPolygon: public ::testing::Test{
public:
	virtual void SetUp();
	virtual void TearDown();
	Polygon *polygon;
};

#endif /* TEST_POLYGON_H_ */
