/*
 * test_label.h
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#ifndef TEST_LABEL_H_
#define TEST_LABEL_H_

#include <vector>
#include "gtest/gtest.h"
#include "suhmicpp/symbols/label.h"

class TestLabel: public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	Label *l;
};

#endif /* TEST_LABEL_H_ */
