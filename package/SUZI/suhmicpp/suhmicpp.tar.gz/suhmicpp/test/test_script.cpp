/*
 * test_script.cpp
 *
 *  Created on: Nov 18, 2011
 *      Author: vlado
 */

#include "test_script.h"

void TestScript::SetUp(){
	QXmlAttributes attrs;
	//attrs.append("extension", "", "", "JPG");
	Window win(attrs);
	script = new Script(&win);
}

void TestScript::TearDown(){
	delete script;
}

//void Script::onUpdate(const SuhubConnectorLight::UpdateList &updateList)
TEST_F(TestScript, onUpdate){
	SuhubConnectorLight::UpdateList updateList;

	SuhubConnectorLight::StatefulTag sens("SENSITIVE", false);
	SuhubConnectorLight::Update u(&sens, SuhubConnectorLight::VTQ(0,0,0));
	updateList.push_back(u);
	script->sensitivityList.uniquePush(&sens);
	script->code.setCode("");
	script->code.compileCode();
	script->onUpdate(updateList);
}
