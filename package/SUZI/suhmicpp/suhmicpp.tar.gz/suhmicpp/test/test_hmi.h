/*
 * test_hmi.h
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#ifndef TEST_HMI_H_
#define TEST_HMI_H_

#include "gtest/gtest.h"
#include "suhmicpp/hmi.h"
#include "suhmicpp/xml/xml_reader.h"

extern HmiAdapt *hmiAdapt;

class TestHMI:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();

	Handler handler;
	Hmi *hmi;
	HmiAdapt *hmiAdapt;
};

#endif /* TEST_HMI_H_ */
