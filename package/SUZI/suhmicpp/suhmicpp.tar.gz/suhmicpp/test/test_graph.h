/*
 * test_graph.h
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#ifndef TEST_GRAPH_H_
#define TEST_GRAPH_H_

#include "gtest/gtest.h"
#include "suhmicpp/graph/online_graph.h"

class TestGraph:
		public QObject {
	Q_OBJECT
public:
	TestGraph();
	virtual ~TestGraph();
	OnlineGraph *g;
private slots:
	void fini();
	void init();
	void cleanup();
};

#endif /* TEST_GRAPH_H_ */
