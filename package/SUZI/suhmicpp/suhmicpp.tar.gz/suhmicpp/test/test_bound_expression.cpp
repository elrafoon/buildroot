/*
 * test_bound_expression.cpp
 *
 *  Created on: Nov 17, 2011
 *      Author: vlado
 */

#include <string>
#include "test_bound_expression.h"
#include "suhmicpp/lists/tag_list.h"
#include "scl/hlapi/stateful_ifc.h"
#include "suhmicpp/symbols/rect.h"

using ::testing::_;
using ::testing::AtLeast;


void TestBoundExpression::SetUp(){
	QXmlAttributes attrs;
	//attrs.append("extension", "", "", "JPG");
	Rect rect(attrs);
	rl = new MockResultListener;
	rl->resultType = ResultListener::INT_DOUBLE;
	EXPECT_CALL(*rl, handleResult(_)).Times(AtLeast(1));
	be = new BoundExpression(&rect, rl);
}

void TestBoundExpression::TearDown(){
	delete rl;
	delete be;
}

//void onUpdate(const SuhubConnectorLight::UpdateList &updateList);
TEST_F(TestBoundExpression, onUpdate){
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::StatefulTag in("SENSITIVE", false);
	SuhubConnectorLight::Update u(&in, SuhubConnectorLight::VTQ(0,0,0));
	updateList.push_back(u);

	be->sensitivityList.uniquePush(&in);
	be->expression.setCode("result = 10.0");
	be->expression.compileCode();
	be->onUpdate(updateList);
}
