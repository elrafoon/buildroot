"""Binarku treba prelozit so symbolom TEST."""

GREEN = '\033[92m'
RED = '\033[91m'
ENDC = '\033[0m'

import subprocess
import os

def printOk():
    print GREEN + "OK" + ENDC

def printFailed():
    print RED + "FAILED" + ENDC

testsDir = '/home/vlado/workspace/'
xmlPath = 'output/hmi.xml'
executable = '/home/vlado/suzi/suhmi-cpp/debug-test/suhmicpp'

projects = ['ValueDisplay_complete',
            'StaticLabel_complete',
            'grafy_complete',
            'label_complete',
            'Label_Static_Label',
            'Image_complete',
            'test2',
            ]

for project in projects:
    fullPath = os.path.join(testsDir, project, xmlPath)
    print "Running %s" % (fullPath,)
    retval = subprocess.call([executable, fullPath])
    if retval == 0:
        printOk()
    else:
        printFailed()
        

