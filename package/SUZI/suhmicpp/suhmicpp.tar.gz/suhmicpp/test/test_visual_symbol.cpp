/*
 * test_visual_symbol.cpp
 *
 *  Created on: Sep 30, 2011
 *      Author: vlado
 */

#include "test_visual_symbol.h"

void TestVisualSymbol::SetUp(){
	QXmlAttributes attrs;
	attrs.append("x", "", "", "1");
	attrs.append("y", "", "", "1");
	rect = new Rect(attrs);
	rect->setSize(100,100);
	rect->setScale(attrs);
}

void TestVisualSymbol::TearDown(){
	delete rect;
}

TEST_F(TestVisualSymbol, setScale){
	rect->setScale(1.5, 2.5);
	std::pair<float, float> scale = rect->getScale();
	EXPECT_EQ(scale.first, (float)1.5);
	EXPECT_EQ(scale.second, (float)2.5);
}

TEST_F(TestVisualSymbol, setSmallScale){
	rect->setScale(1.009, 1.009);
	std::pair<float, float> scale = rect->getScale();
	EXPECT_EQ(scale.first, (float)1.009);
	EXPECT_EQ(scale.second, (float)1.009);
}

TEST_F(TestVisualSymbol, setNegativeScale){
	rect->setScale(-1, -2);
	std::pair<float, float> scale = rect->getScale();
	EXPECT_EQ(scale.first, (float)(1/100.0)); //size.width
	EXPECT_EQ(scale.second, (float)(1/100.0)); //size.height

	std::pair<int, int> size = rect->getSize();
	EXPECT_EQ(size.first, 1);
	EXPECT_EQ(size.second, 1);
}

TEST_F(TestVisualSymbol, setPosition){
	rect->setPosition(0, 0);
	EXPECT_EQ(rect->pos().x(), 0.0);
	EXPECT_EQ(rect->pos().y(), 0.0);
}
