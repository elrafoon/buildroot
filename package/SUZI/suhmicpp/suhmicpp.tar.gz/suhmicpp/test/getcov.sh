#!/bin/sh

lcov -d .. -b /home/vlado/suzi/suhmi-cpp -c -o all.info
lcov -e all.info "*src*" -o suzi.info
genhtml -s --legend -o result suzi.info
