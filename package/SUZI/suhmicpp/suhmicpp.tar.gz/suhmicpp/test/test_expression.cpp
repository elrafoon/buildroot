/*
 * test_expression.cpp
 *
 *  Created on: Oct 3, 2011
 *      Author: vlado
 */

#include <string>
#include <QXmlAttributes>
#include "test_expression.h"
#include "suhmicpp/lists/tag_list.h"
#include "scl/hlapi/stateful_ifc.h"

TestExpression::TestExpression() :
		in("IN", false), out("OUT", false) {

}

void TestExpression::SetUp() {
	QXmlAttributes attrs;
	Window win(attrs);
	exp = new Expression(&win, NULL);

	inList.uniquePush(&in);
	outList.uniquePush(&out);

}
void TestExpression::TearDown() {
	delete exp;
}

TEST_F(TestExpression, execDoubleOk) {
	std::string codeStr("result = 5*$IN.v");
	exp->setCode(codeStr);
	exp->compileCode();
	in.value.v = 5;
	exp->addTag(&in);
	exp->addTag(&out);
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::Update update(&in, SuhubConnectorLight::VTQ(10, 0, 0));
	updateList.push_back(update);
	double result;
	int ret = exp->exec(updateList, result);
	ASSERT_EQ(result, 50.0);
	ASSERT_EQ(ret, 0);
}

TEST_F(TestExpression, execDoubleNone) {
	std::string codeStr("result = None");
	exp->setCode(codeStr);
	exp->compileCode();
	exp->addTag(&in);
	exp->addTag(&out);
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::Update update(&in, SuhubConnectorLight::VTQ(10, 0, 0));
	updateList.push_back(update);
	double result;
	int ret = exp->exec(updateList, result);
	ASSERT_EQ(ret, 1);
}

TEST_F(TestExpression, execBoolOk) {
	std::string codeStr("result = True");
	exp->setCode(codeStr);
	exp->compileCode();
	exp->addTag(&in);
	exp->addTag(&out);
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::Update update(&in, SuhubConnectorLight::VTQ(10, 0, 0));
	updateList.push_back(update);
	bool result;
	int ret = exp->exec(updateList, result);
	ASSERT_EQ(result, true);
	ASSERT_EQ(ret, 0);
}
TEST_F(TestExpression, execBoolNone) {
	std::string codeStr("result = None");
	exp->setCode(codeStr);
	exp->compileCode();
	exp->addTag(&in);
	exp->addTag(&out);
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::Update update(&in, SuhubConnectorLight::VTQ(10, 0, 0));
	updateList.push_back(update);
	bool result;
	int ret = exp->exec(updateList, result);
	ASSERT_EQ(ret, 1);
}

TEST_F(TestExpression, execStringOk) {
	std::string codeStr("result = 'string'");
	exp->setCode(codeStr);
	exp->compileCode();
	exp->addTag(&in);
	exp->addTag(&out);
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::Update update(&in, SuhubConnectorLight::VTQ(10, 0, 0));
	updateList.push_back(update);
	std::string result;
	int ret = exp->exec(updateList, result);
	ASSERT_EQ(ret, 0);
}

TEST_F(TestExpression, execStringNone) {
	std::string codeStr("result = None");
	exp->setCode(codeStr);
	exp->compileCode();
	exp->addTag(&in);
	exp->addTag(&out);
	SuhubConnectorLight::UpdateList updateList;
	SuhubConnectorLight::Update update(&in, SuhubConnectorLight::VTQ(10, 0, 0));
	updateList.push_back(update);
	std::string result;
	int ret = exp->exec(updateList, result);
	ASSERT_EQ(ret, 1);
}
