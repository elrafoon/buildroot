/*
 * test_compound_symbol.h
 *
 *  Created on: Oct 17, 2011
 *      Author: vlado
 */

#ifndef TEST_COMPOUND_SYMBOL_H_
#define TEST_COMPOUND_SYMBOL_H_

#include "gtest/gtest.h"
#include "suhmicpp/hmi.h"
#include "suhmicpp/xml/xml_reader.h"
#include "suhmicpp/symbols/compound_symbol.h"

class TestCS: public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();

	typedef std::list<BoundExpression *> BoundExpressionsPtrs;
	typedef std::list<Script *> ScriptPtrs;
	typedef std::list<ValueLink *> ValueLinkPtrs;
	typedef std::set<BlinkLink *> BlinkLinksSet;

	CompoundSymbol *cs;
};

#endif /* TEST_COMPOUND_SYMBOL_H_ */
