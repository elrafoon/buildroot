/*
 * test_compound_symbol.cpp
 *
 *  Created on: Oct 17, 2011
 *      Author: vlado
 */

#include <QXmlSimpleReader>
#include <QXmlInputSource>
#include "test_compound_symbol.h"
#include "suhmicpp/symbols/rect.h"
#include "suhmicpp/symbols/compound_symbol_template.h"

void TestCS::SetUp() {
	QXmlAttributes attrs;
	attrs.append("x", "", "", "1");
	attrs.append("y", "", "", "1");
	attrs.append("width", "", "", "100");
	attrs.append("height", "", "", "100");

	QXmlAttributes scaleAttrs;
	scaleAttrs.append("x", "", "", "1.0");
	scaleAttrs.append("y", "", "", "1.0");

	QXmlAttributes sizeAttrs;
	sizeAttrs.append("width", "", "", "100");
	sizeAttrs.append("height", "", "", "100");

	Rect *symbol = new Rect(attrs);
	CompoundSymbolTemplate cst;
	BoundExpressionsPtrs boundExpressionsPtrs;
	ScriptPtrs scriptPtrs;
	ValueLinkPtrs valueLinkPtrs;
	BlinkLinksSet blinkLinks;
	cst.symbol.push_back(symbol);
	cs = new CompoundSymbol(attrs, &cst, boundExpressionsPtrs, scriptPtrs, valueLinkPtrs, blinkLinks);
	static_cast<VisualSymbol*>(cs)->setSize(sizeAttrs);
	static_cast<VisualSymbol*>(cs)->setScale(scaleAttrs);
}

void TestCS::TearDown() {
	delete cs;
}

TEST_F(TestCS, fini) {
	cs->fini();
}

TEST_F(TestCS, create) {
	cs->create();
}

TEST_F(TestCS, getSize) {
	std::pair<int, int> size = cs->getSize();
	ASSERT_EQ(size.first, 100);
	ASSERT_EQ(size.second, 100);
}

TEST_F(TestCS, getScale) {
	std::pair<float, float> scale = cs->getScale();
	ASSERT_EQ(scale.first, (float)1.0);
	ASSERT_EQ(scale.second, (float)1.0);
}

TEST_F(TestCS, setScale) {
	cs->setScale(1.0, 2.0);
	std::pair<float, float> scale = cs->getScale();
	ASSERT_EQ(scale.first, (float)1.0);
	ASSERT_EQ(scale.second, (float)2.0);
}
