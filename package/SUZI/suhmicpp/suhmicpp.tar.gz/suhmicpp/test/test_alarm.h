/*
 * test_alarm.h
 *
 *  Created on: Oct 18, 2011
 *      Author: vlado
 */

#ifndef TEST_ALARM_H_
#define TEST_ALARM_H_

#include "gtest/gtest.h"
#include "suhmicpp/symbols/alarm_window.h"

class TestAlarm: public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	AlarmWindow *a;
};

#endif /* TEST_ALARM_H_ */
