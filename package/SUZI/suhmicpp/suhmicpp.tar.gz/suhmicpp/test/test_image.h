/*
 * test_image.h
 *
 *  Created on: Sep 29, 2011
 *      Author: vlado
 */

#ifndef TEST_IMAGE_H_
#define TEST_IMAGE_H_

#include <QtGui>
#include <QXmlAttributes>
#include <QSize>
#include "suhmicpp/symbols/image.h"


class TestImage:
		public QObject {
	Q_OBJECT
public:
	TestImage();
	virtual ~TestImage();
	Image *img;
private slots:
	void setSize();
	void setNegativeSize();
	void setTooBigSize();
};


#endif /* TEST_IMAGE_H_ */

