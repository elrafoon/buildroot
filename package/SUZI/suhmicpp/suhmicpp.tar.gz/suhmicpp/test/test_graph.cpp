/*
 * test_graph.cpp
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#include <QFont>
#include <QFontMetrics>
#include "test_graph.h"
#include "suhmicpp/configurations/archer_configuration.h"

TestGraph::TestGraph() {
	Py_Initialize();
}

TestGraph::~TestGraph() {
	Py_Finalize();
}

void TestGraph::init(){
	ArcherConfiguration c;
	QXmlAttributes attrs;
	attrs.append("title", "", "", "title");
	attrs.append("titleColor", "", "", "#0f0f0f");
	attrs.append("horizontalLineCount", "", "", "10");
	attrs.append("verticalLineCount", "", "", "10");
	attrs.append("graphFgColor", "", "", "#000");
	attrs.append("graphBgColor", "", "", "#fff");

	QXmlAttributes fontAttrs;
	fontAttrs.append("name", "", "", "Monospaced");
	fontAttrs.append("size", "", "", "12");
	fontAttrs.append("style", "", "", "plain");

	g = new OnlineGraph(attrs, c);
}

void TestGraph::cleanup(){
	delete g;
}

void TestGraph::fini(){
	g->fini();
}
