/*
 * test_line.h
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#ifndef TEST_LINE_H_
#define TEST_LINE_H_

#include <vector>
#include "gtest/gtest.h"
#include "suhmicpp/symbols/line.h"

class TestLine:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	typedef std::vector<Line *> LineVector;
	Line *l;
};

#endif /* TEST_LINE_H_ */

