/*
 * test_polyline.cpp
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#include "test_polyline.h"

TEST_F(TestPolyline, fini){
	for (int i = 0; i <= 100; i += 100) {
		QXmlAttributes attrs;
		attrs.append("x", "", "", QString("%1").arg(rand() % 100));
		attrs.append("y", "", "", QString("%1").arg(rand() % 100));

		Polyline *p = new Polyline(attrs);
		p->addVertex(attrs);
		p->fini();
	}
}

TEST_F(TestPolyline, clone){
	for (int i = 0; i <= 100; i += 100) {
		QXmlAttributes attrs;
		attrs.append("x", "", "", QString("%1").arg(rand() % 100));
		attrs.append("y", "", "", QString("%1").arg(rand() % 100));

		Polyline *p = new Polyline(attrs);
		p->addVertex(attrs);
		Polyline *pclone = static_cast<Polyline *>(p->clone());
		EXPECT_EQ(p->vertexes, pclone->vertexes);
	}
}

TEST_F(TestPolyline, size){
	QXmlAttributes attrs;
	attrs.append("x", "", "", QString("%1").arg(rand() % 100));
	attrs.append("y", "", "", QString("%1").arg(rand() % 100));

	Polyline *p = new Polyline(attrs);
	p->addVertex(attrs);
	p->setSize(100,200);
	std::pair<int, int> size = p->getSize();
	EXPECT_EQ(size.first, 100);
	EXPECT_EQ(size.second, 200);
}

TEST_F(TestPolyline, setLineWidth){
	QXmlAttributes attrs;
	attrs.append("x", "", "", QString("%1").arg(rand() % 100));
	attrs.append("y", "", "", QString("%1").arg(rand() % 100));

	Polyline *p = new Polyline(attrs);
	p->addVertex(attrs);
	for(int i = -100; i <= 100; i++){
		p->setLineWidth(i);
	}
}
