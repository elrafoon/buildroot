#include "gtest/gtest.h"

TEST(IsPrimeTest, Positive) {
  EXPECT_FALSE(false);
  EXPECT_TRUE(true);
}
