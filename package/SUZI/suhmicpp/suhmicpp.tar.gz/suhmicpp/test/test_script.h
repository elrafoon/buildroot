/*
 * test_script.h
 *
 *  Created on: Nov 18, 2011
 *      Author: vlado
 */

#ifndef TEST_SCRIPT_H_
#define TEST_SCRIPT_H_

#include "gtest/gtest.h"
#include "suhmicpp/script.h"
#include "suhmicpp/window/window.h"
#include "suhmicpp/lists/tag_list.h"
#include "scl/hlapi/stateful_ifc.h"

class TestScript:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	Script *script;
};

#endif /* TEST_SCRIPT_H_ */

