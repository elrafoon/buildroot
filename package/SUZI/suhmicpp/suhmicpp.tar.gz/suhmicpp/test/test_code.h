/*
 * test_code.h
 *
 *  Created on: Sep 30, 2011
 *      Author: vlado
 */

#ifndef TEST_CODE_H_
#define TEST_CODE_H_

#include "gtest/gtest.h"
#include "suhmicpp/code.h"
#include "suhmicpp/window/window.h"

class TestCode:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();
	Code *code;
};


#endif /* TEST_CODE_H_ */

