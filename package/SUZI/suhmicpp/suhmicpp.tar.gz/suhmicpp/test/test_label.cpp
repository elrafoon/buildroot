/*
 * test_label.cpp
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#include "test_label.h"

#define startStep 2
#define sizeStep 5

void TestLabel::SetUp() {
	QXmlAttributes attrs;
	attrs.append("writeEnabled", "", "", "true");
	l = new Label(attrs);
}

void TestLabel::TearDown() {
	delete l;
}

TEST_F(TestLabel, clone) {
	Label *lclone = static_cast<Label *>(l->clone());
	ASSERT_EQ(lclone->writeEnabled, l->writeEnabled);
	ASSERT_EQ(lclone->expression, l->expression);
	ASSERT_EQ(lclone->fontSize, l->fontSize);
	delete lclone;
}

TEST_F(TestLabel, handleResult) {
	l->handleResult("Test string");
	ASSERT_EQ(l->getText().c_str(), "Test string");
	QString utf8 = QString::fromUtf8("Päťtýždňové vĺčatá nervózne štekajú na môjho ďatľa v tŕní.");
	std::string u = utf8.toUtf8().data();
	l->handleResult(u);
	ASSERT_EQ(l->getText().data(), utf8.toUtf8().data());
}
