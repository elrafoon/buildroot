/*
 * test_arc.cpp
 *
 *  Created on: Oct 7, 2011
 *      Author: vlado
 */

#include "test_arc.h"

#define startStep 10
#define sizeStep 10

void TestArc::SetUp() {
	for (int i = 0; i <= 360; i += startStep) {
		for (int j = 0; j <= 360; j += sizeStep) {
			QXmlAttributes attrs;
			attrs.append("angleStart", "", "", QString("%1").arg(i));
			attrs.append("angleSize", "", "", QString("%1").arg(j));
			attrs.append("radius", "", "", "10");
			attrs.append("arcType", "", "", "pie");

			Arc *a = new Arc(attrs);
			pieArcs.push_back(a);
		}
	}
	for (int i = 0; i <= 360; i += startStep) {
		for (int j = 0; j <= 360; j += sizeStep) {
			QXmlAttributes attrs;
			attrs.append("angleStart", "", "", QString("%1").arg(i));
			attrs.append("angleSize", "", "", QString("%1").arg(j));
			attrs.append("radius", "", "", "10");
			attrs.append("arcType", "", "", "chord");

			Arc *a = new Arc(attrs);
			chordArcs.push_back(a);
		}
	}
	for (int i = 0; i <= 360; i += startStep) {
		for (int j = 0; j <= 360; j += sizeStep) {
			QXmlAttributes attrs;
			attrs.append("angleStart", "", "", QString("%1").arg(i));
			attrs.append("angleSize", "", "", QString("%1").arg(j));
			attrs.append("radius", "", "", "10");
			attrs.append("arcType", "", "", "open");

			Arc *a = new Arc(attrs);
			openArcs.push_back(a);
		}
	}

}

void TestArc::TearDown() {
	for (ArcVector::iterator it = pieArcs.begin(); it != pieArcs.end(); ++it)
		delete *it;
}

TEST_F(TestArc, fini) {
	for (ArcVector::iterator arc = pieArcs.begin(); arc != pieArcs.end(); ++arc)
		(*arc)->fini();
	for (ArcVector::iterator arc = chordArcs.begin(); arc != chordArcs.end(); ++arc)
		(*arc)->fini();
	for (ArcVector::iterator arc = openArcs.begin(); arc != openArcs.end(); ++arc)
		(*arc)->fini();
}

TEST_F(TestArc, clone) {
	for (ArcVector::iterator arc = chordArcs.begin(); arc != chordArcs.end(); ++arc) {
		Arc *a = static_cast<Arc*>((*arc)->clone());

		ASSERT_EQ(a->angleStart, (*arc)->angleStart);
		ASSERT_EQ(a->radius, (*arc)->radius);
		ASSERT_EQ(a->arctype, (*arc)->arctype);
	}
}
