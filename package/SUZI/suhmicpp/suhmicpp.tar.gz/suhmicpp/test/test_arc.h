/*
 * test_arc.h
 *
 *  Created on: Oct 7, 2011
 *      Author: vlado
 */

#ifndef TEST_ARC_H_
#define TEST_ARC_H_

#include "gtest/gtest.h"
#include "suhmicpp/symbols/arc.h"
#include <vector>

class TestArc:
		public ::testing::Test {
public:
	virtual void SetUp();
	virtual void TearDown();

	typedef std::vector<Arc *> ArcVector;
	ArcVector pieArcs;
	ArcVector openArcs;
	ArcVector chordArcs;
};

#endif /* TEST_ARC_H_ */
