/*
 * test_hmi.cpp
 *
 *  Created on: Oct 10, 2011
 *      Author: vlado
 */

#include <QXmlSimpleReader>
#include <QXmlInputSource>
#include <QFile>
#include "test_hmi.h"

#define startStep 2
#define sizeStep 5

void TestHMI::SetUp(){
	hmiAdapt = new HmiAdapt();
	QXmlSimpleReader reader;
	reader.setContentHandler(&handler);
	reader.setErrorHandler(&handler);
	QFile file;
	file.setFileName("test/resources/hmi.xml");
	file.open(QIODevice::ReadOnly);
	QXmlInputSource xmlInputSource(&file);
	reader.parse(xmlInputSource);
	hmi = handler.getHmi();
	hmiAdapt->setAdaptee(hmi);
}


void TestHMI::TearDown() {
	//delete hmi;
	delete hmiAdapt;
}
TEST_F(TestHMI, clone) {
	hmi->create();
}




