/*
 * test_symbol_adapt.cpp
 *
 *  Created on: Jul 13, 2011
 *      Author: vlado
 */

#include <string>
#include <iostream>
#include "gtest/gtest.h"
#include "suhmicpp/util/util.h"

TEST(Util, StringToColor) {
	//pri neznamej farbe vracia ciernu
	std::string undefinedColor("undefinedColor");
	EXPECT_EQ(Util::colorNameToCode(undefinedColor), "#000000");

	//ak je farba uz v kode vrati zadany string
	std::string code("#123456");
	EXPECT_EQ(Util::colorNameToCode(code), code);

	std::string shortCode("#123");
	EXPECT_EQ(Util::colorNameToCode(shortCode), shortCode);

	std::string notHexa("#xxx");
	EXPECT_EQ(Util::colorNameToCode(notHexa), "#000000");

	std::string garbled("#1237");
	EXPECT_EQ(Util::colorNameToCode(garbled), "#000000");
}

TEST(Util, StringToColorCaseInsensitivity) {
	std::string white("white");
	std::string White("White");
	std::string whiteUpperCase("WHITE");
	EXPECT_EQ(Util::colorNameToCode(white), "#ffffff");
	EXPECT_EQ(Util::colorNameToCode(White), "#ffffff");
	EXPECT_EQ(Util::colorNameToCode(whiteUpperCase), "#ffffff");
}

TEST(Util, isColorCode) {
	std::string correctCode("#123456");
	std::string correctShortCode("#123");
	std::string incorrectCode("#0g1h2j");
	std::string incorrectShortCode("#ghj");

	EXPECT_TRUE(Util::isColorCode(correctCode));
	EXPECT_TRUE(Util::isColorCode(correctShortCode));
	EXPECT_FALSE(Util::isColorCode(incorrectCode));
	EXPECT_FALSE(Util::isColorCode(incorrectShortCode));
}
